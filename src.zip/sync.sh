#!/usr/bin/env bash
# 把 app_src 里的最新源码同步进可编译工程，然后（可选）备份成 zip
set -e
SRC=/home/user/iosbuild/app_src
DST=$(cd "$(dirname "$0")" && pwd)
cp "$SRC/main.m" "$DST/Left_Superlike/main.m"
cp "$SRC/Info.plist" "$DST/Left_Superlike/Info.plist"
for f in $(ls "$SRC/www"); do
  case "$f" in *.bak) continue;; esac
  cp -r "$SRC/www/$f" "$DST/Left_Superlike/www/"
done
echo "synced: $(date '+%F %T')"
