# Left_Superlike · iOS 可编译工程

这个包把原来只能"拆旧 ipa 换网页"的工作副本，升级成一个**能真正编译出 ipa** 的 Xcode 工程（用 XcodeGen 生成工程文件，不需要手改 pbxproj）。

## 这次加了什么

**壳（main.m）新增消息通道 `repostPosts`**

```js
window.webkit.messageHandlers.lsStore.postMessage({
  type : 'repostPosts',
  urls : ['https://weibo.com/6656507054/RqLUD1UM5', ...],
  uids : ['1234567890', ...],
  gap  : 4.5
});
```

- 收到后先用 `LSPickPostKey()` 把每条链接转成微博 mid（认不出的会记一条"没认出来"）
- 再对「勾选的每个账号 × 每条帖子」调用已有的 `lsPostRepost:` 转发（走的是原来那套 `normal_repost`，含驳回重试和验证过后的二次转发）
- 日志走 `superLikeLog:`，显示在任务中心的运行日志区
- 成功条数计入 `lsStatsAdd:@"repost"` 并 `pushStats`，**积分照旧 1 条 1 分**

**网页（www/index.html）超Like 卡片里多了一块**

「只转发指定帖子」输入框 + 「锁定这些帖子 · 转发」按钮。留空不影响原来"转发超话精华帖"的逻辑。

## 怎么编出 ipa

### 方式一：GitHub Actions（不用 Mac）

1. 在 GitHub 建一个**私有**仓库
2. 把这个包里的所有文件传上去（`.github/workflows/build-ipa.yml` 要一起，它是隐藏目录，别漏）
3. 进仓库的 **Actions** 页，选 `build-ipa` → **Run workflow**
4. 等 5~10 分钟，跑完在 Artifacts 里下载 `Left_Superlike_unsigned`，解压得到 `Left_Superlike_unsigned.ipa`
5. 用全能签装上

免费额度足够：私有仓库每月 2000 分钟，一次编译约 5 分钟。

### 方式二：有 Mac 就在本地

```bash
brew install xcodegen
xcodegen generate
open Left_Superlike.xcodeproj
```

Xcode 里选真机 → Product → Archive → 导出 unsigned ipa（签名那步选 None / 跳过），一样能拿给全能签。

### 方式三：命令行（Mac）

```bash
xcodebuild -project Left_Superlike.xcodeproj -scheme Left_Superlike \
  -configuration Release -sdk iphoneos -derivedDataPath build \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY="" build
mkdir -p out/Payload && cp -R build/Build/Products/Release-iphoneos/Left_Superlike.app out/Payload/
cd out && zip -qry ../Left_Superlike_unsigned.ipa Payload
```

## 目录结构

```
project.yml                      XcodeGen 工程定义（target 名 Left_Superlike）
Left_Superlike/
  main.m                         壳源码（全部原生逻辑）
  Info.plist                     已去掉失效的 CFBundleIcons，改走 Assets 的 AppIcon
  www/                           网页资源，编译时作为 folder 整体拷进 .app 根
    index.html
    camp1.png camp2.png camp3.png
  Assets.xcassets/AppIcon.appiconset/   图标位（编译时由 sips 从 assets/icon_src.png 生成）
assets/icon_src.png              1024×1024 源图（实际是 JPEG，sips 会转成 png）
.github/workflows/build-ipa.yml  macOS runner 编译脚本
sync.sh                          从工作副本同步源码过来
```

## 以后改代码的流程

1. 改 `/home/user/iosbuild/app_src/main.m` 或 `app_src/www/index.html`（那是日常改的地方）
2. 跑 `./sync.sh` 把改动同步进本工程
3. 推上 GitHub，跑 Actions

## 注意

- 编译产物是 **unsigned ipa**，签名交给全能签（和你之前一样）
- Bundle ID 是 `com.leftsuperlike.ios`，和现有包一致
- 版本号在 `Info.plist`（当前 1.00 / 100），网页底部那句 `Left_Superlike v1.00 · 任务中心` 在 `www/index.html`，两处要一起改
- `www/index.html.v0xx.bak` 这些历史备份没有打进工程，避免包体变大
