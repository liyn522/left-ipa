#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>
#import <ImageIO/ImageIO.h>

static NSString *const kUA = @"Mozilla/5.0 (iPhone; CPU iPhone OS 16_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Mobile/15E148 Safari/604.1";
static NSString *const kLoginURL = @"https://passport.weibo.com/sso/signin?entry=wapsso&source=wapsso&url=https%3A%2F%2Fm.weibo.cn%2F";
static NSString *const kFallbackURL = @"https://login.sina.com.cn/sso/login.php?url=https%3A%2F%2Fm.weibo.cn%2F";

// 超话签到（与安卓版 WeiboClient.checkinSuper 同一接口）
static NSString *const kSuperId = @"100808b0fa9bca8e311e27df3c4903873038c5";

// ---- 捞帖工具 ----
static NSString *LSPickUID(NSString *raw) {
    if (![raw isKindOfClass:[NSString class]]) return @"";
    NSRegularExpression *re = [NSRegularExpression regularExpressionWithPattern:@"\\d{6,}" options:0 error:nil];
    NSArray *ms = [re matchesInString:raw options:0 range:NSMakeRange(0, raw.length)];
    NSString *best = @"";
    for (NSTextCheckingResult *m in ms) {
        NSString *t = [raw substringWithRange:m.range];
        if (t.length > best.length) best = t;
    }
    return best;
}


static NSString *LSPickPageID(NSString *raw) {
    if (![raw isKindOfClass:[NSString class]]) return @"";
    NSRegularExpression *re = [NSRegularExpression regularExpressionWithPattern:@"100808[0-9a-zA-Z]{20,}" options:0 error:nil];
    NSTextCheckingResult *m = [re firstMatchInString:raw options:0 range:NSMakeRange(0, raw.length)];
    if (!m) return @"";
    return [raw substringWithRange:m.range];
}


// 单条帖子链接 → 取 mid 或 mblogid
static NSString *LSPickPostKey(NSString *raw) {
    if (![raw isKindOfClass:[NSString class]]) return @"";
    NSString *t = [raw stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (t.length == 0) return @"";
    // 纯数字（长 mid）
    if ([t rangeOfCharacterFromSet:[[NSCharacterSet decimalDigitCharacterSet] invertedSet]].location == NSNotFound) {
        return (t.length >= 12) ? t : @"";
    }
    // weibo.com/<uid>/<长数字 mid>
    NSRegularExpression *rd = [NSRegularExpression regularExpressionWithPattern:
        @"weibo\\.com/[0-9]{4,}/+([0-9]{10,})" options:0 error:nil];
    NSTextCheckingResult *md = [rd firstMatchInString:t options:0 range:NSMakeRange(0, t.length)];
    if (md) return [t substringWithRange:[md rangeAtIndex:1]];
    // weibo.com/<uid>/<短码 mblogid>
    NSRegularExpression *rc = [NSRegularExpression regularExpressionWithPattern:
        @"weibo\\.com/[0-9]{4,}/+([A-Za-z][A-Za-z0-9]{4,13})" options:0 error:nil];
    NSTextCheckingResult *mc = [rc firstMatchInString:t options:0 range:NSMakeRange(0, t.length)];
    if (mc) return [t substringWithRange:[mc rangeAtIndex:1]];
    // m.weibo.cn/detail|status/<数字>
    NSRegularExpression *rm = [NSRegularExpression regularExpressionWithPattern:
        @"(?:detail|status)/+([0-9]{10,}|[A-Za-z][A-Za-z0-9]{4,13})" options:0 error:nil];
    NSTextCheckingResult *mm = [rm firstMatchInString:t options:0 range:NSMakeRange(0, t.length)];
    if (mm) return [t substringWithRange:[mm rangeAtIndex:1]];
    // 兜底：取最长的字母数字串（跳过 4~12 位纯数字的 uid）
    NSRegularExpression *rl = [NSRegularExpression regularExpressionWithPattern:
        @"([A-Za-z0-9]{10,})" options:0 error:nil];
    NSTextCheckingResult *ml = [rl firstMatchInString:t options:0 range:NSMakeRange(0, t.length)];
    if (ml) return [t substringWithRange:[ml rangeAtIndex:1]];
    return @"";
}

static NSString *LSPickPlain(NSString *h) {
    if (![h isKindOfClass:[NSString class]]) return @"";
    NSRegularExpression *re = [NSRegularExpression regularExpressionWithPattern:@"<[^>]+>" options:0 error:nil];
    NSString *s = [re stringByReplacingMatchesInString:h options:0 range:NSMakeRange(0, h.length) withTemplate:@" "];
    while ([s rangeOfString:@"  "].location != NSNotFound) s = [s stringByReplacingOccurrencesOfString:@"  " withString:@" "];
    return [s stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}
static NSString *const kPCUA = @"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

static NSString *LSDateKey(void) {
    NSDateFormatter *f = [[NSDateFormatter alloc] init];
    f.dateFormat = @"yyyyMMdd";
    f.timeZone = [NSTimeZone timeZoneWithName:@"Asia/Shanghai"];
    return [f stringFromDate:[NSDate date]];
}

static NSString *LSURLEncode(NSString *s) {
    if (s.length == 0) return @"";
    NSCharacterSet *allowed = [NSCharacterSet characterSetWithCharactersInString:
        @"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_.~"];
    return [s stringByAddingPercentEncodingWithAllowedCharacters:allowed] ?: @"";
}

// 把 WebKit 的 cookie 存成 [{n,v,d}]，请求时按域名现拼，避免 .weibo.cn / .weibo.com 混淆
static NSString *LSCollectCookiesJSON(NSArray<NSHTTPCookie *> *cookies) {
    NSMutableArray *arr = [NSMutableArray array];
    for (NSHTTPCookie *c in cookies) {
        NSString *d = c.domain.lowercaseString;
        if (!([d containsString:@"weibo"] || [d containsString:@"sina"])) continue;
        if (c.name.length == 0) continue;
        [arr addObject:@{ @"n" : c.name, @"v" : (c.value ? c.value : @""), @"d" : (c.domain ? c.domain : @"") }];
    }
    NSData *data = [NSJSONSerialization dataWithJSONObject:arr options:0 error:nil];
    return data ? [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] : @"[]";
}

static NSString *LSRandomFp(void) {
    static NSString *const alpha = @"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    NSMutableString *s = [NSMutableString stringWithCapacity:33];
    for (NSInteger i = 0; i < 33; i++) {
        unichar c = [alpha characterAtIndex:(arc4random_uniform((uint32_t)alpha.length))];
        [s appendString:[NSString stringWithCharacters:&c length:1]];
    }
    return s;
}

static NSString *LSCookieValue(NSString *json, NSString *name) {
    if (json.length == 0 || ![json hasPrefix:@"["]) return nil;
    NSData *d = [json dataUsingEncoding:NSUTF8StringEncoding];
    id obj = d ? [NSJSONSerialization JSONObjectWithData:d options:0 error:nil] : nil;
    if (![obj isKindOfClass:[NSArray class]]) return nil;
    for (id it in (NSArray *)obj) {
        if (![it isKindOfClass:[NSDictionary class]]) continue;
        NSDictionary *c = (NSDictionary *)it;
        if ([[c[@"n"] description] isEqualToString:name]) {
            NSString *v = c[@"v"];
            if ([v isKindOfClass:[NSString class]]) return v;
        }
    }
    return nil;
}

// 从 document.cookie 里抠 XSRF-TOKEN。它是 weibo.com 域的非 HttpOnly cookie，
// 页面里读得到 —— 而 getAllCookies 这条路在这个 App 里经常不回调。
static NSString *LSParseXsrf(NSString *docCookie) {
    if (docCookie.length == 0) return nil;
    for (NSString *kv in [docCookie componentsSeparatedByString:@";"]) {
        NSString *t = [kv stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        if ([t hasPrefix:@"XSRF-TOKEN="]) {
            NSString *v = [t substringFromIndex:11];
            return v.length > 0 ? v : nil;
        }
    }
    return nil;
}

// v1.11: 写接口要求 Cookie 头里的 XSRF-TOKEN 与 X-XSRF-TOKEN 完全一致。
// 旧逻辑是「有就不覆盖」，验证换过 session 后两者对不上 -> invalid csrf token。
// v1.13: 微博 id 合法性（剔除 0 / 空 / 非数字，避免把 data.id 的垃圾值当"转发成功"）
static BOOL LSValidPostId(id v) {
    if (!v) return NO;
    NSString *t = [v description];
    if (t.length < 8) return NO;
    for (NSUInteger i = 0; i < t.length; i++) {
        unichar c = [t characterAtIndex:i];
        if (c < '0' || c > '9') return NO;
    }
    return ![t isEqualToString:@"0"];
}

static NSString *LSReplaceCookieValue(NSString *header, NSString *name, NSString *value) {
    if (header.length == 0 || name.length == 0 || value.length == 0) return header;
    NSString *prefix = [name stringByAppendingString:@"="];
    NSMutableArray *parts = [NSMutableArray array];
    BOOL hit = NO;
    for (NSString *raw in [header componentsSeparatedByString:@";"]) {
        NSString *p = [raw stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        if (p.length == 0) continue;
        if ([p hasPrefix:prefix]) {
            [parts addObject:[prefix stringByAppendingString:value]];
            hit = YES;
        } else {
            [parts addObject:p];
        }
    }
    if (!hit) [parts addObject:[prefix stringByAppendingString:value]];
    return [parts componentsJoinedByString:@"; "];
}

static NSString *LSWithCookie(NSString *json, NSString *name, NSString *value) {
    if (value.length == 0 || name.length == 0) return json;
    NSData *d = [json dataUsingEncoding:NSUTF8StringEncoding];
    id obj = d ? [NSJSONSerialization JSONObjectWithData:d options:0 error:nil] : nil;
    NSMutableArray *arr = [NSMutableArray array];
    if ([obj isKindOfClass:[NSArray class]]) [arr addObjectsFromArray:(NSArray *)obj];
    BOOL hit = NO;
    for (NSInteger i = 0; i < (NSInteger)arr.count; i++) {
        id it = arr[i];
        if (![it isKindOfClass:[NSDictionary class]]) continue;
        if ([[((NSDictionary *)it)[@"n"] description] isEqualToString:name]) {
            NSMutableDictionary *m = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)it];
            m[@"v"] = value;
            arr[i] = m;
            hit = YES;
            break;
        }
    }
    if (!hit) [arr addObject:@{ @"n" : name, @"v" : value, @"d" : @".weibo.com" }];
    NSData *out = [NSJSONSerialization dataWithJSONObject:arr options:0 error:nil];
    return out ? [[NSString alloc] initWithData:out encoding:NSUTF8StringEncoding] : json;
}

static NSString *LSHeaderFromCookiesJSON(NSString *json, NSString *host) {
    if (json.length == 0) return @"";
    if (![json hasPrefix:@"["]) return json;   // 旧格式（只有 .weibo.cn 域），原样用
    NSData *d = [json dataUsingEncoding:NSUTF8StringEncoding];
    id obj = d ? [NSJSONSerialization JSONObjectWithData:d options:0 error:nil] : nil;
    if (![obj isKindOfClass:[NSArray class]]) return @"";
    NSString *h = host.lowercaseString;
    NSMutableArray *parts = [NSMutableArray array];
    for (id it in (NSArray *)obj) {
        if (![it isKindOfClass:[NSDictionary class]]) continue;
        NSDictionary *c = (NSDictionary *)it;
        NSString *dom = [c[@"d"] lowercaseString];
        if (dom.length == 0) continue;
        NSString *bare = [dom hasPrefix:@"."] ? [dom substringFromIndex:1] : dom;
        BOOL match = [h isEqualToString:bare] || [h hasSuffix:[@"." stringByAppendingString:bare]];
        if (!match) continue;
        [parts addObject:[NSString stringWithFormat:@"%@=%@", c[@"n"], c[@"v"]]];
    }
    return [parts componentsJoinedByString:@"; "];
}

// 账号是否自带 weibo.com 的登录态（SUB / SUBP 这类身份 cookie）
static BOOL LSCookieHasWeiboSession(NSString *json) {
    if (![json isKindOfClass:[NSString class]] || ![json hasPrefix:@"["]) return NO;
    NSData *d = [json dataUsingEncoding:NSUTF8StringEncoding];
    id obj = d ? [NSJSONSerialization JSONObjectWithData:d options:0 error:nil] : nil;
    if (![obj isKindOfClass:[NSArray class]]) return NO;
    for (id it in (NSArray *)obj) {
        if (![it isKindOfClass:[NSDictionary class]]) continue;
        NSDictionary *c = (NSDictionary *)it;
        NSString *n = [c[@"n"] description];
        NSString *v = [c[@"v"] description];
        NSString *dom = [[c[@"d"] description] lowercaseString];
        if (n.length == 0 || v.length == 0) continue;
        if ([dom rangeOfString:@"weibo.com"].location == NSNotFound) continue;
        if ([n isEqualToString:@"SUB"] || [n isEqualToString:@"SUBP"]) return YES;
    }
    return NO;
}

// 身份类 cookie：绝不允许从“全机网页会话”借给别的账号，否则身份会串
static BOOL LSCookieIsIdentityKey(NSString *n) {
    static NSSet *keys = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        keys = [NSSet setWithObjects:@"SUB", @"SUBP", @"ALF", @"WBPSESS", @"SRT",
                @"SSOLoginState", @"_T_WM", @"SCF", @"SUHB", nil];
    });
    return [keys containsObject:n];
}

// 只补“账号自己没有的非身份 cookie”，已有值一律不动
static NSString *LSOnlyFillCookies(NSString *accountJSON, NSString *webJSON) {
    if (![accountJSON isKindOfClass:[NSString class]] || ![accountJSON hasPrefix:@"["]) return webJSON;
    NSData *d1 = [accountJSON dataUsingEncoding:NSUTF8StringEncoding];
    NSData *d2 = [webJSON dataUsingEncoding:NSUTF8StringEncoding];
    id a1 = d1 ? [NSJSONSerialization JSONObjectWithData:d1 options:0 error:nil] : nil;
    id a2 = d2 ? [NSJSONSerialization JSONObjectWithData:d2 options:0 error:nil] : nil;
    if (![a1 isKindOfClass:[NSArray class]]) return webJSON;
    if (![a2 isKindOfClass:[NSArray class]]) return accountJSON;
    NSMutableArray *out = [NSMutableArray arrayWithArray:(NSArray *)a1];
    NSMutableSet *have = [NSMutableSet set];
    for (id it in (NSArray *)a1) {
        if (![it isKindOfClass:[NSDictionary class]]) continue;
        NSString *n = [((NSDictionary *)it)[@"n"] description];
        NSString *dom = [[((NSDictionary *)it)[@"d"] description] lowercaseString];
        if (n.length) [have addObject:[NSString stringWithFormat:@"%@|%@", dom, n]];
    }
    for (id it in (NSArray *)a2) {
        if (![it isKindOfClass:[NSDictionary class]]) continue;
        NSDictionary *c = (NSDictionary *)it;
        NSString *n = [c[@"n"] description];
        NSString *dom = [[c[@"d"] description] lowercaseString];
        if (n.length == 0) continue;
        if (LSCookieIsIdentityKey(n)) continue;
        NSString *key = [NSString stringWithFormat:@"%@|%@", dom, n];
        if ([have containsObject:key]) continue;
        [out addObject:c];
        [have addObject:key];
    }
    NSData *od = [NSJSONSerialization dataWithJSONObject:out options:0 error:nil];
    return od ? [[NSString alloc] initWithData:od encoding:NSUTF8StringEncoding] : accountJSON;
}

#pragma mark - 自动过滑块（移植 APK AutoVerifyWorker / AutoSlideVerifier）

// 图片：RGBA8 像素
typedef struct { unsigned char *px; int w; int h; } LSRGBA;

static void LSFreeRGBA(LSRGBA *b) {
    if (b && b->px) { free(b->px); b->px = NULL; }
    if (b) { b->w = 0; b->h = 0; }
}

static LSRGBA LSDecodeImageData(NSData *data) {
    LSRGBA out; out.px = NULL; out.w = 0; out.h = 0;
    if (data.length == 0) return out;
    CGImageSourceRef src = CGImageSourceCreateWithData((__bridge CFDataRef)data, NULL);
    if (!src) return out;
    CGImageRef img = CGImageSourceCreateImageAtIndex(src, 0, NULL);
    CFRelease(src);
    if (!img) return out;
    int w = (int)CGImageGetWidth(img);
    int h = (int)CGImageGetHeight(img);
    if (w <= 0 || h <= 0) { CGImageRelease(img); return out; }
    unsigned char *px = (unsigned char *)calloc((size_t)w * (size_t)h * 4, 1);
    if (!px) { CGImageRelease(img); return out; }
    CGColorSpaceRef cs = CGColorSpaceCreateDeviceRGB();
    CGContextRef ctx = CGBitmapContextCreate(px, (size_t)w, (size_t)h, 8, (size_t)w * 4, cs,
        kCGImageAlphaPremultipliedLast | kCGBitmapByteOrder32Big);
    CGColorSpaceRelease(cs);
    if (!ctx) { free(px); CGImageRelease(img); return out; }
    CGContextDrawImage(ctx, CGRectMake(0, 0, w, h), img);
    CGContextRelease(ctx);
    CGImageRelease(img);
    out.px = px; out.w = w; out.h = h;
    return out;
}

// 灰度：0.299R + 0.587G + 0.114B（同 APK toGray）
static unsigned char *LSGraySub(const unsigned char *rgba, int w, int h,
                                int ox, int oy, int bw, int bh) {
    unsigned char *g = (unsigned char *)calloc((size_t)bw * (size_t)bh, 1);
    if (!g) return NULL;
    for (int y = 0; y < bh; y++) {
        for (int x = 0; x < bw; x++) {
            int si = (((oy + y) * w) + (ox + x)) * 4;
            int v = (rgba[si] * 299 + rgba[si + 1] * 587 + rgba[si + 2] * 114) / 1000;
            g[y * bw + x] = (unsigned char)(v > 255 ? 255 : v);
        }
    }
    return g;
}

// Sobel + 三值化（同 APK canny：>=180 强边，>=60 弱边）
static unsigned char *LSSobelEdges(const unsigned char *gray, int w, int h) {
    unsigned char *out = (unsigned char *)calloc((size_t)w * (size_t)h, 1);
    if (!out) return NULL;
    for (int y = 1; y < h - 1; y++) {
        for (int x = 1; x < w - 1; x++) {
            int i = y * w + x;
            int gx = (gray[i - w + 1] + 2 * gray[i + 1] + gray[i + w + 1])
                   - (gray[i - w - 1] + 2 * gray[i - 1] + gray[i + w - 1]);
            int gy = (gray[i + w - 1] + 2 * gray[i + w] + gray[i + w + 1])
                   - (gray[i - w - 1] + 2 * gray[i - w] + gray[i - w + 1]);
            int m = (int)sqrt((double)(gx * gx + gy * gy));
            out[i] = (m >= 180) ? 255 : (m >= 60 ? 128 : 0);
        }
    }
    return out;
}

// 拼图块非透明边界（同 APK findOpaqueBounds，alpha > 128）
static int LSFindOpaqueBounds(const unsigned char *rgba, int w, int h, int out[4]) {
    int minX = w, minY = h, maxX = -1, maxY = -1;
    for (int y = 0; y < h; y++) {
        for (int x = 0; x < w; x++) {
            if (rgba[((y * w) + x) * 4 + 3] > 128) {
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                if (y > maxY) maxY = y;
            }
        }
    }
    if (maxX < 0) return -1;
    out[0] = minX; out[1] = minY;
    out[2] = maxX - minX + 1; out[3] = maxY - minY + 1;
    return 0;
}

// 归一化互相关（同 APK normalizedCrossCorrelation，mask 内中心化）
static double LSNCC(const unsigned char *img, int imgW,
                    const unsigned char *tpl, int tw, int th,
                    const unsigned char *mask, int gx, int gy) {
    double tsum = 0, isum = 0;
    int n = 0;
    for (int y = 0; y < th; y++) {
        for (int x = 0; x < tw; x++) {
            int ti = y * tw + x;
            if (!mask[ti]) continue;
            tsum += tpl[ti];
            isum += img[(gy + y) * imgW + gx + x];
            n++;
        }
    }
    if (n == 0) return -1.0;
    double tm = tsum / n, im = isum / n, num = 0, tsq = 0, isq = 0;
    for (int y = 0; y < th; y++) {
        for (int x = 0; x < tw; x++) {
            int ti = y * tw + x;
            if (!mask[ti]) continue;
            double a = (double)tpl[ti] - tm;
            double b = (double)img[(gy + y) * imgW + gx + x] - im;
            num += a * b; tsq += a * a; isq += b * b;
        }
    }
    double den = sqrt(tsq) * sqrt(isq);
    return (den > 1e-9) ? (num / den) : -1.0;
}

// 梯度幅值
static double *LSGradMag(const unsigned char *g, int w, int h) {
    double *m = (double *)calloc((size_t)w * (size_t)h, sizeof(double));
    if (!m) return NULL;
    for (int y = 1; y < h - 1; y++) {
        for (int x = 1; x < w - 1; x++) {
            int i = y * w + x;
            int gx = (g[i - w + 1] + 2 * g[i + 1] + g[i + w + 1])
                   - (g[i - w - 1] + 2 * g[i - 1] + g[i + w - 1]);
            int gy = (g[i + w - 1] + 2 * g[i + w] + g[i + w + 1])
                   - (g[i - w - 1] + 2 * g[i - w] + g[i - w + 1]);
            m[i] = sqrt((double)(gx * gx + gy * gy));
        }
    }
    return m;
}

// 幅值 Pearson（对缺口整体变暗不敏感，方向翻转也不影响）
static double LSMatchMag(const double *tm, const double *bm, int tw, int th,
                         int bw, int ox, int oy, const unsigned char *mask) {
    double ts = 0, bs = 0;
    int n = 0;
    for (int y = 0; y < th; y++) {
        for (int x = 0; x < tw; x++) {
            if (!mask[y * tw + x]) continue;
            ts += tm[y * tw + x];
            bs += bm[(oy + y) * bw + ox + x];
            n++;
        }
    }
    if (n < 30) return -1.0;
    ts /= n; bs /= n;
    double num = 0, d1 = 0, d2 = 0;
    for (int y = 0; y < th; y++) {
        for (int x = 0; x < tw; x++) {
            if (!mask[y * tw + x]) continue;
            double a = tm[y * tw + x] - ts;
            double b = bm[(oy + y) * bw + ox + x] - bs;
            num += a * b; d1 += a * a; d2 += b * b;
        }
    }
    double den = sqrt(d1) * sqrt(d2);
    return (den > 1e-9) ? (num / den) : -1.0;
}

// 找缺口：全图 4px 粗搜 → 局部 ±4 精修 → 去重取前 3 个候选 x
static NSArray<NSNumber *> *LSFindGapCandidates(LSRGBA *bg, LSRGBA *jig, double *bestScoreOut) {
    if (bestScoreOut) *bestScoreOut = -2.0;
    int b[4];
    if (LSFindOpaqueBounds(jig->px, jig->w, jig->h, b) != 0) return @[];
    int tx = b[0], ty = b[1], tw = b[2], th = b[3];
    if (tw < 15 || th < 15) return @[];
    unsigned char *bgg = LSGraySub(bg->px, bg->w, bg->h, 0, 0, bg->w, bg->h);
    unsigned char *jgg = LSGraySub(jig->px, jig->w, jig->h, tx, ty, tw, th);
    if (!bgg || !jgg) { free(bgg); free(jgg); return @[]; }
    double *bm = LSGradMag(bgg, bg->w, bg->h);
    double *tm = LSGradMag(jgg, tw, th);
    free(bgg); free(jgg);
    if (!bm || !tm) { free(bm); free(tm); return @[]; }
    unsigned char *mask = (unsigned char *)calloc((size_t)tw * (size_t)th, 1);
    if (!mask) { free(bm); free(tm); return @[]; }
    for (int y = 0; y < th; y++) {
        for (int x = 0; x < tw; x++) {
            mask[y * tw + x] = (jig->px[(((ty + y) * jig->w) + tx + x) * 4 + 3] > 128) ? 1 : 0;
        }
    }
    int xmax = bg->w - tw, ymax = bg->h - th;
    if (xmax <= 0 || ymax <= 0) { free(bm); free(tm); free(mask); return @[]; }

    NSMutableArray *coarse = [NSMutableArray array];
    for (int yy = 0; yy <= ymax; yy += 4) {
        for (int xx = 0; xx <= xmax; xx += 4) {
            double sc = LSMatchMag(tm, bm, tw, th, bg->w, xx, yy, mask);
            [coarse addObject:@{ @"x" : @(xx), @"y" : @(yy), @"s" : @(sc) }];
        }
    }
    NSArray *sorted = [coarse sortedArrayUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b2) {
        double sa = [a[@"s"] doubleValue], sb = [b2[@"s"] doubleValue];
        if (sa > sb) return NSOrderedAscending;
        if (sa < sb) return NSOrderedDescending;
        return NSOrderedSame;
    }];

    NSMutableArray *out = [NSMutableArray array];
    double best = -2.0;
    NSInteger tried = 0;
    for (NSDictionary *c in sorted) {
        if (tried >= 12 || out.count >= 3) break;
        tried++;
        int x0 = [c[@"x"] intValue], y0 = [c[@"y"] intValue];
        double bs = -2.0;
        int bxv = x0;
        for (int yy = (y0 - 4 < 0 ? 0 : y0 - 4); yy <= (y0 + 4 > ymax ? ymax : y0 + 4); yy++) {
            for (int xx = (x0 - 4 < 0 ? 0 : x0 - 4); xx <= (x0 + 4 > xmax ? xmax : x0 + 4); xx++) {
                double s2 = LSMatchMag(tm, bm, tw, th, bg->w, xx, yy, mask);
                if (s2 > bs) { bs = s2; bxv = xx; }
            }
        }
        BOOL dup = NO;
        for (NSDictionary *o in out) {
            if (abs([o[@"x"] intValue] - bxv) <= 20) { dup = YES; break; }
        }
        if (dup) continue;
        [out addObject:@{ @"x" : @(bxv), @"s" : @(bs) }];
        if (bs > best) best = bs;
    }
    free(bm); free(tm); free(mask);
    if (bestScoreOut) *bestScoreOut = best;

    NSMutableArray *xs = [NSMutableArray array];
    for (NSDictionary *o in out) [xs addObject:o[@"x"]];
    return xs;
}

// 轨迹（同 APK genTrack：绝对位置序列，末端补 3 次终点）
static NSArray<NSNumber *> *LSGenTrack(int dist) {
    if (dist <= 0) return @[];
    NSMutableArray *arr = [NSMutableArray array];
    double segEnd = dist * 0.7;
    double r = (double)arc4random_uniform(1000) / 1000.0;
    int n = (int)(dist * (0.98 + r * 0.04));
    if (n < 1) n = 1;
    double walked = 0;
    int i = 0;
    while (i < n) {
        double rr = (double)arc4random_uniform(1000) / 1000.0;
        double step = (i < segEnd) ? (2.5 + rr * 1.5) : (-3.5 - rr * 1.5);
        walked += step * 0.18;
        if (walked < 1.0) walked = 1.0;
        int pos = (int)(walked * 0.18);
        if (pos <= 0) pos = 1;
        i += pos;
        if (i > n) i = n;
        int jit = (int)arc4random_uniform(3) - 1;
        int v = i + jit;
        if (v < 0) v = 0;
        [arr addObject:@(v)];
    }
    int cur = n;
    while (cur != dist) {
        cur += (cur > dist) ? -1 : 1;
        [arr addObject:@(cur)];
    }
    for (int k = 0; k < 3; k++) [arr addObject:@(dist)];
    return arr;
}

// 从风控响应里取验证地址（同 APK extractVerifyUrl）
static NSString *LSVerifyURLFromJSON(NSDictionary *j) {
    if (![j isKindOfClass:[NSDictionary class]]) return nil;
    id sch = j[@"scheme"];
    if ([sch isKindOfClass:[NSString class]] && [((NSString *)sch) hasPrefix:@"http"]) return sch;
    id vals[2] = { j[@"validate"], j[@"data"] };
    for (int i = 0; i < 2; i++) {
        id v = vals[i];
        if (![v isKindOfClass:[NSDictionary class]]) continue;
        id u = ((NSDictionary *)v)[@"verify_url"];
        if ([u isKindOfClass:[NSString class]] && [((NSString *)u) hasPrefix:@"http"]) return u;
        id kv = ((NSDictionary *)v)[@"exception_key"];
        if ([kv isKindOfClass:[NSString class]] && ((NSString *)kv).length > 0) {
            return [@"https://security.weibo.com/verify/index?key=" stringByAppendingString:kv];
        }
    }
    return nil;
}

// v1.10: weibo sometimes only returns a sentence without a verify_url field.
// Treat that as "verification required" too, instead of a plain failure.
static BOOL LSMsgLooksVerify(NSString *m) {
    if (![m isKindOfClass:[NSString class]] || m.length == 0) return NO;
    NSString *low = m.lowercaseString;
    NSArray *keys = @[ @"verify", @"for your safety", @"111002", @"安全验证",
                       @"需要验证", @"身份验证", @"异常请求", @"操作频繁", @"访问过于频繁" ];
    for (NSString *k in keys) {
        if ([low containsString:k]) return YES;
    }
    return NO;
}

// v1.11: weibo says csrf token is invalid -> refresh XSRF-TOKEN and retry once
static BOOL LSMsgLooksCsrf(NSString *m) {
    if (![m isKindOfClass:[NSString class]] || m.length == 0) return NO;
    NSString *low = m.lowercaseString;
    if ([low containsString:@"csrf"]) return YES;
    if ([low containsString:@"invalid token"]) return YES;
    if ([low containsString:@"unauthorized"]) return YES;
    return NO;
}

// 风控/限流判定（对齐 APK RATE_KEYWORDS）
static BOOL LSIsRateLimited(NSString *msg) {
    if (msg.length == 0) return NO;
    NSArray *kws = @[@"系统繁忙", @"请求过于频繁", @"操作频繁", @"稍后再试",
                     @"请稍后再试", @"验证", @"身份", @"异常", @"限制"];
    for (NSString *k in kws) {
        if ([msg containsString:k]) return YES;
    }
    return NO;
}

// 合并 cookie（按 name 覆盖，旧的不丢）
static __attribute__((unused)) NSString *LSMergeCookies(NSString *oldJSON, NSString *newJSON) {
    NSMutableDictionary *map = [NSMutableDictionary dictionary];
    NSArray *src = @[ oldJSON ?: @"", newJSON ?: @"" ];
    for (NSString *one in src) {
        if (![one hasPrefix:@"["]) continue;
        id obj = [NSJSONSerialization JSONObjectWithData:[one dataUsingEncoding:NSUTF8StringEncoding]
                                                options:0 error:nil];
        if (![obj isKindOfClass:[NSArray class]]) continue;
        for (id it in (NSArray *)obj) {
            if (![it isKindOfClass:[NSDictionary class]]) continue;
            NSDictionary *c = (NSDictionary *)it;
            NSString *n = c[@"n"];
            if (![n isKindOfClass:[NSString class]] || n.length == 0) continue;
            map[n] = c;
        }
    }
    NSMutableArray *arr = [NSMutableArray array];
    for (NSString *k in map) [arr addObject:map[k]];
    NSData *d = [NSJSONSerialization dataWithJSONObject:arr options:0 error:nil];
    return d ? [[NSString alloc] initWithData:d encoding:NSUTF8StringEncoding] : (newJSON ?: @"[]");
}

// 反 webdriver 伪装（同 APK STEALTH_JS）
static NSString *const LS_STEALTH_JS =
@"(function(){try{Object.defineProperty(navigator,'webdriver',{get:function(){return false;}});"
"Object.defineProperty(navigator,'platform',{get:function(){return 'Win32';}});"
"Object.defineProperty(navigator,'hardwareConcurrency',{get:function(){return 8;}});"
"Object.defineProperty(navigator,'deviceMemory',{get:function(){return 8;}});"
"if(!navigator.languages||navigator.languages.length===0){"
"Object.defineProperty(navigator,'languages',{get:function(){return ['zh-CN','zh','en'];}});}"
"window.chrome=window.chrome||{runtime:{}};}catch(e){}})();";

// 抓滑块信息（同 APK extractSliderInfo）
static NSString *const LS_EXTRACT_JS =
@"(function(){try{"
"function pick(s){for(var i=0;i<s.length;i++){var e=document.querySelector(s[i]);if(e)return e;}return null;}"
"var bg=pick(['.yidun_popup .yidun_bg-img','.yidun_bg-img','.yidun_bgimg img','[class*=bg-img]',"
"'.geetest_canvas_bg img','.geetest_bg img','[class*=captcha-bg]','img[class*=bg]']);"
"var jg=pick(['.yidun_popup .yidun_jigsaw','.yidun_jigsaw','.yidun_jigsaw-img','[class*=jigsaw]',"
"'.geetest_canvas_slice img','.geetest_slice img','[class*=slice]','img[class*=slice]']);"
"var sl=pick(['.yidun_popup .yidun_slider','.yidun_slider','.yidun_slider__icon','.yidun_control',"
"'.geetest_slider_button','.nc_scale','[class*=slide]','[class*=drag]','[class*=slider]']);"
"if(!bg||!jg||!sl){return JSON.stringify({ok:false,"
"err:'bg='+(!!bg)+' jig='+(!!jg)+' sld='+(!!sl),"
"url:location.href.slice(0,80),title:(document.title||'').slice(0,40)});}"
"var br=bg.getBoundingClientRect();var sr=sl.getBoundingClientRect();"
"return JSON.stringify({ok:true,bgUrl:bg.src,jigsawUrl:jg.src,"
"bgLeft:Math.round(br.left),bgTop:Math.round(br.top),bgWidth:Math.round(br.width),bgHeight:Math.round(br.height),"
"sliderLeft:Math.round(sr.left+sr.width/2),sliderTop:Math.round(sr.top+sr.height/2),sliderWidth:Math.round(sr.width)});"
"}catch(e){return JSON.stringify({ok:false,err:String(e)});}})();";

// 拖动（同 APK buildDragJs：20ms 一步 + 末端 3 次微调 + 250ms/150ms 停顿）
static NSString *LSBuildDragJs(NSArray *track, int sx, int sy) {
    NSString *tr = [track componentsJoinedByString:@","];
    return [NSString stringWithFormat:
    @"(function(){var track=[%@];var startX=%d,startY=%d;"
    "var slider=document.querySelector('.yidun_slider')||document.querySelector('.yidun_control')||document.querySelector('[class*=slider]');"
    "if(!slider)return 'no-slider';"
    "function fM(t,x,y){var e=new MouseEvent(t,{bubbles:true,cancelable:true,view:window,clientX:x,clientY:y,screenX:x,screenY:y,button:0,buttons:(t==='mouseup'?0:1),detail:1});slider.dispatchEvent(e);}"
    "function fP(t,x,y){try{var e=new PointerEvent(t,{bubbles:true,cancelable:true,view:window,clientX:x,clientY:y,pointerId:1,pointerType:'mouse',isPrimary:true,button:0,buttons:(t==='pointerup'?0:1),pressure:(t==='pointerup'?0:0.5)});slider.dispatchEvent(e);}catch(e){}}"
    "fM('mouseover',startX,startY);fM('mousemove',startX,startY);fP('pointerdown',startX,startY);fM('mousedown',startX,startY);"
    "var endX=startX+track[track.length-1];var i=0;"
    "var timer=setInterval(function(){"
    "if(i>=track.length){clearInterval(timer);"
    "fM('mousemove',endX-2,startY);fP('pointermove',endX-2,startY);"
    "fM('mousemove',endX-1,startY);fP('pointermove',endX-1,startY);"
    "fM('mousemove',endX,startY);fP('pointermove',endX,startY);"
    "setTimeout(function(){fM('mousemove',endX,startY);fP('pointermove',endX,startY);"
    "setTimeout(function(){fM('mouseup',endX,startY);fP('pointerup',endX,startY);fM('click',endX,startY);},150);},250);return;}"
    "var x=startX+track[i];var jy=startY+(Math.random()*2-1);"
    "fM('mousemove',x,jy);fP('pointermove',x,jy);i++;},20);return 'ok';})();",
    tr, sx, sy];
}

#pragma mark - 验证执行器

@interface LSVerifyRunner : NSObject <WKNavigationDelegate>
@property (nonatomic, strong) WKWebView *web;
@property (nonatomic, strong) WKWebViewConfiguration *cfg;
@property (nonatomic, strong) UIWindow *host;
@property (nonatomic, copy) NSString *verifyURL;
@property (nonatomic, copy) NSString *cookiesJSON;
@property (nonatomic, copy) NSString *accountName;
@property (nonatomic, assign) NSInteger attempt;
@property (nonatomic, assign) BOOL finished;
@property (nonatomic, assign) BOOL manualTried;
@property (nonatomic, assign) BOOL manualBroken;
// v1.10: only after really standing on the verify page may leaving it count as pass
@property (nonatomic, assign) BOOL sawVerify;
// v1.12: 这次验证是给哪个动作用的（checkin / repost / comment / publish）
@property (nonatomic, copy) NSString *probeKind;
@property (nonatomic, assign) BOOL replayTried;
@property (nonatomic, assign) NSInteger replayDeadline;
@property (nonatomic, assign) BOOL scanOnly;
@property (nonatomic, assign) BOOL scanTried;
@property (nonatomic, assign) NSInteger scanDeadline;
@property (nonatomic, assign) NSInteger probeDeadline;
@property (nonatomic, assign) NSInteger manualDeadline;
@property (nonatomic, strong) UIView *mvTop;
@property (nonatomic, strong) UIView *mvBottom;
@property (nonatomic, strong) UIButton *mvReopen;
@property (nonatomic, assign) BOOL needLogin;
@property (nonatomic, copy) void (^onNeedLogin)(void);
@property (nonatomic, strong) NSArray *candX;
@property (nonatomic, assign) NSInteger candIdx;
@property (nonatomic, strong) NSDictionary *sliderInfo;
@property (nonatomic, assign) int bgPixelWidth;
@property (nonatomic, copy) void (^log)(NSString *kind, NSString *text);
@property (nonatomic, copy) void (^onEnd)(void);
@property (nonatomic, copy) void (^completion)(BOOL ok, NSString *cookiesJSON);
- (void)start;
@end

@implementation LSVerifyRunner

- (void)start {
    self.attempt = 0;
    self.finished = NO;
    self.cfg = [[WKWebViewConfiguration alloc] init];
    NSArray *cks = [self parsedCookies];
    BOOL haveWeiboIdentity = NO;
    for (id it in cks) {
        if (![it isKindOfClass:[NSDictionary class]]) continue;
        NSDictionary *cc = (NSDictionary *)it;
        NSString *cn = [cc[@"n"] description];
        NSString *cv = [cc[@"v"] description];
        NSString *cd = [[cc[@"d"] description] lowercaseString];
        if (cn.length == 0 || cv.length == 0) continue;
        if ([cd rangeOfString:@"weibo.com"].location == NSNotFound) continue;
        if ([cn isEqualToString:@"SUB"] || [cn isEqualToString:@"SUBP"]) {
            haveWeiboIdentity = YES;
            break;
        }
    }
    self.cfg.websiteDataStore = haveWeiboIdentity
        ? [WKWebsiteDataStore nonPersistentDataStore]
        : [WKWebsiteDataStore defaultDataStore];
    // 视口必须接近真机屏幕：太小会把易盾弹窗布局挤扁，坐标全错
    UIWindow *win0 = UIApplication.sharedApplication.windows.firstObject;
    CGRect vf = win0 ? win0.bounds : CGRectMake(0, 0, 390, 844);
    // 安卓端 webview 也是不可见的，这里用最小可见 alpha 保证 WebKit 继续渲染
    self.web = [[WKWebView alloc] initWithFrame:vf configuration:self.cfg];
    self.web.navigationDelegate = self;
    self.web.alpha = 0.01;
    self.web.userInteractionEnabled = NO;
    self.web.opaque = NO;
    self.web.backgroundColor = [UIColor clearColor];
    self.web.scrollView.scrollEnabled = NO;
    self.host = win0;
    if (win0) {
        [win0 addSubview:self.web];
        [win0 sendSubviewToBack:self.web];
    }

    // v1.07：验证器不再借用整机共享登录态。
    // 本号自己的 cookie 里有 weibo.com 身份时，用一个临时会话、只装本号的 cookie；
    // 只有 cookie 里确实没有身份时才退回共享会话，并在日志里说明，不静默串号。
    if (!haveWeiboIdentity) {
        [self logLine:@"info" text:@"这个号缺 weibo.com 登录态，验证器退回共享会话打开"];
        [self loadVerifyPage];
        return;
    }
    [self logLine:@"info" text:@"验证器用本号独立会话打开（不碰全局登录态）"];
    WKHTTPCookieStore *store = self.cfg.websiteDataStore.httpCookieStore;
    if (cks.count == 0) {
        [self loadVerifyPage];
        return;
    }
    __block NSInteger left = (NSInteger)cks.count;
    __block BOOL loaded = NO;
    __weak typeof(self) ws = self;
    for (id it in cks) {
        if (![it isKindOfClass:[NSDictionary class]]) { left -= 1; continue; }
        NSDictionary *c = (NSDictionary *)it;
        NSMutableDictionary *props = [NSMutableDictionary dictionary];
        props[NSHTTPCookieName] = c[@"n"];
        props[NSHTTPCookieValue] = c[@"v"] ?: @"";
        props[NSHTTPCookieDomain] = c[@"d"];
        props[NSHTTPCookiePath] = @"/";
        NSHTTPCookie *ck = [NSHTTPCookie cookieWithProperties:props];
        if (!ck) { left -= 1; continue; }
        [store setCookie:ck completionHandler:^{
            left -= 1;
            if (left <= 0 && !loaded) {
                loaded = YES;
                LSVerifyRunner *s = ws;
                [s loadVerifyPage];
            }
        }];
    }
    if (left <= 0 && !loaded) { loaded = YES; [self loadVerifyPage]; }
}

- (void)dealloc {
    // 兜底：任何路径下被释放，都不能把隐形 WebView 和手动验证面板留在 window 上
    [self destroyManualUI];
    _web.userInteractionEnabled = NO;
    _web.navigationDelegate = nil;
    [_web removeFromSuperview];
    _web = nil;
}

- (NSArray *)parsedCookies {
    if (![self.cookiesJSON hasPrefix:@"["]) return @[];
    id obj = [NSJSONSerialization JSONObjectWithData:[self.cookiesJSON dataUsingEncoding:NSUTF8StringEncoding]
                                            options:0 error:nil];
    return [obj isKindOfClass:[NSArray class]] ? (NSArray *)obj : @[];
}

- (void)loadVerifyPage {
    if (self.verifyURL.length > 0) { [self loadVerifyURL:self.verifyURL]; return; }
    // 不再直接打开 verify/index?key=... —— 那个 key 拼出来的地址微博已经不认了。
    // 先打开带完整登录态的超话页，再由页面内重放签到请求，让微博自己下发验证页。
    NSString *u = [NSString stringWithFormat:@"https://weibo.com/p/%@", kSuperId];
    [self logLine:@"info" text:@"正在打开超话页，让微博自己给出验证…"];
    NSMutableURLRequest *r = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:u]];
    [r setValue:@"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        forHTTPHeaderField:@"User-Agent"];
    [r setValue:@"zh-CN,zh;q=0.9" forHTTPHeaderField:@"Accept-Language"];
    r.timeoutInterval = 20.0;
    [self.web loadRequest:r];
}

- (void)loadVerifyURL:(NSString *)url {
    if (![url isKindOfClass:[NSString class]] || url.length == 0) return;
    NSRange rng = [url rangeOfString:@"?"];
    NSString *shown = (rng.location != NSNotFound && rng.location > 40)
        ? [url substringToIndex:rng.location]
        : (url.length > 60 ? [url substringToIndex:60] : url);
    [self logLine:@"info" text:[NSString stringWithFormat:@"微博给出验证页：%@", shown]];
    NSMutableURLRequest *r = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    [r setValue:@"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        forHTTPHeaderField:@"User-Agent"];
    [r setValue:@"zh-CN,zh;q=0.9" forHTTPHeaderField:@"Accept-Language"];
    [r setValue:[NSString stringWithFormat:@"https://weibo.com/p/%@", kSuperId] forHTTPHeaderField:@"Referer"];
    r.timeoutInterval = 20.0;
    [self.web loadRequest:r];
}

- (BOOL)textLooksBroken:(NSString *)t {
    if (![t isKindOfClass:[NSString class]] || t.length == 0) return NO;
    NSArray *keys = @[ @"系统繁忙", @"请稍后再试", @"请稍后", @"出错", @"错误", @"异常",
                       @"访问受限", @"无法访问", @"验证失败", @"操作频繁" ];
    for (NSString *k in keys) {
        if ([t containsString:k]) return YES;
    }
    return NO;
}

// 打开超话页却落到微博登录页 —— 说明这个号在微博那边已经掉登录了。
// 这时候不是滑块的问题，滑一百次也没用，必须重新扫码。
- (BOOL)textLooksLogin:(NSString *)t {
    if (![t isKindOfClass:[NSString class]] || t.length == 0) return NO;
    NSArray *keys = @[ @"请先登录", @"扫码登录", @"手机号登录", @"密码登录", @"账号登录",
                       @"登录微博", @"注册微博", @"新浪微博登录", @"立即登录" ];
    for (NSString *k in keys) {
        if ([t containsString:k]) return YES;
    }
    if ([t containsString:@"登录"] && [t containsString:@"注册"]) return YES;
    return NO;
}

// 判定为「掉登录」后统一收口：改按钮文案、写清楚的日志，不再让用户白等滑块
- (void)markNeedLogin {
    if (self.needLogin) return;
    self.needLogin = YES;
    self.manualTried = YES;
    [self logLine:@"bad" text:@"❌ 打开后是微博登录页 —— 这个号已经掉登录了，不是滑块没过"];
    [self logLine:@"info" text:@"可以就在这个页面上重新登录（扫码/输密码），登完点底部蓝色按钮；不想登就点「重新登录」回账号页"];
    if (self.mvReopen) {
        [self.mvReopen setTitle:@"重新登录" forState:UIControlStateNormal];
    }
}

- (BOOL)onVerifyDomain {
    NSString *h = self.web.URL.host.lowercaseString ?: @"";
    return [h containsString:@"security.weibo.com"] || [h containsString:@"verify"];
}

- (BOOL)kindIsCheckin {
    return (self.probeKind.length == 0 || [self.probeKind isEqualToString:@"checkin"]);
}

- (void)runScan {
    NSString *js =
      @"(function(){window.__LSS__=null;"
       "var e=performance.getEntriesByType('resource').map(function(x){return x.name;});"
       "var api='';for(var i=0;i<e.length;i++){if(e[i].indexOf('ajax_proxy/chaohua/page')>=0){api=e[i];break;}}"
       "if(!api){window.__LSS__='NO_API|'+e.slice(0,6).join(' || ');return;}"
       "fetch(api,{credentials:'include'}).then(function(r){return r.text();}).then(function(t){"
       "var keys=[];try{var j=JSON.parse(t);keys=Object.keys(j);"
       "if(j.data&&typeof j.data==='object'){var d=Object.keys(j.data);for(var k=0;k<d.length;k++){keys.push('data.'+d[k]);}}}catch(x){}"
       "var low=t.toLowerCase();var si=low.indexOf('state');var ci=t.indexOf('签到状态');"
       "window.__LSS__='API='+api+'\\nKEYS='+keys.join(',')"
       "+'\\nSTATE@'+si+':'+(si>=0?t.substr(Math.max(0,si-80),220):'none')"
       "+'\\nCN@'+ci+':'+(ci>=0?t.substr(Math.max(0,ci-80),220):'none');})"
       ".catch(function(x){window.__LSS__='ERR:'+x;});})();";
    __weak typeof(self) ws = self;
    [self.web evaluateJavaScript:js completionHandler:^(id r, NSError *e) {
        LSVerifyRunner *s = ws;
        if (!s) return;
        s.scanDeadline = 12;
        [s pollScan];
    }];
}

- (void)pollScan {
    if (self.finished) return;
    __weak typeof(self) ws = self;
    [self.web evaluateJavaScript:@"window.__LSS__" completionHandler:^(id res, NSError *e) {
        LSVerifyRunner *s = ws;
        if (!s || s.finished) return;
        NSString *t = [res isKindOfClass:[NSString class]] ? (NSString *)res : @"";
        if (t.length == 0) {
            s.scanDeadline -= 1;
            if (s.scanDeadline <= 0) {
                [s logLine:@"bad" text:@"扫描超时：页面没跑出数据"];
                [s finishOK:YES];
                return;
            }
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)),
                           dispatch_get_main_queue(), ^{
                LSVerifyRunner *s2 = ws;
                if (s2) [s2 pollScan];
            });
            return;
        }
        [s logLine:@"info" text:t];
        [s finishOK:YES];
    }];
}

- (void)logLine:(NSString *)kind text:(NSString *)text {
    if (self.log) self.log(kind, text);
}

- (void)finishOK:(BOOL)ok {
    if (self.finished) return;
    self.finished = YES;
    [self destroyManualUI];
    self.web.userInteractionEnabled = NO;
    [self.web removeFromSuperview];
    self.web.navigationDelegate = nil;
    // 立刻通知外部解除占用，避免 60 秒兜底和正常结束同时生效
    if (self.onEnd) self.onEnd();
    if (!ok) {
        if (self.completion) self.completion(NO, nil);
        return;
    }
    // 读取 cookie 是异步的，如果 WebKit 迟迟不回，就用现有 cookie 先把流程放行
    __block BOOL fired = NO;
    NSString *baseCk = self.cookiesJSON ?: @"[]";
    // 先把回调抓在本地，即使这个 runner 已被释放也能把结果交出去
    void (^cb)(BOOL, NSString *) = self.completion;
    void (^emit)(NSString *) = ^(NSString *cj) {
        if (fired) return;
        fired = YES;
        if (cb) cb(YES, cj);
    };
    __weak typeof(self) wsx = self;
    // 发帖要 X-XSRF-TOKEN，评论/转发不校验。页面刚在微博里跑过请求，
    // 这里的 XSRF-TOKEN 是最新的，比账号里存的那份靠谱。
    [self.web evaluateJavaScript:@"document.cookie||''" completionHandler:^(id res, NSError *e) {
        LSVerifyRunner *sx = wsx;
        NSString *docCk = [res isKindOfClass:[NSString class]] ? (NSString *)res : @"";
        NSString *xsrf = LSParseXsrf(docCk);
        NSString *merged1 = xsrf.length ? LSWithCookie(baseCk, @"XSRF-TOKEN", xsrf) : baseCk;
        if (xsrf.length) [sx logLine:@"info" text:@"已补上最新 XSRF-TOKEN"];
        if (!sx) { emit(merged1); return; }
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{ emit(merged1); });
        [[[sx.cfg websiteDataStore] httpCookieStore] getAllCookies:^(NSArray<NSHTTPCookie *> *cookies) {
            NSString *fresh = LSCollectCookiesJSON(cookies);
            // v1.05：这里以前用 LSMergeCookies 把“全机网页会话”的 cookie 整个并进账号，
            // 同名身份 cookie（SUB/SUBP/ALF…）被网页里那个号顶掉。于是验证通过后重发的签到
            // 实际是替网页里那个号签的：服务端回“已签到”，界面绿字，本号根本没签上。
            // 现在只补账号缺的非身份 cookie，身份一律用账号自己的。
            NSString *merged = LSOnlyFillCookies(merged1, fresh);
            emit(merged.length > 0 ? merged : merged1);
        }];
    }];
}

- (void)fail {
    if (self.finished) return;
    if (self.manualTried) {
        [self logLine:@"bad" text:@"❌ 手动验证也没过"];
        [self finishOK:NO];
        return;
    }
    self.manualTried = YES;
    [self logLine:@"info" text:@"👉 自动认不出，把验证页显示出来，手动拖一下就行"];
    [self showForManual];
}

#pragma mark - 手动验证面板（原生按钮，不依赖微博页面里的按钮）

- (void)mvReloadTapped {
    [self logLine:@"info" text:@"🔄 正在重新加载验证页…"];
    [self.web reload];
}

- (void)mvReopenTapped {
    if (self.needLogin) {
        [self logLine:@"info" text:@"➡️ 去账号页重新扫码登录这个号"];
        if (self.onNeedLogin) self.onNeedLogin();
        [self finishOK:NO];
        return;
    }
    [self logLine:@"info" text:@"🔄 正在重新打开超话页，让微博重新下发验证…"];
    [self loadFreshVerify];
}

- (void)mvSkipTapped {
    [self logLine:@"bad" text:@"⏭ 已手动跳过这个号"];
    [self finishOK:NO];
}

- (void)mvDoneTapped {
    [self checkManualDone];
}

- (void)checkManualDone {
    if (self.finished) return;
    self.manualDeadline = 600;
    __weak typeof(self) ws = self;
    NSString *js = @"((document.title||'')+' '+((document.body&&document.body.innerText)||'')).slice(0,120)";
    [self.web evaluateJavaScript:js completionHandler:^(id res, NSError *e) {
        LSVerifyRunner *s = ws;
        if (!s || s.finished) return;
        NSString *txt = [res isKindOfClass:[NSString class]] ? (NSString *)res : @"";
        if ([s textLooksLogin:txt]) {
            [s markNeedLogin];
            return;
        }
        if ([s textLooksBroken:txt]) {
            [s logLine:@"bad" text:@"页面还是微博的错误页，先点「重开验证」，或等 1 分钟再点「刷新」"];
            return;
        }
        if ([s onVerifyDomain]) {
            [s logLine:@"bad" text:@"还停在验证页，滑块好像没过——滑完再点一次这个按钮"];
            return;
        }
        if (![s kindIsCheckin] && !s.sawVerify) {
            // v1.12: 页面里从来没出现过验证页，等于这次没真验。
            // 别再拿旧登录态去赌一次、也别让用户以为成功了。
            [s logLine:@"bad" text:@"页面里没出现验证页，这次等于没验证——这个号被微博只拦接口，去微博 App 手动发一条过掉验证再回来"];
            [s finishOK:NO];
            return;
        }
        [s logLine:@"ok" text:@"✓ 验证通过（手动）"];
        [s finishOK:YES];
    }];
}

- (void)loadFreshVerify {
    NSString *u = [NSString stringWithFormat:@"https://weibo.com/p/%@", kSuperId];
    NSMutableURLRequest *r = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:u]];
    [r setValue:@"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        forHTTPHeaderField:@"User-Agent"];
    [r setValue:@"zh-CN,zh;q=0.9" forHTTPHeaderField:@"Accept-Language"];
    r.timeoutInterval = 20.0;
    [self.web loadRequest:r];
}

- (void)buildManualUI {
    if (self.mvTop) return;
    UIWindow *win = self.host;
    if (!win) return;
    CGRect b = win.bounds;
    CGFloat topH = 44.0;
    CGFloat botH = 34.0;
    if (@available(iOS 11.0, *)) {
        topH = win.safeAreaInsets.top > 0 ? win.safeAreaInsets.top : 44.0;
        botH = win.safeAreaInsets.bottom > 0 ? win.safeAreaInsets.bottom : 34.0;
    }
    UIColor *brand = [UIColor colorWithRed:0.23 green:0.47 blue:0.95 alpha:1.0];

    UIView *top = [[UIView alloc] initWithFrame:CGRectMake(0, 0, b.size.width, topH + 80)];
    top.backgroundColor = [UIColor colorWithWhite:0.10 alpha:0.96];

    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(16, topH + 6, b.size.width - 32, 22)];
    title.text = [NSString stringWithFormat:@"手动验证 · %@", (self.accountName.length ? self.accountName : @"当前账号")];
    title.font = [UIFont boldSystemFontOfSize:15];
    title.textColor = [UIColor whiteColor];
    [top addSubview:title];

    UIButton *reload = [UIButton buttonWithType:UIButtonTypeSystem];
    reload.frame = CGRectMake(16, topH + 36, 80, 38);
    [reload setTitle:@"刷新" forState:UIControlStateNormal];
    [reload setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    reload.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.18];
    reload.layer.cornerRadius = 8;
    reload.titleLabel.font = [UIFont systemFontOfSize:15];
    [reload addTarget:self action:@selector(mvReloadTapped) forControlEvents:UIControlEventTouchUpInside];
    [top addSubview:reload];

    UIButton *reopen = [UIButton buttonWithType:UIButtonTypeSystem];
    reopen.frame = CGRectMake(104, topH + 36, 100, 38);
    [reopen setTitle:(self.needLogin ? @"重新登录" : @"重开验证") forState:UIControlStateNormal];
    [reopen setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    reopen.backgroundColor = brand;
    reopen.layer.cornerRadius = 8;
    reopen.titleLabel.font = [UIFont systemFontOfSize:15];
    [reopen addTarget:self action:@selector(mvReopenTapped) forControlEvents:UIControlEventTouchUpInside];
    self.mvReopen = reopen;
    [top addSubview:reopen];

    UIButton *skip = [UIButton buttonWithType:UIButtonTypeSystem];
    skip.frame = CGRectMake(212, topH + 36, 68, 38);
    [skip setTitle:@"跳过" forState:UIControlStateNormal];
    [skip setTitleColor:[UIColor colorWithWhite:0.72 alpha:1.0] forState:UIControlStateNormal];
    skip.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.12];
    skip.layer.cornerRadius = 8;
    skip.titleLabel.font = [UIFont systemFontOfSize:14];
    [skip addTarget:self action:@selector(mvSkipTapped) forControlEvents:UIControlEventTouchUpInside];
    [top addSubview:skip];

    UIView *bot = [[UIView alloc] initWithFrame:CGRectMake(0, b.size.height - botH - 90, b.size.width, botH + 90)];
    bot.backgroundColor = [UIColor colorWithWhite:0.10 alpha:0.96];

    UILabel *tip = [[UILabel alloc] initWithFrame:CGRectMake(16, 8, b.size.width - 32, 18)];
    tip.text = @"滑完滑块 / 点完验证后，点下面的蓝色按钮继续";
    tip.font = [UIFont systemFontOfSize:12];
    tip.textColor = [UIColor colorWithWhite:0.75 alpha:1.0];
    [bot addSubview:tip];

    UIButton *done = [UIButton buttonWithType:UIButtonTypeSystem];
    done.frame = CGRectMake(16, 30, b.size.width - 32, 48);
    [done setTitle:@"我已完成验证，继续跑" forState:UIControlStateNormal];
    [done setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    done.backgroundColor = brand;
    done.layer.cornerRadius = 10;
    done.titleLabel.font = [UIFont boldSystemFontOfSize:16];
    [done addTarget:self action:@selector(mvDoneTapped) forControlEvents:UIControlEventTouchUpInside];
    [bot addSubview:done];

    [win addSubview:top];
    [win addSubview:bot];
    self.mvTop = top;
    self.mvBottom = bot;
}

- (void)destroyManualUI {
    if (self.mvTop) { [self.mvTop removeFromSuperview]; self.mvTop = nil; }
    if (self.mvBottom) { [self.mvBottom removeFromSuperview]; self.mvBottom = nil; }
    self.mvReopen = nil;
}

// 页面上的跳转按钮（weibo:// 之类）在 WKWebView 里点了没反应，这里接管掉
- (void)webView:(WKWebView *)webView
    decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction
                    decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler {
    NSURL *u = navigationAction.request.URL;
    NSString *sch = u.scheme.lowercaseString;
    BOOL httpLike = (sch.length == 0
                     || [sch isEqualToString:@"http"] || [sch isEqualToString:@"https"]
                     || [sch isEqualToString:@"about"] || [sch isEqualToString:@"file"]
                     || [sch isEqualToString:@"data"]);
    if (!httpLike) {
        decisionHandler(WKNavigationActionPolicyCancel);
        if (self.needLogin) {
            [self logLine:@"info" text:@"登录流程里的跳转按钮已拦掉，直接在页面上扫码/输密码就行"];
            return;
        }
        [self logLine:@"info" text:@"这个跳转按钮打不开，已改为重新拉取验证页"];
        if (!self.finished) [self loadFreshVerify];
        return;
    }
    decisionHandler(WKNavigationActionPolicyAllow);
}

// 自动识别失败时，把隐形 WebView 亮出来让用户自己拖，拖过自动续跑
- (void)showForManual {
    if (self.finished) return;
    [self revealWebForUser];
    [self buildManualUI];
    self.manualDeadline = 600;
    [self pollManual];
}

- (void)revealWebForUser {
    self.web.alpha = 1.0;
    self.web.opaque = YES;
    self.web.backgroundColor = [UIColor whiteColor];
    self.web.userInteractionEnabled = YES;
    self.web.scrollView.scrollEnabled = YES;
    if (self.host) [self.host bringSubviewToFront:self.web];
}

// 微博返回的是错误页（验证链接已失效）时，不再静默跳过。
// 页面照样亮出来，用户可以点「返回」或下拉刷新试试，说不定能拿到新链接。
- (void)showBrokenManual {
    if (self.finished) return;
    self.manualBroken = YES;
    self.manualTried = YES;
    [self logLine:@"bad" text:@"👉 验证页打不开（微博返回错误页），已弹出手动验证面板"];
    [self logLine:@"info" text:@"先点顶部「重开验证」；页面能出来就滑一下，滑完点底部蓝色按钮"];
    [self revealWebForUser];
    [self buildManualUI];
    self.manualDeadline = 600;
    [self pollManual];
}

- (void)pollManual {
    if (self.finished) return;
    __weak typeof(self) ws = self;
    NSString *js = @"((document.title||'')+' '+((document.body&&document.body.innerText)||'')).slice(0,120)";
    [self.web evaluateJavaScript:js completionHandler:^(id res, NSError *e) {
        LSVerifyRunner *s = ws;
        if (!s || s.finished) return;
        NSString *txt = [res isKindOfClass:[NSString class]] ? (NSString *)res : @"";
        // 微博验证服务返回「系统繁忙 / 请稍后」时，域名可能已经离开了验证页，
        // 光看域名会误判成「验证通过」，必须先看页面内容。
        if ([s textLooksLogin:txt]) {
            [s markNeedLogin];
        } else if ([s textLooksBroken:txt]) {
            if (!s.manualBroken) {
                NSString *show = txt.length > 30 ? [txt substringToIndex:30] : txt;
                [s logLine:@"bad" text:[NSString stringWithFormat:@"微博返回「%@」，这个号先跳过，过一会儿再试", show]];
                [s finishOK:NO];
                return;
            }
            // 已经在错误页展示模式：继续倒计时，让用户自己刷新试
        } else if ([s onVerifyDomain]) {
            // 页面真的停在验证页过，才允许后面「离开验证页 = 验通过」的推断
            s.sawVerify = YES;
        } else if (s.sawVerify) {
            [s logLine:@"ok" text:@"✓ 验证通过（手动）"];
            [s finishOK:YES];
            return;
        } else {
            // v1.09 这里会把「从没真进过验证页」误判成验证通过，
            // 然后拿旧 cookie 再试一次 -> 必失败。v1.10 起只等用户点蓝色按钮。
        }
        s.manualDeadline -= 1;
        if (s.manualDeadline > 0 && (600 - s.manualDeadline) % 30 == 0) {
            [s logLine:@"info" text:@"还在等你手动验证：页面打不开就点顶部「重开验证」，重新下发一次再滑"];
        }
        if (s.manualDeadline <= 0) {
            [s logLine:@"bad" text:@"⌛ 手动验证超时"];
            [s finishOK:NO];
            return;
        }
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            LSVerifyRunner *s2 = ws;
            if (s2) [s2 pollManual];
        });
    }];
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation {
    if (self.finished) return;
    if (self.scanOnly) {
        if (self.scanTried) return;
        self.scanTried = YES;
        __weak typeof(self) ws0 = self;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(4.0 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            LSVerifyRunner *s0 = ws0;
            if (s0) [s0 runScan];
        });
        return;
    }
    __weak typeof(self) ws = self;
    if ([self onVerifyDomain]) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            LSVerifyRunner *s = ws;
            if (s) [s attemptLoop];
        });
        return;
    }
    if (self.replayTried) return;
    self.replayTried = YES;
    // v1.12: 写操作（转发/评论/发帖）不能用签到探针自证「不需要验证」：
    // 签到能过不代表转发能发，重放签到只会制造一次假通过。
    if (![self kindIsCheckin] && !self.sawVerify) {
        [self logLine:@"bad" text:@"这次微博没下发验证页（只回了一句 verify），先把页面亮给你处理"];
        [self manualFallback];
        return;
    }
    NSString *jsT = @"((document.title||'')+' '+((document.body&&document.body.innerText)||'')).slice(0,100)";
    [self.web evaluateJavaScript:jsT completionHandler:^(id res, NSError *e) {
        LSVerifyRunner *s = ws;
        if (!s || s.finished) return;
        NSString *txt = [res isKindOfClass:[NSString class]] ? (NSString *)res : @"";
        if ([s textLooksLogin:txt]) {
            [s logLine:@"bad" text:@"打开后是微博登录页 —— 这个号已掉登录（不是滑块问题），跳过"];
            [s logLine:@"info" text:@"去「账号」页给它重新扫码，登好再跑这批任务"];
            [s finishOK:NO];
            return;
        }
        if ([txt rangeOfString:@"出错了"].location != NSNotFound
            || [txt rangeOfString:@"111002"].location != NSNotFound
            || [s textLooksBroken:txt]) {
            [s logLine:@"bad" text:@"微博返回报错页，这个号跳过，其余账号继续"];
            [s finishOK:NO];
            return;
        }
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.2 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            LSVerifyRunner *s2 = ws;
            if (s2) [s2 replayCheckin];
        });
    }];
}

- (void)replayCheckin {
    if (self.finished) return;
    NSString *tpl =
      @"(function(){window.__LSV_RESULT__=null;"
       "var ua=navigator.userAgent;"
       "fetch('https://weibo.com/ajax_proxy/chaohua/page/checkin',{method:'POST',credentials:'include',"
       "headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With':'XMLHttpRequest'},"
       "body:'scene_id=pc_checkin&page_id=%@&timezone=Asia%%2FShanghai&lang=zh-CN&plat=Win32&ua='+encodeURIComponent(ua)}"
       ").then(function(r){return r.text();}).then(function(t){window.__LSV_RESULT__=t;})"
       ".catch(function(e){window.__LSV_RESULT__='ERR:'+e;});})();";
    NSString *js = [NSString stringWithFormat:tpl, kSuperId];
    __weak typeof(self) ws = self;
    [self.web evaluateJavaScript:js completionHandler:^(id res, NSError *e) {
        LSVerifyRunner *s = ws;
        if (!s) return;
        s.replayDeadline = 20;
        [s pollReplay];
    }];
}

- (void)pollReplay {
    if (self.finished) return;
    __weak typeof(self) ws = self;
    [self.web evaluateJavaScript:@"window.__LSV_RESULT__" completionHandler:^(id res, NSError *e) {
        LSVerifyRunner *s = ws;
        if (!s || s.finished) return;
        NSString *t = [res isKindOfClass:[NSString class]] ? (NSString *)res : @"";
        if (t.length == 0) {
            s.replayDeadline -= 1;
            if (s.replayDeadline <= 0) {
                [s logLine:@"bad" text:@"微博没给出反馈，先显示页面让你手动处理"];
                [s manualFallback];
                return;
            }
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)),
                           dispatch_get_main_queue(), ^{
                LSVerifyRunner *s2 = ws;
                if (s2) [s2 pollReplay];
            });
            return;
        }
        [s handleReplayBody:t];
    }];
}

- (void)handleReplayBody:(NSString *)t {
    if ([t hasPrefix:@"ERR:"]) {
        [self logLine:@"bad" text:[NSString stringWithFormat:@"页面内请求失败：%@", [t substringFromIndex:4]]];
        [self manualFallback];
        return;
    }
    id obj = [NSJSONSerialization JSONObjectWithData:[t dataUsingEncoding:NSUTF8StringEncoding]
                                            options:0 error:nil];
    if ([obj isKindOfClass:[NSDictionary class]]) {
        NSDictionary *j = (NSDictionary *)obj;
        NSString *code = [j[@"code"] description];
        NSString *m = j[@"msg"];
        if (![m isKindOfClass:[NSString class]]) m = j[@"message"];
        BOOL ok = ([code isEqualToString:@"100000"] || [code isEqualToString:@"0"]
                   || [j[@"ok"] integerValue] == 1);
        if (!ok && [m isKindOfClass:[NSString class]]
            && ([m containsString:@"已签到"] || [m containsString:@"已经签到"])) ok = YES;
        if (ok) {
            [self logLine:@"ok" text:@"✓ 这次不需要验证，已直接通过"];
            [self finishOK:YES];
            return;
        }
        NSString *vu = LSVerifyURLFromJSON(j);
        if (vu.length > 0) {
            [self loadVerifyURL:vu];
            return;
        }
        [self logLine:@"bad" text:[NSString stringWithFormat:@"微博返回：%@",
            (m.length > 0 ? m : (code.length > 0 ? code : @"未知"))]];
    }
    [self manualFallback];
}

- (void)manualFallback {
    if (self.finished) return;
    self.manualTried = YES;
    [self logLine:@"info" text:@"👉 把页面显示出来，手动拖一下就行"];
    [self revealWebForUser];
    self.manualDeadline = 100;
    [self pollManual];
}

- (void)attemptLoop {
    if (self.finished) return;
    if (![self onVerifyDomain]) {
        [self logLine:@"ok" text:@"✓ 已离开验证页"];
        [self finishOK:YES];
        return;
    }
    if (self.attempt >= 6) { [self fail]; return; }
    self.attempt += 1;
    [self logLine:@"info" text:[NSString stringWithFormat:@"▸ 滑块第 %ld 次尝试…", (long)self.attempt]];

    NSString *js = [NSString stringWithFormat:@"%@\n%@", LS_STEALTH_JS, LS_EXTRACT_JS];
    __weak typeof(self) ws = self;
    [self.web evaluateJavaScript:js completionHandler:^(id res, NSError *e) {
        LSVerifyRunner *s = ws;
        if (!s || s.finished) return;
        if (e || ![res isKindOfClass:[NSString class]]) { [s retryLater]; return; }
        id obj = [NSJSONSerialization JSONObjectWithData:[((NSString *)res) dataUsingEncoding:NSUTF8StringEncoding]
                                                options:0 error:nil];
        if (![obj isKindOfClass:[NSDictionary class]]) { [s retryLater]; return; }
        NSDictionary *info = (NSDictionary *)obj;
        if (![info[@"ok"] boolValue]) {
            NSString *why = info[@"err"] ?: @"未知";
            NSString *tl = info[@"title"];
            // 验证页本身没打开（微博的错误页），滑块永远不会出现，直接判这次失败
            BOOL dead = [s textLooksBroken:tl];
            NSString *msg = tl.length > 0
                ? [NSString stringWithFormat:@"… 还没出来（%@）·%@", why, tl]
                : [NSString stringWithFormat:@"… 还没出来（%@）", why];
            [s logLine:@"info" text:msg];
            if (dead) {
                [s showBrokenManual];
                return;
            }
            [s retryLater];
            return;
        }
        [s downloadAndSolve:info];
    }];
}

- (void)retryLater {
    __weak typeof(self) ws = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        LSVerifyRunner *s = ws;
        if (s) [s attemptLoop];
    });
}

- (void)downloadAndSolve:(NSDictionary *)info {
    NSString *bgUrl = info[@"bgUrl"];
    NSString *jgUrl = info[@"jigsawUrl"];
    if (bgUrl.length == 0 || jgUrl.length == 0) {
        [self logLine:@"bad" text:@"✗ 没拿到验证图片地址"];
        [self retryLater];
        return;
    }
    __weak typeof(self) ws = self;
    NSURLSession *sess = [NSURLSession sharedSession];
    __block NSData *bgData = nil;
    __block NSData *jgData = nil;
    __block NSInteger left = 2;

    void (^onOne)(void) = ^{
        left -= 1;
        if (left > 0) return;
        LSVerifyRunner *s = ws;
        if (!s || s.finished) return;
        if (bgData.length == 0 || jgData.length == 0) {
            [s logLine:@"bad" text:@"✗ 验证图片下载失败"];
            [s retryLater];
            return;
        }
        [s solveWithBG:bgData jigsaw:jgData info:info];
    };

    NSMutableURLRequest *r1 = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:bgUrl]];
    [r1 setValue:@"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        forHTTPHeaderField:@"User-Agent"];
    [r1 setValue:self.verifyURL forHTTPHeaderField:@"Referer"];
    [r1 setValue:@"zh-CN,zh;q=0.9" forHTTPHeaderField:@"Accept-Language"];
    [[sess dataTaskWithRequest:r1 completionHandler:^(NSData *d, NSURLResponse *rp, NSError *er) {
        bgData = d;
        onOne();
    }] resume];

    NSMutableURLRequest *r2 = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:jgUrl]];
    [r2 setValue:@"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        forHTTPHeaderField:@"User-Agent"];
    [r2 setValue:self.verifyURL forHTTPHeaderField:@"Referer"];
    [r2 setValue:@"zh-CN,zh;q=0.9" forHTTPHeaderField:@"Accept-Language"];
    [[sess dataTaskWithRequest:r2 completionHandler:^(NSData *d, NSURLResponse *rp, NSError *er) {
        jgData = d;
        onOne();
    }] resume];
}

- (void)solveWithBG:(NSData *)bgData jigsaw:(NSData *)jgData info:(NSDictionary *)info {
    LSRGBA bg = LSDecodeImageData(bgData);
    LSRGBA jig = LSDecodeImageData(jgData);
    if (!bg.px || !jig.px) {
        LSFreeRGBA(&bg); LSFreeRGBA(&jig);
        [self logLine:@"bad" text:@"✗ 验证图片解码失败"];
        [self retryLater];
        return;
    }
    double bestScore = -2.0;
    NSArray *xs = LSFindGapCandidates(&bg, &jig, &bestScore);
    int bgW = bg.w;
    LSFreeRGBA(&bg);
    LSFreeRGBA(&jig);

    if (xs.count == 0) {
        [self logLine:@"bad" text:@"✗ 没找到缺口"];
        [self retryLater];
        return;
    }
    [self logLine:@"info" text:[NSString stringWithFormat:@"… 缺口候选 %lu 个，最高相似度 %.2f",
                              (unsigned long)xs.count, bestScore]];
    if (bestScore < 0.35) {
        [self logLine:@"bad" text:@"✗ 候选相似度太低，跳过"];
        [self retryLater];
        return;
    }
    self.sliderInfo = info;
    self.candX = xs;
    self.candIdx = 0;
    self.bgPixelWidth = bgW;
    [self tryCandidate];
}

- (void)tryCandidate {
    if (self.finished) return;
    if (self.candIdx >= (NSInteger)self.candX.count) {
        [self logLine:@"info" text:@"… 候选都试过了，重新识别"];
        [self retryLater];
        return;
    }
    NSInteger idx = self.candIdx;
    self.candIdx = idx + 1;
    int gapX = [self.candX[idx] intValue];
    double domW = [self.sliderInfo[@"bgWidth"] doubleValue];
    double scale = (domW > 0 && self.bgPixelWidth > 0) ? (domW / (double)self.bgPixelWidth) : 1.0;
    int distance = (int)lround((double)gapX * scale);
    if (distance < 8) {
        [self logLine:@"bad" text:[NSString stringWithFormat:@"✗ 距离异常 %d", distance]];
        [self tryCandidate];
        return;
    }
    int sx = [self.sliderInfo[@"sliderLeft"] intValue];
    int sy = [self.sliderInfo[@"sliderTop"] intValue];
    [self logLine:@"info" text:[NSString stringWithFormat:@"… 拖到 x=%d（缩放 %.2f，距离 %d）",
                              gapX, scale, distance]];

    NSArray *track = LSGenTrack(distance);
    NSString *js = LSBuildDragJs(track, sx, sy);
    __weak typeof(self) ws = self;
    [self.web evaluateJavaScript:js completionHandler:^(id res, NSError *e) {
        LSVerifyRunner *s = ws;
        if (!s || s.finished) return;
        if (e) {
            [s logLine:@"bad" text:@"✗ 拖动注入失败"];
            [s tryCandidate];
            return;
        }
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.2 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            LSVerifyRunner *s2 = ws;
            if (!s2 || s2.finished) return;
            if (![s2 onVerifyDomain]) {
                [s2 logLine:@"ok" text:@"✓ 滑块通过，验证完成"];
                [s2 finishOK:YES];
                return;
            }
            [s2 logLine:@"info" text:@"… 这个位置没过，换下一个候选"];
            [s2 nextCandidateOrRetry];
        });
    }];
}

- (void)nextCandidateOrRetry {
    if (self.finished) return;
    if (self.candIdx >= (NSInteger)self.candX.count) {
        [self retryLater];
        return;
    }
    __weak typeof(self) ws = self;
    [self.web evaluateJavaScript:LS_EXTRACT_JS completionHandler:^(id res, NSError *e) {
        LSVerifyRunner *s = ws;
        if (!s || s.finished) return;
        if (![res isKindOfClass:[NSString class]]) { [s retryLater]; return; }
        id obj = [NSJSONSerialization JSONObjectWithData:[((NSString *)res) dataUsingEncoding:NSUTF8StringEncoding]
                                                options:0 error:nil];
        if (![obj isKindOfClass:[NSDictionary class]] || ![((NSDictionary *)obj)[@"ok"] boolValue]) {
            [s retryLater];
            return;
        }
        NSDictionary *ni = (NSDictionary *)obj;
        NSString *oldBg = s.sliderInfo[@"bgUrl"];
        NSString *newBg = ni[@"bgUrl"];
        if (oldBg.length > 0 && newBg.length > 0 && ![oldBg isEqualToString:newBg]) {
            [s attemptLoop];       // 验证图已换，必须重新识别
            return;
        }
        s.sliderInfo = ni;
        [s tryCandidate];
    }];
}

@end

#pragma mark - 账号存储

@interface LSStore : NSObject
+ (NSArray *)accounts;
+ (NSArray *)upsert:(NSDictionary *)acc;
+ (NSArray *)removeUID:(NSString *)uid;
+ (NSArray *)renameUID:(NSString *)uid remark:(NSString *)remark;
@end

@implementation LSStore

+ (NSArray *)accounts {
    id a = [[NSUserDefaults standardUserDefaults] objectForKey:@"left_accounts"];
    return [a isKindOfClass:[NSArray class]] ? (NSArray *)a : @[];
}

+ (void)saveAccounts:(NSArray *)arr {
    [[NSUserDefaults standardUserDefaults] setObject:(arr ? arr : @[]) forKey:@"left_accounts"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

+ (NSArray *)upsert:(NSDictionary *)acc {
    NSMutableArray *m = [NSMutableArray array];
    NSString *uid = acc[@"uid"];
    for (NSDictionary *d in [self accounts]) {
        if (![[d[@"uid"] description] isEqualToString:[uid description]]) [m addObject:d];
    }
    [m insertObject:acc atIndex:0];
    [self saveAccounts:m];
    return m;
}

+ (NSArray *)removeUID:(NSString *)uid {
    NSMutableArray *m = [NSMutableArray array];
    for (NSDictionary *d in [self accounts]) {
        if (![[d[@"uid"] description] isEqualToString:[uid description]]) [m addObject:d];
    }
    [self saveAccounts:m];
    return m;
}

+ (NSArray *)renameUID:(NSString *)uid remark:(NSString *)remark {
    NSMutableArray *m = [NSMutableArray array];
    for (NSDictionary *d in [self accounts]) {
        if ([[d[@"uid"] description] isEqualToString:[uid description]]) {
            NSMutableDictionary *x = [d mutableCopy];
            NSString *r = [remark stringByTrimmingCharactersInSet:
                [NSCharacterSet whitespaceAndNewlineCharacterSet]];
            if (r.length > 0) x[@"remark"] = r;
            else [x removeObjectForKey:@"remark"];
            [m addObject:x];
        } else {
            [m addObject:d];
        }
    }
    [self saveAccounts:m];
    return m;
}

@end

#pragma mark - 登录页

@interface LSLoginViewController : UIViewController <WKNavigationDelegate, WKScriptMessageHandler>
@property (nonatomic, strong) WKWebView *web;
@property (nonatomic, strong) UIView *bar;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UIButton *cancelBtn;
@property (nonatomic, strong) UIView *hud;
@property (nonatomic, strong) UILabel *hudLabel;
@property (nonatomic, strong) UIActivityIndicatorView *spinner;
@property (nonatomic, strong) NSTimer *poll;
@property (nonatomic, assign) BOOL finished;
@property (nonatomic, assign) BOOL triedFallback;
@property (nonatomic, assign) BOOL busy;
@property (nonatomic, assign) BOOL triedSso;
@property (nonatomic, assign) NSInteger missCount;
@property (nonatomic, assign) NSInteger tickCount;
@property (nonatomic, strong) UIButton *doneBtn;
@property (nonatomic, copy) void (^onDone)(NSDictionary *account);
@property (nonatomic, copy) void (^onFail)(NSString *msg);
@end

@implementation LSLoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];

    self.bar = [[UIView alloc] init];
    self.bar.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.98];
    [self.view addSubview:self.bar];

    self.cancelBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [self.cancelBtn setTitle:@"取消" forState:UIControlStateNormal];
    self.cancelBtn.titleLabel.font = [UIFont systemFontOfSize:15];
    [self.cancelBtn setTitleColor:[UIColor colorWithRed:0.04 green:0.11 blue:0.18 alpha:1.0] forState:UIControlStateNormal];
    [self.cancelBtn addTarget:self action:@selector(cancelTapped) forControlEvents:UIControlEventTouchUpInside];
    [self.bar addSubview:self.cancelBtn];

    self.titleLabel = [[UILabel alloc] init];
    self.titleLabel.text = @"登录微博";
    self.titleLabel.font = [UIFont boldSystemFontOfSize:16];
    self.titleLabel.textColor = [UIColor colorWithRed:0.04 green:0.11 blue:0.18 alpha:1.0];
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    [self.bar addSubview:self.titleLabel];

    WKWebViewConfiguration *cfg = [[WKWebViewConfiguration alloc] init];
    cfg.allowsInlineMediaPlayback = YES;
    [cfg.userContentController addScriptMessageHandler:self name:@"lsLogin"];
    self.web = [[WKWebView alloc] initWithFrame:CGRectZero configuration:cfg];
    self.web.navigationDelegate = self;
    [self.view addSubview:self.web];

    self.hud = [[UIView alloc] init];
    self.hud.backgroundColor = [UIColor colorWithRed:0.08 green:0.15 blue:0.24 alpha:1.0];
    self.hud.layer.cornerRadius = 14;
    self.hud.hidden = YES;
    [self.view addSubview:self.hud];

    self.spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleMedium];
    self.spinner.color = [UIColor whiteColor];
    [self.hud addSubview:self.spinner];

    self.hudLabel = [[UILabel alloc] init];
    self.hudLabel.textColor = [UIColor whiteColor];
    self.hudLabel.font = [UIFont systemFontOfSize:13];
    self.hudLabel.textAlignment = NSTextAlignmentCenter;
    [self.hud addSubview:self.hudLabel];

    self.doneBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [self.doneBtn setTitle:@"我已完成登录，点这里继续" forState:UIControlStateNormal];
    self.doneBtn.titleLabel.font = [UIFont boldSystemFontOfSize:14];
    [self.doneBtn setTitleColor:[UIColor colorWithRed:0.04 green:0.11 blue:0.18 alpha:1.0] forState:UIControlStateNormal];
    self.doneBtn.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.96];
    self.doneBtn.layer.cornerRadius = 22;
    self.doneBtn.layer.shadowColor = [UIColor blackColor].CGColor;
    self.doneBtn.layer.shadowOpacity = 0.13;
    self.doneBtn.layer.shadowRadius = 8;
    self.doneBtn.layer.shadowOffset = CGSizeMake(0, 2);
    [self.doneBtn addTarget:self action:@selector(onDoneTap) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.doneBtn];

    [self loadLogin];
    self.poll = [NSTimer timerWithTimeInterval:1.2 target:self selector:@selector(tick) userInfo:nil repeats:YES];
    [[NSRunLoop mainRunLoop] addTimer:self.poll forMode:NSRunLoopCommonModes];
}

- (void)dealloc {
    [self.web.configuration.userContentController removeScriptMessageHandlerForName:@"lsLogin"];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    CGFloat w = self.view.bounds.size.width;
    CGFloat h = self.view.bounds.size.height;
    CGFloat safeTop = 0;
    if (@available(iOS 11.0, *)) safeTop = self.view.safeAreaInsets.top;
    CGFloat barH = 52;
    self.bar.frame = CGRectMake(0, 0, w, safeTop + barH);
    self.cancelBtn.frame = CGRectMake(4, safeTop, 68, barH);
    self.titleLabel.frame = CGRectMake(80, safeTop, w - 160, barH);
    CGFloat safeBottom = 0;
    if (@available(iOS 11.0, *)) safeBottom = self.view.safeAreaInsets.bottom;
    self.web.frame = CGRectMake(0, safeTop + barH, w, h - safeTop - barH - safeBottom);
    self.hud.frame = CGRectMake(w/2 - 110, safeTop + barH + 60, 220, 76);
    self.spinner.frame = CGRectMake(20, 26, 20, 20);
    self.hudLabel.frame = CGRectMake(44, 0, 160, 76);
    self.doneBtn.frame = CGRectMake(20, h - safeBottom - 58, w - 40, 44);
}

- (void)loadLogin {
    NSURL *u = [NSURL URLWithString:kLoginURL];
    NSMutableURLRequest *r = [NSMutableURLRequest requestWithURL:u];
    [r setValue:kUA forHTTPHeaderField:@"User-Agent"];
    [self.web loadRequest:r];
}

- (void)cancelTapped {
    [self stopAll];
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)stopAll {
    self.finished = YES;
    [self.poll invalidate];
    self.poll = nil;
}

#pragma mark - Cookie 拼装

- (NSString *)cookieHeader:(NSArray<NSHTTPCookie *> *)cookies forHost:(NSString *)host {
    NSMutableArray *parts = [NSMutableArray array];
    NSString *h = host.lowercaseString;
    for (NSHTTPCookie *c in cookies) {
        NSString *d = c.domain.lowercaseString;
        if (d.length == 0) continue;
        NSString *bare = [d hasPrefix:@"."] ? [d substringFromIndex:1] : d;
        BOOL match = [h isEqualToString:bare]
                  || [h hasSuffix:[@"." stringByAppendingString:bare]]
                  || [h hasSuffix:d];
        if (match) [parts addObject:[NSString stringWithFormat:@"%@=%@", c.name, c.value]];
    }
    return [parts componentsJoinedByString:@"; "];
}

#pragma mark - 轮询探测登录态

- (void)tick {
    if (self.finished) return;
    self.tickCount++;
    if (self.tickCount > 110) {
        [self failWith:@"登录超时了，请退出重试"];
        return;
    }
    if (self.busy) return;
    NSString *host = self.web.URL.host.lowercaseString;
    if (host.length == 0) return;
    if (![host hasSuffix:@"weibo.cn"]) return;   // 还停在登录页，不动手
    self.busy = YES;
    self.hud.hidden = NO;
    self.spinner.hidden = NO;
    [self.spinner startAnimating];
    self.hudLabel.text = @"正在确认登录状态…";
    [self probe];
}

- (void)probe {
    NSString *js =
        @"(function(){"
         "function send(o){try{window.webkit.messageHandlers.lsLogin.postMessage(o);}catch(e){}}"
         "fetch('/api/config',{credentials:'include',cache:'no-store'})"
         ".then(function(r){return r.json();})"
         ".then(function(j){"
           "var d=(j&&j.data)||{};var uid=d.uid||'';"
           "if(!uid){send({ok:false,login:!!d.login,loginUrl:d.loginUrl||'',host:location.host});return;}"
           "fetch('/api/container/getIndex?type=uid&value='+uid,{credentials:'include'})"
           ".then(function(r2){return r2.json();})"
           ".then(function(j2){"
             "var i=(j2&&j2.data&&j2.data.userInfo)||{};"
             "send({ok:true,uid:String(uid),name:i.screen_name||'',avatar:i.profile_image_url||'',host:location.host});"
           "})"
           ".catch(function(){send({ok:true,uid:String(uid),name:'',avatar:'',host:location.host});});"
         "})"
         ".catch(function(e){send({ok:false,login:false,loginUrl:'',host:location.host,err:String(e)});});"
         "})();";
    [self.web evaluateJavaScript:js completionHandler:nil];
}

#pragma mark - 收结果

- (void)userContentController:(WKUserContentController *)userContentController
      didReceiveScriptMessage:(WKScriptMessage *)message {
    if (![message.name isEqualToString:@"lsLogin"]) return;
    if (self.finished) return;
    id body = message.body;
    if (![body isKindOfClass:[NSDictionary class]]) {
        self.busy = NO;
        return;
    }
    NSDictionary *b = (NSDictionary *)body;

    if ([b[@"ok"] boolValue]) {
        NSString *uid = b[@"uid"];
        NSString *name = b[@"name"];
        NSString *avatar = b[@"avatar"];
        if (![uid isKindOfClass:[NSString class]] || uid.length == 0) {
            self.busy = NO;
            return;
        }
        if (![name isKindOfClass:[NSString class]] || name.length == 0) {
            name = [NSString stringWithFormat:@"微博账号 %@", uid];
        }
        if (![avatar isKindOfClass:[NSString class]]) avatar = @"";
        [self saveAndFinish:uid name:name avatar:avatar];
        return;
    }

    // 站点认可登录、但换不到 uid：用官方 loginUrl 走一次 SSO 换票
    NSString *loginUrl = b[@"loginUrl"];
    if ([loginUrl isKindOfClass:[NSString class]] && loginUrl.length > 0 && !self.triedSso) {
        self.triedSso = YES;
        self.busy = NO;
        NSMutableURLRequest *r = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:loginUrl]];
        [r setValue:kUA forHTTPHeaderField:@"User-Agent"];
        [self.web loadRequest:r];
        self.hudLabel.text = @"正在同步登录态…";
        return;
    }

    self.busy = NO;
    self.missCount++;
    [self.spinner stopAnimating];
    self.hudLabel.text = @"还没检测到登录完成，请稍候…";
    if (self.missCount >= 15) {
        [self failWith:@"没能确认登录状态，请退出后重试"];
    }
}

- (void)saveAndFinish:(NSString *)uid name:(NSString *)name avatar:(NSString *)avatar {
    __weak typeof(self) weakSelf = self;
    [[WKWebsiteDataStore defaultDataStore].httpCookieStore getAllCookies:^(NSArray<NSHTTPCookie *> *cookies) {
        typeof(self) sf = weakSelf;
        if (!sf) return;
        NSString *ck = LSCollectCookiesJSON(cookies);
        dispatch_async(dispatch_get_main_queue(), ^{
            if (sf.finished) return;
            NSDictionary *acc = @{
                @"uid" : uid,
                @"name" : name,
                @"avatar" : avatar,
                @"cookies" : (ck ? ck : @""),
                @"addedAt" : @([[NSDate date] timeIntervalSince1970])
            };
            [sf finishWith:acc];
        });
    }];
}

- (void)finishWith:(NSDictionary *)acc {
    [self.spinner stopAnimating];
    self.hud.hidden = YES;
    void (^cb)(NSDictionary *) = self.onDone;
    [self stopAll];
    [self dismissViewControllerAnimated:YES completion:^{
        if (cb) cb(acc);
    }];
}

- (void)failWith:(NSString *)msg {
    [self.spinner stopAnimating];
    self.hud.hidden = YES;
    [self stopAll];
    void (^cb)(NSString *) = self.onFail;
    [self dismissViewControllerAnimated:YES completion:^{
        if (cb) cb(msg);
    }];
}

#pragma mark - 导航

- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation {
    if (self.finished) return;
    NSString *host = webView.URL.host.lowercaseString;
    if ([host hasSuffix:@"weibo.cn"] && !self.busy) [self tick];
}

- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(WKNavigation *)navigation withError:(NSError *)error {
    if (self.finished) return;
    NSString *host = webView.URL.host.lowercaseString;
    if (!self.triedFallback && host && [host containsString:@"passport"]) {
        self.triedFallback = YES;
        self.busy = NO;
        NSMutableURLRequest *r = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:kFallbackURL]];
        [r setValue:kUA forHTTPHeaderField:@"User-Agent"];
        [webView loadRequest:r];
        return;
    }
    self.hud.hidden = NO;
    self.hudLabel.text = @"网络打不开微博，检查网络或 DNS";
    [self.spinner stopAnimating];
}

- (void)onDoneTap {
    if (self.finished) return;
    self.busy = NO;
    self.missCount = 0;
    // 走一趟 SSO 换票：把 passport 域的登录态兑换成 m.weibo.cn 域的 SUB
    NSMutableURLRequest *r = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:kLoginURL]];
    [r setValue:kUA forHTTPHeaderField:@"User-Agent"];
    [self.web loadRequest:r];
    self.hud.hidden = NO;
    self.spinner.hidden = NO;
    [self.spinner startAnimating];
    self.hudLabel.text = @"正在确认登录状态…";
}
@end

#pragma mark - 主控制器

@interface LSViewController : UIViewController <WKNavigationDelegate, WKScriptMessageHandler>
@property (nonatomic, strong) WKWebView *web;
@property (nonatomic, copy) void (^slStep)(void);
@property (nonatomic, assign) BOOL slPaused;
@property (nonatomic, assign) BOOL slCancelled;    // 手动结束后，所有在途回调一律不再推进
@property (nonatomic, copy) void (^slPendingStep)(void);
@property (nonatomic, copy) NSString *slXsrf;
@property (nonatomic, strong) id verifier;          // LSVerifyRunner，跑验证期间持有
@property (nonatomic, assign) BOOL verifying;       // 防止并发重复触发
@property (nonatomic, copy) NSString *curAccName;      // 当前正在跑的账号名，给手动验证面板用
- (void)openLogin;                                     // 掉登录时把手动验证面板导到登录页
- (void)fetchXsrf:(NSString *)cookiesJSON completion:(void (^)(NSString *token))done;
- (void)fetchXsrfForce:(NSString *)cookiesJSON completion:(void (^)(NSString *token))done;
- (void)lsPostRepost:(NSString *)cookiesJSON idstr:(NSString *)idstr text:(NSString *)text
                 deep:(NSInteger)deep completion:(void (^)(BOOL ok, NSString *msg))done;
- (void)lsPostComment:(NSString *)cookiesJSON idstr:(NSString *)idstr text:(NSString *)text
                  deep:(NSInteger)deep completion:(void (^)(BOOL ok, NSString *msg))done;
- (void)lsPostPublish:(NSString *)cookiesJSON text:(NSString *)text uid:(NSString *)uid
                  deep:(NSInteger)deep completion:(void (^)(BOOL ok, NSString *msg))done;
- (void)lsRunVerify:(NSString *)url cookies:(NSString *)ck kind:(NSString *)kind
          completion:(void (^)(BOOL ok, NSString *newCk))done;
- (void)lsPostCheckin:(NSString *)cookiesJSON deep:(NSInteger)deep
            completion:(void (^)(BOOL ok, NSString *msg))done;
- (void)pickPush:(NSDictionary *)payload;
- (void)pickFetch:(NSString *)raw kw:(NSString *)kw max:(NSInteger)maxC page:(NSInteger)page;
- (void)pickFetchSuper:(NSString *)pid kw:(NSString *)kw max:(NSInteger)maxC page:(NSInteger)page;
- (void)pickFetchPost:(NSString *)raw;
- (void)pickFetchPosts:(NSArray *)urls;
- (void)pickPostsStep:(NSArray *)urls idx:(NSInteger)i items:(NSMutableArray *)items bad:(NSMutableArray *)bad cj:(NSString *)cj;
- (void)pickPostOne:(NSString *)key cookieJSON:(NSString *)cj completion:(void (^)(NSDictionary *item, NSString *err))done;
- (void)pickCommentStep:(NSArray *)items accs:(NSArray *)accs texts:(NSArray *)texts gap:(double)gap
                     idx:(NSInteger)i okN:(NSInteger)okN failN:(NSInteger)failN;

- (void)startLockRepost:(NSArray *)urls uids:(NSArray *)uids gap:(double)gap;
- (void)lockRepostStep:(NSArray *)ids accs:(NSArray *)accs texts:(NSArray *)texts gap:(double)gap
                    idx:(NSInteger)i okN:(NSInteger)okN failN:(NSInteger)failN;

- (void)pickTextPool:(void (^)(NSArray *texts))done;
@end


#pragma mark - 页面内请求器

// 账号里存的 cookie 和 WKWebView 里的 cookie 是两套。
// 发帖接口只认后者，所以干脆在页面里发请求，省得搬来搬去。
@interface LSWebApi : NSObject <WKNavigationDelegate>
@property (nonatomic, strong) WKWebView *web;
@property (nonatomic, assign) BOOL ready;
@property (nonatomic, strong) NSMutableArray *pending;
@end

@implementation LSWebApi

+ (instancetype)shared {
    static LSWebApi *o = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ o = [[LSWebApi alloc] init]; });
    return o;
}

- (instancetype)init {
    self = [super init];
    if (self) _pending = [NSMutableArray array];
    return self;
}

- (void)ensureReady {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self ensureReady]; });
        return;
    }
    if (_ready || _web) return;
    WKWebViewConfiguration *cfg = [[WKWebViewConfiguration alloc] init];
    cfg.websiteDataStore = [WKWebsiteDataStore defaultDataStore];
    _web = [[WKWebView alloc] initWithFrame:CGRectMake(0, 0, 1, 1) configuration:cfg];
    _web.customUserAgent = kPCUA;
    _web.alpha = 0.01;
    _web.navigationDelegate = self;
    UIWindow *w = UIApplication.sharedApplication.windows.firstObject;
    if (w) {
        [w addSubview:_web];
        [w sendSubviewToBack:_web];
    }
    NSMutableURLRequest *r = [NSMutableURLRequest requestWithURL:
        [NSURL URLWithString:[NSString stringWithFormat:@"https://weibo.com/p/%@", kSuperId]]];
    [r setValue:kPCUA forHTTPHeaderField:@"User-Agent"];
    r.timeoutInterval = 20.0;
    [_web loadRequest:r];
    // didFinish 万一不来，8 秒后照样放行，别把发帖卡死
    __weak typeof(self) ws = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(8.0 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        LSWebApi *a = ws;
        if (!a || a.ready) return;
        a.ready = YES;
        NSArray *q = [a.pending copy];
        [a.pending removeAllObjects];
        for (void (^blk)(void) in q) blk();
    });
}

- (void)webView:(WKWebView *)w didFinishNavigation:(WKNavigation *)n {
    _ready = YES;
    NSArray *q = [_pending copy];
    [_pending removeAllObjects];
    for (void (^blk)(void) in q) blk();
}

- (void)postPath:(NSString *)path form:(NSString *)form
       completion:(void (^)(id json, NSString *raw))done {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self postPath:path form:form completion:done];
        });
        return;
    }
    [self ensureReady];
    __weak typeof(self) ws = self;
    void (^run)(void) = ^{
        LSWebApi *a = ws;
        if (!a || !a.web) { done(nil, @"NOCALL"); return; }
        NSString *seq = [NSString stringWithFormat:@"q%u", arc4random_uniform(1000000)];
        NSData *jd = [NSJSONSerialization dataWithJSONObject:@[ form ] options:0 error:nil];
        NSString *formJson = jd ? [[NSString alloc] initWithData:jd encoding:NSUTF8StringEncoding] : @"[\"\"]";
        NSString *js = [NSString stringWithFormat:
            @"(function(){window.__LSA_%@__=null;"
             "var xs=(document.cookie.match(/XSRF-TOKEN=([^;]*)/)||[])[1]||'';"
             "var h={'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8',"
             "'Accept':'application/json, text/plain, */*',"
             "'X-Requested-With':'XMLHttpRequest','MWeibo-Pwa':'1'};"
             "if(xs) h['X-XSRF-TOKEN']=decodeURIComponent(xs);"
             "fetch('https://weibo.com%@',{method:'POST',credentials:'include',"
             "headers:h,"
             "body:%@[0]}).then(function(r){return r.text();})"
             ".then(function(t){window.__LSA_%@__=t;})"
             ".catch(function(e){window.__LSA_%@__='ERR:'+e;});})();",
            seq, path, formJson, seq, seq];
        if (!a.web) { done(nil, @"NOCALL"); return; }
        [a.web evaluateJavaScript:js completionHandler:nil];
        [a poll:seq tries:60 cb:done];
    };
    if (_ready) run();
    else [_pending addObject:[run copy]];
}

- (void)poll:(NSString *)seq tries:(NSInteger)n cb:(void (^)(id, NSString *))done {
    __weak typeof(self) ws = self;
    [_web evaluateJavaScript:[NSString stringWithFormat:@"window.__LSA_%@__", seq]
        completionHandler:^(id res, NSError *e) {
            LSWebApi *a = ws;
            if (!a) return;
            NSString *t = [res isKindOfClass:[NSString class]] ? (NSString *)res : @"";
            if (t.length == 0) {
                if (n <= 0) { done(nil, @"TIMEOUT"); return; }
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.4 * NSEC_PER_SEC)),
                               dispatch_get_main_queue(), ^{
                    [a poll:seq tries:n - 1 cb:done];
                });
                return;
            }
            id obj = [NSJSONSerialization JSONObjectWithData:[t dataUsingEncoding:NSUTF8StringEncoding]
                                                    options:0 error:nil];
            done(obj, t);
        }];
}

@end

@implementation LSViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithRed:0.945 green:0.961 blue:0.984 alpha:1.0];

    WKUserContentController *ucc = [[WKUserContentController alloc] init];
    [ucc addScriptMessageHandler:self name:@"lsStore"];

    // 打卡数据 + 账号列表在 documentStart 注入（file:// 下 localStorage 不可靠）
    NSDictionary *streak = [[NSUserDefaults standardUserDefaults] objectForKey:@"left_streak"];
    NSString *streakJSON = @"null";
    if (streak && [NSJSONSerialization isValidJSONObject:streak]) {
        NSData *data = [NSJSONSerialization dataWithJSONObject:streak options:0 error:nil];
        if (data) streakJSON = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    }
    NSData *accData = [NSJSONSerialization dataWithJSONObject:[LSStore accounts] options:0 error:nil];
    NSString *accJSON = accData ? [[NSString alloc] initWithData:accData encoding:NSUTF8StringEncoding] : @"[]";

    id ckObj = [[NSUserDefaults standardUserDefaults] objectForKey:@"left_checkin"];
    NSString *ckJSON = @"{}";
    if ([ckObj isKindOfClass:[NSDictionary class]]) {
        NSData *d = [NSJSONSerialization dataWithJSONObject:ckObj options:0 error:nil];
        if (d) ckJSON = [[NSString alloc] initWithData:d encoding:NSUTF8StringEncoding];
    }
    NSString *src = [NSString stringWithFormat:@"window.__LS_INIT__ = %@; window.__LS_ACCOUNTS__ = %@; window.__LS_CHECKIN__ = %@;",
                     streakJSON, accJSON, ckJSON];
    WKUserScript *us = [[WKUserScript alloc] initWithSource:src
                                              injectionTime:WKUserScriptInjectionTimeAtDocumentStart
                                           forMainFrameOnly:YES];
    [ucc addUserScript:us];

    WKWebViewConfiguration *cfg = [[WKWebViewConfiguration alloc] init];
    cfg.userContentController = ucc;
    cfg.allowsInlineMediaPlayback = YES;

    CGRect f = self.view.bounds;
    WKWebView *wv = [[WKWebView alloc] initWithFrame:f configuration:cfg];
    wv.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    wv.navigationDelegate = self;
    wv.backgroundColor = self.view.backgroundColor;
    wv.scrollView.bounces = NO;
    wv.scrollView.backgroundColor = self.view.backgroundColor;
    if (@available(iOS 11.0, *)) {
        wv.scrollView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    }
    self.web = wv;
    [self.view addSubview:wv];

    NSString *wwwPath = [[[NSBundle mainBundle] bundlePath] stringByAppendingPathComponent:@"www"];
    NSString *htmlPath = [wwwPath stringByAppendingPathComponent:@"index.html"];
    BOOL exists = [[NSFileManager defaultManager] fileExistsAtPath:htmlPath];
    if (!exists) {
        NSString *err = [NSString stringWithFormat:
            @"<html><body style='font-family:-apple-system;padding:24px;background:#f1f5fb'>"
            @"<h3 style='color:#e8557f'>缺少页面文件</h3>"
            @"<p style='font-size:13px;color:#6b7c93'>expected: %@</p></body></html>", htmlPath];
        [wv loadHTMLString:err baseURL:nil];
        return;
    }
    NSURL *baseURL = [NSURL fileURLWithPath:wwwPath isDirectory:YES];
    NSURL *fileURL = [NSURL fileURLWithPath:htmlPath];
    [wv loadFileURL:fileURL allowingReadAccessToURL:baseURL];
}

- (void)dealloc {
    [self.web.configuration.userContentController removeScriptMessageHandlerForName:@"lsStore"];
}

#pragma mark - 桥

- (void)userContentController:(WKUserContentController *)userContentController
      didReceiveScriptMessage:(WKScriptMessage *)message {
    if (![message.name isEqualToString:@"lsStore"]) return;
    id body = message.body;
    if (![body isKindOfClass:[NSDictionary class]]) return;
    NSDictionary *dict = (NSDictionary *)body;

    NSString *type = dict[@"type"];
    if ([type isKindOfClass:[NSString class]]) {
        if ([type isEqualToString:@"login"]) {
            [self openLogin];
            return;
        }
        if ([type isEqualToString:@"signin"]) {
            id us = dict[@"uids"];
            [self startSigninWithUids:([us isKindOfClass:[NSArray class]] ? (NSArray *)us : nil)];
            return;
        }
        if ([type isEqualToString:@"publish"]) {
            id t = dict[@"text"];
            if (![t isKindOfClass:[NSString class]]) t = @"";
            [self startPublish:(NSString *)t];
            return;
        }
        if ([type isEqualToString:@"superlike"]) {
            [self startSuperLike:dict];
            return;
        }
        if ([type isEqualToString:@"slPause"]) {
            self.slPaused = YES;
            return;
        }
        if ([type isEqualToString:@"slResume"]) {
            self.slPaused = NO;
            void (^pend)(void) = self.slPendingStep;
            self.slPendingStep = nil;
            if (pend) {
                // 延迟一拍，等当前回调栈退出去再继续
                dispatch_async(dispatch_get_main_queue(), pend);
            }
            return;
        }
        if ([type isEqualToString:@"slStop"]) {
            // 手动结束：置取消位，拆掉在途步骤和验证器，然后让前端复位
            self.slCancelled = YES;
            self.slPaused = NO;
            self.slPendingStep = nil;
            self.slStep = nil;
            self.verifying = NO;
            self.verifier = nil;
            [self superLikeLog:@"info" text:@"■ 已手动结束本次任务"];
            [self superLikeDone:NO msg:@"已手动结束本次任务" cmts:0 reps:0 posts:0];
            return;
        }
        if ([type isEqualToString:@"clear"]) {
            [self clearLocalData];
            return;
        }
        if ([type isEqualToString:@"saveTiming"]) {
            NSDictionary *o = @{ @"accGap" : (dict[@"accGap"] ?: @2.0),
                                 @"stepGap" : (dict[@"stepGap"] ?: @4.5),
                                 @"sync" : (dict[@"sync"] ?: @0) };
            [[NSUserDefaults standardUserDefaults] setObject:o forKey:@"left_timing"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            [self pushSettings];
            [self toast:@"已保存，下次超Like生效"];
            return;
        }
        if ([type isEqualToString:@"refreshRemote"]) {
            [[NSURLCache sharedURLCache] removeAllCachedResponses];
            [self refreshHome];
            [self toast:@"已刷新远程配置"];
            return;
        }
        if ([type isEqualToString:@"ready"]) {
            [self pushNick];
            [self refreshHome];
            [self pushSettings];
            [self pushLogs];
            [self pushFlower];
            return;
        }
        if ([type isEqualToString:@"nick"]) {
            id nk = dict[@"nick"];
            if ([nk isKindOfClass:[NSString class]]) {
                NSString *v = [(NSString *)nk stringByTrimmingCharactersInSet:
                    [NSCharacterSet whitespaceAndNewlineCharacterSet]];
                [[NSUserDefaults standardUserDefaults] setObject:(v.length ? v : @"航航丝")
                                                          forKey:@"left_nick"];
                [[NSUserDefaults standardUserDefaults] synchronize];
                [self pushNick];
            }
            return;
        }
        if ([type isEqualToString:@"refresh"]) {
            [self refreshHome];
            [self toast:@"已刷新"];
            return;
        }
        if ([type isEqualToString:@"copyLog"]) {
            id t = dict[@"text"];
            if (![t isKindOfClass:[NSString class]]) t = @"";
            if ([(NSString *)t length] > 0) {
                [[UIPasteboard generalPasteboard] setString:(NSString *)t];
                [self toast:@"日志已复制"];
            } else {
                [self toast:@"还没有日志"];
            }
            return;
        }
        if ([type isEqualToString:@"saveLogs"]) {
            id arr = dict[@"records"];
            if ([arr isKindOfClass:[NSArray class]]) {
                NSData *jd = [NSJSONSerialization dataWithJSONObject:arr options:0 error:nil];
                NSString *json = jd ? [[NSString alloc] initWithData:jd encoding:NSUTF8StringEncoding] : @"[]";
                if (json) {
                    [[NSUserDefaults standardUserDefaults] setObject:json forKey:@"left_logs"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                }
            }
            return;
        }
        if ([type isEqualToString:@"saveFlower"]) {
            id obj = dict[@"data"];
            if ([obj isKindOfClass:[NSDictionary class]]) {
                NSData *jd = [NSJSONSerialization dataWithJSONObject:obj options:0 error:nil];
                NSString *json = jd ? [[NSString alloc] initWithData:jd encoding:NSUTF8StringEncoding] : nil;
                if (json) {
                    [[NSUserDefaults standardUserDefaults] setObject:json forKey:@"left_flower"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                }
            }
            return;
        }
        if ([type isEqualToString:@"pickPost"]) {
            id us = dict[@"urls"];
            if ([us isKindOfClass:[NSArray class]] && [(NSArray *)us count] > 0) {
                [self pickFetchPosts:(NSArray *)us];
            } else {
                NSString *u = [dict[@"url"] description];
                if (u.length > 0) [self pickFetchPost:u];
            }
            return;
        }
        if ([type isEqualToString:@"pickFetch"]) {
            NSString *raw = [dict[@"uid"] isKindOfClass:[NSString class]] ? dict[@"uid"] : @"";
            NSString *kw = [dict[@"kw"] isKindOfClass:[NSString class]] ? dict[@"kw"] : @"";
            NSInteger maxC = [dict[@"max"] isKindOfClass:[NSNumber class]] ? [dict[@"max"] integerValue] : 20;
            NSInteger page = [dict[@"page"] isKindOfClass:[NSNumber class]] ? [dict[@"page"] integerValue] : 1;
            [self pickFetch:raw kw:kw max:maxC page:page];
            return;
        }
        if ([type isEqualToString:@"pickComment"]) {
            id its = dict[@"items"];
            id uids = dict[@"uids"];
            double gap = [dict[@"gap"] isKindOfClass:[NSNumber class]] ? [dict[@"gap"] doubleValue] : 4.5;
            if (gap < 1) gap = 1;
            if (![its isKindOfClass:[NSArray class]] || [(NSArray *)its count] == 0) return;
            NSArray *all = [LSStore accounts];
            NSMutableArray *accs = [NSMutableArray array];
            for (id a in all) {
                if (![a isKindOfClass:[NSDictionary class]]) continue;
                if ([uids isKindOfClass:[NSArray class]]) {
                    NSString *u = [((NSDictionary *)a)[@"uid"] description];
                    BOOL hit = NO;
                    for (id uu in (NSArray *)uids) {
                        if ([u isEqualToString:[uu description]]) { hit = YES; break; }
                    }
                    if (!hit) continue;
                }
                [accs addObject:a];
            }
            if (accs.count == 0) { [self toast:@"先勾选参与账号"]; return; }
            NSArray *posts = (NSArray *)its;
            __weak typeof(self) ws = self;
            [self pickTextPool:^(NSArray *texts) {
                LSViewController *sf = ws;
                if (!sf) return;
                dispatch_async(dispatch_get_main_queue(), ^{
                    [sf superLikeLog:@"info" text:[NSString stringWithFormat:
                        @"开始批量评论：%ld 个账号 × %ld 条帖子，文案池 %ld 条",
                        (long)accs.count, (long)posts.count, (long)texts.count]];
                    [sf pickCommentStep:posts accs:accs texts:texts gap:gap idx:0 okN:0 failN:0];
                });
            }];
            return;
        }
        if ([type isEqualToString:@"repostPosts"]) {
            id us = dict[@"urls"];
            id uids = dict[@"uids"];
            double gap = [dict[@"gap"] isKindOfClass:[NSNumber class]] ? [dict[@"gap"] doubleValue] : 4.5;
            if (gap < 1) gap = 1;
            if (![us isKindOfClass:[NSArray class]] || [(NSArray *)us count] == 0) {
                [self toast:@"先贴帖子链接"];
                return;
            }
            [self startLockRepost:(NSArray *)us
                              uids:([uids isKindOfClass:[NSArray class]] ? (NSArray *)uids : nil)
                               gap:gap];
            return;
        }
        if ([type isEqualToString:@"tplGet"]) {
            [self pushTemplates];
            return;
        }
        if ([type isEqualToString:@"tplSave"]) {
            id obj = dict[@"data"];
            if ([obj isKindOfClass:[NSDictionary class]]) {
                NSData *jd = [NSJSONSerialization dataWithJSONObject:obj options:0 error:nil];
                NSString *json = jd ? [[NSString alloc] initWithData:jd encoding:NSUTF8StringEncoding] : nil;
                if (json) {
                    [[NSUserDefaults standardUserDefaults] setObject:json forKey:@"left_tpl_custom"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                }
            }
            [self pushTemplates];
            return;
        }
        if ([type isEqualToString:@"delAcc"]) {
            id uid = dict[@"uid"];
            if ([uid isKindOfClass:[NSString class]]) {
                [self pushAccounts:[LSStore removeUID:uid]];
            }
            return;
        }
        if ([type isEqualToString:@"renameAcc"]) {
            id uid = dict[@"uid"];
            id rk = dict[@"remark"];
            if ([uid isKindOfClass:[NSString class]] && [rk isKindOfClass:[NSString class]]) {
                [self pushAccounts:[LSStore renameUID:uid remark:rk]];
            }
            return;
        }
        return;
    }

    // 默认：打卡数据
    NSNumber *days = dict[@"days"];
    NSString *last = dict[@"last"];
    if (![days isKindOfClass:[NSNumber class]]) days = @0;
    if (![last isKindOfClass:[NSString class]]) last = @"";
    NSDictionary *payload = @{ @"days" : days, @"last" : last };
    [[NSUserDefaults standardUserDefaults] setObject:payload forKey:@"left_streak"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

#pragma mark - 超话签到

- (void)startSignin {
    [self startSigninWithUids:nil];
}

- (void)startSigninWithUids:(NSArray *)uids {
    NSArray *all = [LSStore accounts];
    if (all.count == 0) {
        [self signinCallback:@[] summary:@"先在账号页登录一个微博账号"];
        return;
    }
    NSArray *accs = all;
    if ([uids isKindOfClass:[NSArray class]] && uids.count > 0) {
        NSMutableArray *pick = [NSMutableArray array];
        for (id a in all) {
            if (![a isKindOfClass:[NSDictionary class]]) continue;
            NSString *u = [NSString stringWithFormat:@"%@", ((NSDictionary *)a)[@"uid"] ?: @""];
            if ([uids containsObject:u]) [pick addObject:a];
        }
        if (pick.count == 0) {
            [self signinCallback:@[] summary:@"勾选的账号都找不到了，去账号页看看"];
            return;
        }
        accs = pick;
    }
    [self toast:(accs.count == 1 ? @"正在给超话签到…" : [NSString stringWithFormat:@"正在给 %ld 个账号签到…", (long)accs.count])];
    [self signinNext:accs index:0 results:[NSMutableArray array]];
}

- (void)signinNext:(NSArray *)accs index:(NSInteger)i results:(NSMutableArray *)results {
    if (i >= accs.count) {
        NSInteger total = (NSInteger)accs.count;
        NSInteger okN = 0;
        NSString *firstFail = nil;
        for (NSDictionary *r in results) {
            if ([r[@"ok"] boolValue]) okN++;
            else if (!firstFail && [r[@"msg"] length]) firstFail = r[@"msg"];
        }
        NSString *msg;
        if (okN == total) {
            msg = (total == 1) ? @"超话签到成功" : [NSString stringWithFormat:@"%ld 个账号全部签到成功", (long)total];
        } else if (okN > 0) {
            msg = [NSString stringWithFormat:@"%ld 个成功，%ld 个失败：%@",
                   (long)okN, (long)(total - okN), (firstFail ? firstFail : @"未知原因")];
        } else {
            msg = (firstFail ? firstFail : @"签到失败");
        }
        [self signinCallback:results summary:msg];
        return;
    }

    NSDictionary *acc = accs[(NSUInteger)i];
    __weak typeof(self) ws = self;
    [self ensureCookies:acc completion:^(NSString *json) {
        typeof(self) sf = ws;
        if (!sf) return;
        [sf postCheckin:json completion:^(BOOL aok, NSString *amsg) {
            typeof(self) sf2 = ws;
            if (!sf2) return;
            NSString *aname = [NSString stringWithFormat:@"%@", (acc[@"name"] ?: @"账号")];
            NSString *receipt = (amsg.length ? amsg : (aok ? @"服务器已确认" : @"没有回执"));
            [sf2 superLikeLog:(aok ? @"ok" : @"bad")
                         text:[NSString stringWithFormat:@"[签到] %@%@ · %@",
                               (aok ? @"✓ " : @"✗ "), aname, receipt]];
            [results addObject:@{ @"uid" : (acc[@"uid"] ?: @""),
                                  @"name" : (acc[@"name"] ?: @"账号"),
                                  @"ok" : @(aok),
                                  @"msg" : (amsg ?: @"") }];
            [sf2 signinNext:accs index:i + 1 results:results];
        }];
    }];
}

// 老版本存的 cookie 只有 .weibo.cn 域，这里顺手从 WebKit 里补全并回写
- (void)ensureCookies:(NSDictionary *)acc completion:(void (^)(NSString *json))done {
    NSString *cur = acc[@"cookies"];
    // 账号自带 weibo.com 登录态就原样用。以前这里无条件拿“全机网页会话”覆盖，
    // 等于批量任务里所有号都换成了同一个身份，签到才会冒出“请先登录 / 已签到”的假象。
    if ([cur isKindOfClass:[NSString class]] && [cur hasPrefix:@"["] && cur.length > 4) {
        if (LSCookieHasWeiboSession(cur)) { done(cur); return; }
    }
    // 读取 cookie 是异步的，WebKit 偶尔不回，这里限时兜底，避免整批签到永久卡住
    __block BOOL fired = NO;
    void (^emit)(NSString *) = ^(NSString *j) {
        if (fired) return;
        fired = YES;
        if (done) done(j ?: @"");
    };
    NSString *fallback = ([cur isKindOfClass:[NSString class]] ? cur : @"");
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{ emit(fallback); });

    NSMutableDictionary *copy = [acc mutableCopy];
    [[WKWebsiteDataStore defaultDataStore].httpCookieStore getAllCookies:^(NSArray<NSHTTPCookie *> *cookies) {
        NSString *webJSON = LSCollectCookiesJSON(cookies);
        NSString *json = webJSON;
        if ([cur isKindOfClass:[NSString class]] && [cur hasPrefix:@"["] && cur.length > 4) {
            // 账号本身是 JSON 但缺身份 cookie：只补非身份项，身份 cookie 一律不借用
            json = LSOnlyFillCookies(cur, webJSON);
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            if (json.length > 4) {
                copy[@"cookies"] = json;
                [LSStore upsert:copy];
                emit(json);
            } else {
                emit(fallback);
            }
        });
    }];
}

- (void)probeCheckinState:(NSString *)cookiesJSON {
    static BOOL probed = NO;
    static LSVerifyRunner *gScan = nil;
    if (probed) return;
    probed = YES;
    if (![cookiesJSON hasPrefix:@"["]) return;
    LSVerifyRunner *r = [[LSVerifyRunner alloc] init];
    r.scanOnly = YES;
    r.cookiesJSON = cookiesJSON;
    NSMutableString *acc = [NSMutableString string];
    r.log = ^(NSString *kind, NSString *text) {
        [acc appendFormat:@"%@\n", text];
    };
    __weak typeof(self) ws = self;
    r.onEnd = ^{
        typeof(self) sf = ws;
        if (!sf) return;
        NSString *msg = acc.length ? [acc copy] : @"没拿到扫描结果";
        if (msg.length > 900) msg = [msg substringToIndex:900];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.3 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            UIAlertController *a = [UIAlertController alertControllerWithTitle:@"超话页扫描"
                message:msg preferredStyle:UIAlertControllerStyleAlert];
            [a addAction:[UIAlertAction actionWithTitle:@"知道了" style:UIAlertActionStyleDefault handler:nil]];
            UIViewController *top = sf;
            while (top.presentedViewController) top = top.presentedViewController;
            [top presentViewController:a animated:YES completion:nil];
        });
    };
    gScan = r;
    [r start];
}

- (void)postCheckin:(NSString *)cookiesJSON completion:(void (^)(BOOL ok, NSString *msg))done {
    // 签到接口和评论/转发一样要校验 CSRF，先按账号单独取一次 XSRF-TOKEN，再发签到
    __weak typeof(self) ws = self;
    self.slXsrf = nil;
    [self fetchXsrf:cookiesJSON completion:^(NSString *token) {
        typeof(self) sf = ws;
        if (!sf) { done(NO, @"签到没跑起来，重开一下 App"); return; }
        [sf lsPostCheckin:cookiesJSON deep:0 completion:done];
    }];
}

- (void)lsPostCheckin:(NSString *)cookiesJSON deep:(NSInteger)deep
            completion:(void (^)(BOOL ok, NSString *msg))done {
    NSString *ck = LSHeaderFromCookiesJSON(cookiesJSON, @"weibo.com");
    if (ck.length == 0) {
        done(NO, @"需重新登录这个账号");
        return;
    }
    // 只有 .weibo.cn 的登录态签不了 weibo.com 的签到接口，直说不绕
    if ([cookiesJSON isKindOfClass:[NSString class]] && [cookiesJSON hasPrefix:@"["]
        && !LSCookieHasWeiboSession(cookiesJSON)) {
        done(NO, @"这个号缺 weibo.com 登录态，去账号页重新登录一次");
        return;
    }
    NSString *body = [NSString stringWithFormat:
        @"scene_id=pc_checkin&page_id=%@&timezone=Asia%%2FShanghai&lang=zh-CN&plat=Win32&ua=%@",
        kSuperId, LSURLEncode(kPCUA)];

    NSMutableURLRequest *r = [NSMutableURLRequest
        requestWithURL:[NSURL URLWithString:@"https://weibo.com/ajax_proxy/chaohua/page/checkin"]];
    r.HTTPMethod = @"POST";
    [r setValue:kPCUA forHTTPHeaderField:@"User-Agent"];
    [r setValue:@"application/json, text/plain, */*" forHTTPHeaderField:@"Accept"];
    [r setValue:@"zh-CN,zh;q=0.9" forHTTPHeaderField:@"Accept-Language"];
    [r setValue:[NSString stringWithFormat:@"https://weibo.com/p/%@", kSuperId] forHTTPHeaderField:@"Referer"];
    [r setValue:@"XMLHttpRequest" forHTTPHeaderField:@"X-Requested-With"];
    [r setValue:@"application/x-www-form-urlencoded; charset=UTF-8" forHTTPHeaderField:@"Content-Type"];
    [r setValue:@"https://weibo.com" forHTTPHeaderField:@"Origin"];
    [r setValue:@"same-origin" forHTTPHeaderField:@"Sec-Fetch-Site"];
    [r setValue:@"cors" forHTTPHeaderField:@"Sec-Fetch-Mode"];
    [r setValue:@"empty" forHTTPHeaderField:@"Sec-Fetch-Dest"];

    r.HTTPBody = [body dataUsingEncoding:NSUTF8StringEncoding];
    r.timeoutInterval = 20.0;

    NSString *xsrf = LSCookieValue(cookiesJSON, @"XSRF-TOKEN");
    if (xsrf.length == 0) xsrf = self.slXsrf;
    if (xsrf.length > 0 && [ck rangeOfString:@"XSRF-TOKEN="].location == NSNotFound) {
        ck = [NSString stringWithFormat:@"%@; XSRF-TOKEN=%@", ck, xsrf];
    }
    [r setValue:ck forHTTPHeaderField:@"Cookie"];
    [r setValue:@"1" forHTTPHeaderField:@"MWeibo-Pwa"];
    if (xsrf.length > 0) {
        NSString *decoded = [xsrf stringByRemovingPercentEncoding];
        [r setValue:(decoded.length ? decoded : xsrf) forHTTPHeaderField:@"X-XSRF-TOKEN"];
    }

    [[[NSURLSession sharedSession] dataTaskWithRequest:r
        completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
            BOOL ok = NO;
            NSString *msg = nil;
            NSString *vurl = nil;
            if (error) {
                msg = @"网络请求失败，检查网络后重试";
            } else {
                id obj = data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil;
                if ([obj isKindOfClass:[NSDictionary class]]) {
                    NSDictionary *j = (NSDictionary *)obj;
                    vurl = LSVerifyURLFromJSON(j);
                    NSString *code = [j[@"code"] description];
                    NSString *m = j[@"msg"];
                    if (![m isKindOfClass:[NSString class]] || m.length == 0) m = j[@"message"];
                    if (![m isKindOfClass:[NSString class]] || m.length == 0) m = j[@"error"];
                    if (![m isKindOfClass:[NSString class]] || m.length == 0) m = nil;
                    ok = ([code isEqualToString:@"100000"] || [code isEqualToString:@"0"]
                          || [j[@"ok"] integerValue] == 1);
                    msg = m;
                    if (!ok && msg && ([msg containsString:@"已签到"] || [msg containsString:@"已经签到"])) {
                        ok = YES;
                        // 标清来源：这是服务端说“今天本来就已经签过”，不是本次新签的
                        msg = [NSString stringWithFormat:@"服务端说今日已签（%@）", msg];
                    }
                    // 成功时也留一条可核对的服务端回执（code + msg），别让界面只剩一个“已签到”
                    if (ok && !msg.length) {
                        msg = (code.length ? [NSString stringWithFormat:@"code %@", code] : @"服务器已确认");
                    }
                    if (!ok && !msg) {
                        NSHTTPURLResponse *hr = (NSHTTPURLResponse *)response;
                        if (hr.statusCode == 401 || hr.statusCode == 403) msg = @"Cookie 已失效，请重新登录";
                        else msg = [NSString stringWithFormat:@"签到失败（%@）", code.length ? code : @"无返回"];
                    }
                } else {
                    NSHTTPURLResponse *hr = (NSHTTPURLResponse *)response;
                    msg = (hr.statusCode == 418 || hr.statusCode == 403) ? @"被微博拦截了，换个网络再试" : @"微博返回了看不懂的内容，稍后再试";
                }
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                if (!ok && vurl.length > 0 && deep < 1) {
                    __weak typeof(self) ws2 = self;
                    [self lsRunVerify:vurl cookies:cookiesJSON kind:@"checkin" completion:^(BOOL vok, NSString *newCk) {
                        typeof(self) sf2 = ws2;
                        if (!sf2) { done(NO, @"需要安全验证，请稍后重试"); return; }
                        if (vok && newCk.length > 0) {
                            // 身份守卫：验证器跑在共享网页会话里，回来的 SUB 可能不是这个号。
                            // 不是这个号就退回本号原 cookie 重签，绝不拿别人的身份换一个“已签到”。
                            NSString *subA = LSCookieValue(cookiesJSON, @"SUB");
                            NSString *subB = LSCookieValue(newCk, @"SUB");
                            if (subA.length && subB.length && ![subA isEqualToString:subB]) {
                                [sf2 superLikeLog:@"bad"
                                               text:@"⚠️ 验证回来的登录态不是这个号，已改用本号原 cookie 重签"];
                                [sf2 lsPostCheckin:cookiesJSON deep:deep + 1 completion:done];
                            } else {
                                [sf2 lsPostCheckin:newCk deep:deep + 1 completion:done];
                            }
                        } else {
                            done(NO, @"需要安全验证，自动过滑块没成功");
                        }
                    }];
                    return;
                }
                done(ok, msg);
            });
        }] resume];
}

- (void)signinCallback:(NSArray *)results summary:(NSString *)summary {
    // 只跑部分账号时，必须按 uid 合并进当天记录。
    // 以前这里整体覆盖，单跑一个号会把其他账号的签到记录一起冲掉，界面上全变「未签到」。
    NSString *todayKey = LSDateKey();
    NSArray *incoming = (results ? results : @[]);
    NSMutableArray *merged = [NSMutableArray array];
    id oldCk = [[NSUserDefaults standardUserDefaults] objectForKey:@"left_checkin"];
    if ([oldCk isKindOfClass:[NSDictionary class]] &&
        [((NSDictionary *)oldCk)[@"date"] isEqualToString:todayKey]) {
        id oldItems = ((NSDictionary *)oldCk)[@"items"];
        if ([oldItems isKindOfClass:[NSArray class]]) [merged addObjectsFromArray:(NSArray *)oldItems];
    }
    for (id it in incoming) {
        if (![it isKindOfClass:[NSDictionary class]]) continue;
        NSString *u = [NSString stringWithFormat:@"%@", ((NSDictionary *)it)[@"uid"] ?: @""];
        NSInteger hit = -1;
        for (NSInteger i = 0; i < (NSInteger)merged.count; i++) {
            id e = merged[i];
            if ([e isKindOfClass:[NSDictionary class]] &&
                [[NSString stringWithFormat:@"%@", ((NSDictionary *)e)[@"uid"] ?: @""] isEqualToString:u]) { hit = i; break; }
        }
        if (hit >= 0) [merged replaceObjectAtIndex:hit withObject:it];
        else [merged addObject:it];
    }
    NSDictionary *payload = @{ @"date" : todayKey, @"items" : merged };
    [[NSUserDefaults standardUserDefaults] setObject:payload forKey:@"left_checkin"];
    [[NSUserDefaults standardUserDefaults] synchronize];

    NSInteger okN = 0;
    for (id it in (results ?: @[])) {
        if ([it isKindOfClass:[NSDictionary class]] && [((NSDictionary *)it)[@"ok"] boolValue]) okN++;
    }
    if (okN > 0) {
        [self lsStatsAdd:@"checkin" n:okN];
        [self pushStats];
    }

    NSData *dr = [NSJSONSerialization dataWithJSONObject:payload options:0 error:nil];
    NSString *payloadJSON = dr ? [[NSString alloc] initWithData:dr encoding:NSUTF8StringEncoding] : @"{}";
    NSArray *a = @[ payloadJSON, (summary ? summary : @"") ];
    NSData *d = [NSJSONSerialization dataWithJSONObject:a options:0 error:nil];
    NSString *json = d ? [[NSString alloc] initWithData:d encoding:NSUTF8StringEncoding] : @"[\"{}\",\"\"]";
    NSString *js = [NSString stringWithFormat:
        @"window.__LS_CHECKIN__ = JSON.parse(%@[0]); if(window.lsSigninDone) window.lsSigninDone(%@[0], %@[1]);",
        json, json, json];
    [self.web evaluateJavaScript:js completionHandler:nil];
}

#pragma mark - 一键超Like

// 微博写接口（评论/转发/发帖）要校验 CSRF。Cookie 里没有 XSRF-TOKEN 时，
// 和 APK 一样去 weibo.com 首页抓 Set-Cookie 里的 XSRF-TOKEN。
- (void)fetchXsrf:(NSString *)cookiesJSON completion:(void (^)(NSString *token))done {
    // v1.11: 不再直接信 cookie 里那份 XSRF-TOKEN。验证 / 重新登录之后 session 已经换了，
    // 旧 token 发出去就是 invalid csrf token。统一向 weibo.com 要一份新的。
    [self fetchXsrfForce:cookiesJSON completion:done];
}

- (void)fetchXsrfForce:(NSString *)cookiesJSON completion:(void (^)(NSString *token))done {
    NSString *fromCookie = LSCookieValue(cookiesJSON, @"XSRF-TOKEN");
    NSString *ck = LSHeaderFromCookiesJSON(cookiesJSON, @"weibo.com");
    if (ck.length == 0) {
        done(nil);
        return;
    }
    NSMutableURLRequest *r = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"https://weibo.com/"]];
    r.HTTPMethod = @"GET";
    [r setValue:kPCUA forHTTPHeaderField:@"User-Agent"];
    [r setValue:@"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8" forHTTPHeaderField:@"Accept"];
    [r setValue:@"zh-CN,zh;q=0.9" forHTTPHeaderField:@"Accept-Language"];
    [r setValue:ck forHTTPHeaderField:@"Cookie"];
    r.timeoutInterval = 20.0;

    __weak typeof(self) ws = self;
    [[[NSURLSession sharedSession] dataTaskWithRequest:r
        completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
            NSString *token = nil;
            if (!error && [response isKindOfClass:[NSHTTPURLResponse class]]) {
                NSDictionary *hdrs = [(NSHTTPURLResponse *)response allHeaderFields];
                for (NSString *k in hdrs) {
                    if ([[k lowercaseString] rangeOfString:@"set-cookie"].location == NSNotFound) continue;
                    id v = hdrs[k];
                    NSArray *lines = [v isKindOfClass:[NSArray class]] ? v
                                    : ([v isKindOfClass:[NSString class]] ? @[ v ] : @[]);
                    for (id one in lines) {
                        if (![one isKindOfClass:[NSString class]]) continue;
                        NSRange rr = [(NSString *)one rangeOfString:@"XSRF-TOKEN="];
                        if (rr.location == NSNotFound) continue;
                        NSString *rest = [(NSString *)one substringFromIndex:rr.location + rr.length];
                        NSRange semi = [rest rangeOfString:@";"];
                        if (semi.location != NSNotFound) rest = [rest substringToIndex:semi.location];
                        rest = [rest stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                        if (rest.length > 0) { token = rest; break; }
                    }
                    if (token.length > 0) break;
                }
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                typeof(self) sf = ws;
                NSString *use = token.length ? token : fromCookie;
                if (sf && use.length > 0) sf.slXsrf = use;
                done(use);
            });
        }] resume];
}

- (NSString *)lsTodayCN {
    NSDateFormatter *f = [[NSDateFormatter alloc] init];
    f.dateFormat = @"yyyyMMdd";
    f.timeZone = [NSTimeZone timeZoneWithName:@"Asia/Shanghai"];
    return [f stringFromDate:[NSDate date]];
}

- (NSInteger)slCount:(NSDictionary *)d key:(NSString *)k max:(NSInteger)mx {
    id v = d[k];
    NSInteger n = 0;
    if ([v respondsToSelector:@selector(integerValue)]) n = [v integerValue];
    if (n < 0) n = 0;
    if (n > mx) n = mx;
    return n;
}

- (NSString *)slIdFromURL:(NSString *)u {
    if (![u isKindOfClass:[NSString class]] || u.length == 0) return @"";
    NSString *s = u;
    NSRange q = [s rangeOfString:@"?"];
    if (q.location != NSNotFound) s = [s substringToIndex:q.location];
    NSRange slash = [s rangeOfString:@"/" options:NSBackwardsSearch];
    if (slash.location != NSNotFound) s = [s substringFromIndex:slash.location + 1];
    return s;
}

- (void)startSuperLike:(NSDictionary *)opts {
    NSInteger nCmt = [self slCount:opts key:@"comment" max:10];
    NSInteger nRep = [self slCount:opts key:@"repost" max:20];
    NSInteger nPost = [self slCount:opts key:@"post" max:10];

    // 每轮开始前先清掉上一轮可能残留的验证器，避免隐形 WebView 堆叠
    self.verifying = NO;
    self.verifier = nil;
    self.slStep = nil;
    self.slPaused = NO;
    self.slCancelled = NO;
    self.slPendingStep = nil;

    if (nCmt + nRep + nPost == 0) {
        [self superLikeDone:NO msg:@"评论、转发、发帖至少要选一项" cmts:0 reps:0 posts:0];
        return;
    }
    NSArray *accs = [LSStore accounts];
    if (accs.count == 0) {
        [self superLikeDone:NO msg:@"先在账号页登录一个微博账号" cmts:0 reps:0 posts:0];
        return;
    }

    NSMutableArray *picked = [NSMutableArray array];
    id sel = opts[@"accounts"];
    if ([sel isKindOfClass:[NSArray class]] && [(NSArray *)sel count] > 0) {
        for (id u in (NSArray *)sel) {
            NSString *uid = [u description];
            for (NSDictionary *one in accs) {
                if ([[one[@"uid"] description] isEqualToString:uid]) {
                    [picked addObject:one];
                    break;
                }
            }
        }
    }
    if (picked.count == 0) [picked addObject:accs.firstObject];

    [self toast:(picked.count > 1
        ? [NSString stringWithFormat:@"%ld 个账号，逐个执行", (long)picked.count]
        : @"正在准备任务…")];
    __weak typeof(self) ws = self;
    if (picked.count > 1) {
        [self superLikeLog:@"info" text:[NSString stringWithFormat:@"共 %ld 个账号，逐个跑（同时只跑 1 个）", (long)picked.count]];
    }

    // 文案库和账号无关，只取一次
    [self fetchTemplates:^(NSDictionary *tpl) {
        typeof(self) s0 = ws;
        if (!s0) return;

        __block NSInteger accIdx = 0;
        __block NSInteger totalCmt = 0;
        __block NSInteger totalRep = 0;
        __block NSInteger totalPost = 0;
        __block NSInteger failAccs = 0;
        __block NSString *firstFail = nil;

        __block void (^runOne)(void) = nil;
        runOne = ^{
            typeof(self) sf = ws;
            if (!sf) return;
            if (sf.slCancelled) return;   // 已手动结束，不再起下一个账号

            if (accIdx >= (NSInteger)picked.count) {
                // 注意：这里绝对不能写 runOne = nil。
                // 当前调用栈正在执行 runOne 自己，立即置 nil 会释放正在执行的 block，
                // 下一句访问它的捕获变量就会崩在 KERN_INVALID_ADDRESS at 0x8。
                // 改成收尾之后用 dispatch_async 延迟一拍释放（见下）。
                NSMutableArray *bits = [NSMutableArray array];
                if (totalCmt > 0) [bits addObject:[NSString stringWithFormat:@"评论 %ld 条", (long)totalCmt]];
                if (totalRep > 0) [bits addObject:[NSString stringWithFormat:@"转发 %ld 条", (long)totalRep]];
                if (totalPost > 0) [bits addObject:[NSString stringWithFormat:@"发帖 %ld 条", (long)totalPost]];
                NSString *msg;
                if (bits.count > 0) {
                    NSString *head = picked.count > 1
                        ? [NSString stringWithFormat:@"%ld 个账号 · ", (long)picked.count]
                        : @"";
                    msg = [NSString stringWithFormat:@"完成：%@%@", head, [bits componentsJoinedByString:@" · "]];
                    if (failAccs > 0 && firstFail.length > 0) {
                        msg = [NSString stringWithFormat:@"%@（%ld 个账号没成功：%@）",
                              msg, (long)failAccs, firstFail];
                    }
                } else if (firstFail.length > 0) {
                    msg = [NSString stringWithFormat:@"一项都没成功：%@", firstFail];
                } else {
                    msg = @"今天能做的都做完了，明天再来";
                }
                if (totalCmt > 0) [sf lsStatsAdd:@"comment" n:totalCmt];
                if (totalRep > 0) [sf lsStatsAdd:@"repost" n:totalRep];
                if (totalPost > 0) [sf lsStatsAdd:@"post" n:totalPost];
                if (totalCmt + totalRep + totalPost > 0) [sf pushStats];
                [sf superLikeLog:@"info" text:@"■ 全部跑完"];
                [sf superLikeDone:(bits.count > 0)
                               msg:msg
                              cmts:totalCmt
                              reps:totalRep
                             posts:totalPost];
                // 等 runOne 的调用栈退出去之后再释放，避免自释放
                dispatch_async(dispatch_get_main_queue(), ^{
                    runOne = nil;
                });
                return;
            }

            NSDictionary *acc = picked[accIdx];
            NSString *accName = acc[@"name"] ?: acc[@"uid"] ?: @"账号";
            if (picked.count > 1) {
                [sf toast:[NSString stringWithFormat:@"账号 %ld/%ld：%@",
                          (long)(accIdx + 1), (long)picked.count, accName]];
            }
            [sf superLikeLog:@"info" text:[NSString stringWithFormat:@"▸ 账号 %ld/%ld %@",
                (long)(accIdx + 1), (long)picked.count, accName]];
            sf.slXsrf = nil;   // 每个账号各拿各的 CSRF

            NSString *accUid = acc[@"uid"] ?: accName;
            [sf ensureCookies:acc completion:^(NSString *json) {
                typeof(self) s1 = ws;
                if (!s1) return;
                [s1 fetchXsrf:json completion:^(NSString *xsrf) {
                    typeof(self) s2 = ws;
                    if (!s2) return;
                    [s2 fetchFeed:json completion:^(NSArray *feedIds, NSString *feedErr) {
                        typeof(self) s3 = ws;
                        if (!s3) return;
                        [s3 fetchEssencePosts:json completion:^(NSArray *repIds, NSString *repErr) {
                            typeof(self) s4 = ws;
                            if (!s4) return;
                            [s4 runSuperLike:json
                                          feed:feedIds
                                       reposts:repIds
                                           tpl:tpl
                                           uid:accUid
                                          nCmt:nCmt
                                          nRep:nRep
                                         nPost:nPost
                                     feedErr:feedErr
                                      repErr:repErr
                                 accountName:accName
                                      finish:^(NSInteger c, NSInteger r, NSInteger pp,
                                               NSString *fail, BOOL stopAll) {
                                typeof(self) s5 = ws;
                                if (!s5) return;
                                [s5 superLikeLog:(c + r + pp > 0 ? @"info" : @"bad")
                                             text:[NSString stringWithFormat:@"%@ · 评论 %ld · 转发 %ld · 发帖 %ld",
                                                   accName, (long)c, (long)r, (long)pp]];
                                totalCmt += c;
                                totalRep += r;
                                totalPost += pp;
                                if (fail.length > 0) {
                                    failAccs++;
                                    if (firstFail.length == 0) firstFail = fail;
                                }
                                if (stopAll) {
                                    [s5 superLikeDone:NO
                                                   msg:fail
                                                  cmts:totalCmt
                                                  reps:totalRep
                                                 posts:totalPost];
                                    return;
                                }
                                if (s5.slCancelled) return;   // 已手动结束，不再跑下一个账号
                                accIdx++;
                                double accGap = [[[s5 lsTiming] objectForKey:@"accGap"] doubleValue];
                                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(accGap * NSEC_PER_SEC)),
                                               dispatch_get_main_queue(), ^{
                                    if (s5.slCancelled) return;
                                    if (s5.slPaused) {
                                        s5.slPendingStep = runOne;
                                    } else if (runOne) {
                                        runOne();
                                    }
                                });
                            }];
                        }];
                    }];
                }];
            }];
        };

        runOne();
    }];
}

- (void)fetchTemplates:(void (^)(NSDictionary *tpl))done {
    NSString *url = @"https://raw.giteeusercontent.com/liyn19/left-superlike1/raw/master/templates.json";
    NSMutableURLRequest *r = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    r.timeoutInterval = 12.0;
    [r setValue:@"Left_Superlike iOS" forHTTPHeaderField:@"User-Agent"];

    [[[NSURLSession sharedSession] dataTaskWithRequest:r
        completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
            NSMutableArray *cmt = [NSMutableArray array];
            NSMutableArray *rep = [NSMutableArray array];
            NSMutableArray *post = [NSMutableArray array];
            NSMutableArray *cmtGroups = [NSMutableArray array];
            NSMutableArray *repGroups = [NSMutableArray array];
            NSMutableArray *postGroups = [NSMutableArray array];

            id obj = (!error && data) ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil;
            if ([obj isKindOfClass:[NSDictionary class]]) {
                id cats = ((NSDictionary *)obj)[@"categories"];
                if ([cats isKindOfClass:[NSDictionary class]]) {
                    NSDictionary *c = (NSDictionary *)cats;

                    id cm = c[@"comment"];
                    if ([cm isKindOfClass:[NSDictionary class]]) {
                        id gs = ((NSDictionary *)cm)[@"groups"];
                        if ([gs isKindOfClass:[NSArray class]]) {
                            for (id g in gs) {
                                if (![g isKindOfClass:[NSDictionary class]]) continue;
                                id cs = ((NSDictionary *)g)[@"contents"];
                                if (![cs isKindOfClass:[NSArray class]]) continue;
                                NSString *gn = ((NSDictionary *)g)[@"name"];
                                if (![gn isKindOfClass:[NSString class]] || gn.length == 0) gn = @"默认";
                                NSMutableArray *gItems = [NSMutableArray array];
                                for (id t in cs) {
                                    if (![t isKindOfClass:[NSString class]]) continue;
                                    NSString *ts = [(NSString *)t stringByTrimmingCharactersInSet:
                                        [NSCharacterSet whitespaceAndNewlineCharacterSet]];
                                    if (ts.length >= 2 && ts.length <= 120) {
                                        [cmt addObject:ts];
                                        [gItems addObject:ts];
                                    }
                                }
                                if (gItems.count > 0) {
                                    [cmtGroups addObject:@{ @"name" : gn, @"items" : gItems }];
                                }
                            }
                        }
                    }

                    id rp = c[@"repost"];
                    if ([rp isKindOfClass:[NSDictionary class]]) {
                        id gs = ((NSDictionary *)rp)[@"groups"];
                        if ([gs isKindOfClass:[NSArray class]]) {
                            for (id g in gs) {
                                if (![g isKindOfClass:[NSDictionary class]]) continue;
                                id cs = ((NSDictionary *)g)[@"contents"];
                                if (![cs isKindOfClass:[NSArray class]]) continue;
                                NSString *gn = ((NSDictionary *)g)[@"name"];
                                if (![gn isKindOfClass:[NSString class]] || gn.length == 0) gn = @"默认";
                                NSMutableArray *gItems = [NSMutableArray array];
                                for (id t in cs) {
                                    if (![t isKindOfClass:[NSString class]]) continue;
                                    NSString *ts = [(NSString *)t stringByTrimmingCharactersInSet:
                                        [NSCharacterSet whitespaceAndNewlineCharacterSet]];
                                    if (ts.length >= 2 && ts.length <= 120) {
                                        [rep addObject:ts];
                                        [gItems addObject:ts];
                                    }
                                }
                                if (gItems.count > 0) {
                                    [repGroups addObject:@{ @"name" : gn, @"items" : gItems }];
                                }
                            }
                        }
                    }

                    id ps = c[@"post"];
                    if ([ps isKindOfClass:[NSDictionary class]]) {
                        id gs = ((NSDictionary *)ps)[@"groups"];
                        if ([gs isKindOfClass:[NSArray class]]) {
                            for (id g in gs) {
                                if (![g isKindOfClass:[NSDictionary class]]) continue;
                                id cs = ((NSDictionary *)g)[@"contents"];
                                if (![cs isKindOfClass:[NSArray class]]) continue;
                                NSString *gn = ((NSDictionary *)g)[@"name"];
                                if (![gn isKindOfClass:[NSString class]] || gn.length == 0) gn = @"默认";
                                NSMutableArray *gItems = [NSMutableArray array];
                                for (id t in cs) {
                                    NSMutableArray *parts = [NSMutableArray array];
                                    if ([t isKindOfClass:[NSArray class]]) {
                                        for (id piece in (NSArray *)t) {
                                            if ([piece isKindOfClass:[NSString class]]) [parts addObject:piece];
                                        }
                                    } else if ([t isKindOfClass:[NSString class]]) {
                                        [parts addObject:t];
                                    }
                                    NSString *full = [parts componentsJoinedByString:@" "];
                                    full = [full stringByTrimmingCharactersInSet:
                                        [NSCharacterSet whitespaceAndNewlineCharacterSet]];
                                    if (full.length >= 4 && full.length <= 300) {
                                        [post addObject:full];
                                        [gItems addObject:full];
                                    }
                                }
                                if (gItems.count > 0) {
                                    [postGroups addObject:@{ @"name" : gn, @"items" : gItems }];
                                }
                            }
                        }
                    }
                }
            }

            if (cmt.count == 0) {
                [cmt addObjectsFromArray:@[
                    @"今天也在为左航骄傲，会一直陪着你走下去",
                    @"看你一路成长，每一步都算数",
                    @"舞台上的你太亮眼了，期待更多作品",
                    @"好好照顾自己，我们一直都在",
                    @"认真的人最值得被看见"]];
            }
            if (rep.count == 0) {
                [rep addObjectsFromArray:@[ @"#左航ZH[超话]# ", @"#加点zuo料# ", @"#为左航守护星愿# " ]];
            }

            // 自建分组的文案也进池子，超Like 会一起随机用
            NSDictionary *cu = [self lsTplCustom];
            for (NSString *cat in @[ @"comment", @"repost", @"post" ]) {
                id gs = cu[cat];
                if (![gs isKindOfClass:[NSArray class]]) continue;
                NSMutableArray *dst = nil;
                if ([cat isEqualToString:@"comment"]) dst = cmt;
                else if ([cat isEqualToString:@"repost"]) dst = rep;
                else dst = post;
                for (id g in (NSArray *)gs) {
                    if (![g isKindOfClass:[NSDictionary class]]) continue;
                    id its = ((NSDictionary *)g)[@"items"];
                    if (![its isKindOfClass:[NSArray class]]) continue;
                    for (id t in (NSArray *)its) {
                        if (![t isKindOfClass:[NSString class]]) continue;
                        NSString *ts = [(NSString *)t stringByTrimmingCharactersInSet:
                            [NSCharacterSet whitespaceAndNewlineCharacterSet]];
                        if (ts.length >= 2) [dst addObject:ts];
                    }
                }
            }

            NSDictionary *groups = @{
                @"comment" : (cmtGroups.count ? cmtGroups : @[]),
                @"repost" : (repGroups.count ? repGroups : @[]),
                @"post" : (postGroups.count ? postGroups : @[])
            };
            NSDictionary *out = @{ @"comment" : cmt, @"repost" : rep, @"post" : post,
                                   @"groups" : groups };
            dispatch_async(dispatch_get_main_queue(), ^{ done(out); });
        }] resume];
}

- (void)fetchFeed:(NSString *)cookiesJSON completion:(void (^)(NSArray *ids, NSString *err))done {
    NSString *ck = LSHeaderFromCookiesJSON(cookiesJSON, @"weibo.com");
    if (ck.length == 0) {
        done(@[], @"需重新登录这个账号");
        return;
    }
    NSString *flow = [kSuperId stringByAppendingString:@"_-_sort_time"];
    NSString *urlStr = [NSString stringWithFormat:
        @"https://weibo.com/ajax_proxy/chaohua/page?flowId=%@&page=1", flow];
    NSMutableURLRequest *r = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:urlStr]];
    r.HTTPMethod = @"GET";
    [r setValue:kPCUA forHTTPHeaderField:@"User-Agent"];
    [r setValue:@"application/json, text/plain, */*" forHTTPHeaderField:@"Accept"];
    [r setValue:@"zh-CN,zh;q=0.9" forHTTPHeaderField:@"Accept-Language"];
    [r setValue:[@"https://weibo.com/p/" stringByAppendingString:kSuperId] forHTTPHeaderField:@"Referer"];
    [r setValue:@"XMLHttpRequest" forHTTPHeaderField:@"X-Requested-With"];
    [r setValue:@"https://weibo.com" forHTTPHeaderField:@"Origin"];
    [r setValue:@"same-origin" forHTTPHeaderField:@"Sec-Fetch-Site"];
    [r setValue:@"cors" forHTTPHeaderField:@"Sec-Fetch-Mode"];
    [r setValue:@"empty" forHTTPHeaderField:@"Sec-Fetch-Dest"];
    [r setValue:ck forHTTPHeaderField:@"Cookie"];
    NSString *xsrf = LSCookieValue(cookiesJSON, @"XSRF-TOKEN");
    if (xsrf.length > 0) {
        NSString *decoded = [xsrf stringByRemovingPercentEncoding];
        [r setValue:(decoded.length ? decoded : xsrf) forHTTPHeaderField:@"X-XSRF-TOKEN"];
    }
    r.timeoutInterval = 20.0;

    [[[NSURLSession sharedSession] dataTaskWithRequest:r
        completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
            NSMutableArray *ids = [NSMutableArray array];
            NSString *err = nil;
            if (error) {
                err = @"拉帖子列表失败";
            } else {
                id obj = data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil;
                NSArray *items = nil;
                if ([obj isKindOfClass:[NSDictionary class]]) {
                    id it = ((NSDictionary *)obj)[@"items"];
                    if ([it isKindOfClass:[NSArray class]]) items = it;
                }
                for (id it in items) {
                    if (![it isKindOfClass:[NSDictionary class]]) continue;
                    id cat = ((NSDictionary *)it)[@"category"];
                    if (![cat isKindOfClass:[NSString class]] || ![cat containsString:@"feed"]) continue;
                    id d = ((NSDictionary *)it)[@"data"];
                    if (![d isKindOfClass:[NSDictionary class]]) continue;
                    id idstr = ((NSDictionary *)d)[@"idstr"];
                    if ([idstr isKindOfClass:[NSString class]] && [(NSString *)idstr length] > 0) {
                        if (![ids containsObject:idstr]) [ids addObject:idstr];
                    }
                }
                if (ids.count == 0) {
                    NSHTTPURLResponse *hr = (NSHTTPURLResponse *)response;
                    err = (hr.statusCode == 401 || hr.statusCode == 403)
                        ? @"Cookie 已失效，请重新登录" : @"这次没拉到帖子";
                }
            }
            dispatch_async(dispatch_get_main_queue(), ^{ done(ids, err); });
        }] resume];
}

- (void)fetchEssencePosts:(NSString *)cookiesJSON completion:(void (^)(NSArray *ids, NSString *err))done {
    NSString *ck = LSHeaderFromCookiesJSON(cookiesJSON, @"weibo.com");
    if (ck.length == 0) {
        done(@[], @"需重新登录这个账号");
        return;
    }
    NSString *flow = [kSuperId stringByAppendingString:@"_-_soul"];
    NSString *urlStr = [NSString stringWithFormat:
        @"https://weibo.com/ajax_proxy/chaohua/page?flowId=%@&page=1", flow];
    NSMutableURLRequest *r = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:urlStr]];
    r.HTTPMethod = @"GET";
    [r setValue:kPCUA forHTTPHeaderField:@"User-Agent"];
    [r setValue:@"application/json, text/plain, */*" forHTTPHeaderField:@"Accept"];
    [r setValue:@"zh-CN,zh;q=0.9" forHTTPHeaderField:@"Accept-Language"];
    [r setValue:[@"https://weibo.com/p/" stringByAppendingString:kSuperId] forHTTPHeaderField:@"Referer"];
    [r setValue:@"XMLHttpRequest" forHTTPHeaderField:@"X-Requested-With"];
    [r setValue:@"https://weibo.com" forHTTPHeaderField:@"Origin"];
    [r setValue:@"same-origin" forHTTPHeaderField:@"Sec-Fetch-Site"];
    [r setValue:@"cors" forHTTPHeaderField:@"Sec-Fetch-Mode"];
    [r setValue:@"empty" forHTTPHeaderField:@"Sec-Fetch-Dest"];
    [r setValue:ck forHTTPHeaderField:@"Cookie"];
    NSString *xsrf = LSCookieValue(cookiesJSON, @"XSRF-TOKEN");
    if (xsrf.length > 0) {
        NSString *decoded = [xsrf stringByRemovingPercentEncoding];
        [r setValue:(decoded.length ? decoded : xsrf) forHTTPHeaderField:@"X-XSRF-TOKEN"];
    }
    r.timeoutInterval = 20.0;

    [[[NSURLSession sharedSession] dataTaskWithRequest:r
        completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
            NSMutableArray *ids = [NSMutableArray array];
            NSString *err = nil;
            if (error) {
                err = @"拉帖子列表失败";
            } else {
                id obj = data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil;
                NSArray *items = nil;
                if ([obj isKindOfClass:[NSDictionary class]]) {
                    id it = ((NSDictionary *)obj)[@"items"];
                    if ([it isKindOfClass:[NSArray class]]) items = it;
                }
                for (id it in items) {
                    if (![it isKindOfClass:[NSDictionary class]]) continue;
                    id cat = ((NSDictionary *)it)[@"category"];
                    if (![cat isKindOfClass:[NSString class]] || ![cat containsString:@"feed"]) continue;
                    id d = ((NSDictionary *)it)[@"data"];
                    if (![d isKindOfClass:[NSDictionary class]]) continue;
                    id idstr = ((NSDictionary *)d)[@"idstr"];
                    if ([idstr isKindOfClass:[NSString class]] && [(NSString *)idstr length] > 0) {
                        if (![ids containsObject:idstr]) [ids addObject:idstr];
                    }
                }
                if (ids.count == 0) {
                    NSHTTPURLResponse *hr = (NSHTTPURLResponse *)response;
                    err = (hr.statusCode == 401 || hr.statusCode == 403)
                        ? @"Cookie 已失效，请重新登录" : @"这次没拉到超话精华帖";
                }
            }
            dispatch_async(dispatch_get_main_queue(), ^{ done(ids, err); });
        }] resume];
}

- (void)runSuperLike:(NSString *)cookiesJSON
                feed:(NSArray *)feedIds
             reposts:(NSArray *)repIds
                 tpl:(NSDictionary *)tpl
                 uid:(NSString *)accUid
                nCmt:(NSInteger)nCmt
                nRep:(NSInteger)nRep
               nPost:(NSInteger)nPost
             feedErr:(NSString *)feedErr
              repErr:(NSString *)repErr
         accountName:(NSString *)accountName
              finish:(void (^)(NSInteger cmts, NSInteger reps, NSInteger posts,
                               NSString *fail, BOOL stopAll))finish {

    self.curAccName = (accountName.length ? accountName : nil);
    NSString *today = [self lsTodayCN];
    NSString *doneKey = (accUid.length > 0) ? accUid : (accountName ?: @"?");
    NSDictionary *st = [[NSUserDefaults standardUserDefaults] objectForKey:@"left_superlike"];
    NSMutableSet *doneFeed = [NSMutableSet set];
    NSMutableSet *doneRep = [NSMutableSet set];
    if ([st isKindOfClass:[NSDictionary class]]) {
        id d = st[@"date"];
        if ([d isKindOfClass:[NSString class]] && [d isEqual:today]) {
            // 按账号分别取已做记录：不同账号互不影响，
            // 否则排在后面的账号会被前面账号的记录全部过滤掉
            id byAcc = st[@"byAcc"];
            if ([byAcc isKindOfClass:[NSDictionary class]]) {
                id mine = ((NSDictionary *)byAcc)[doneKey];
                if ([mine isKindOfClass:[NSDictionary class]]) {
                    id a = ((NSDictionary *)mine)[@"feed"];
                    if ([a isKindOfClass:[NSArray class]]) [doneFeed addObjectsFromArray:a];
                    id b = ((NSDictionary *)mine)[@"repost"];
                    if ([b isKindOfClass:[NSArray class]]) [doneRep addObjectsFromArray:b];
                }
            }
        }
    }

    NSArray *cmtTexts = tpl[@"comment"];
    NSArray *repTexts = tpl[@"repost"];
    NSArray *postTexts = tpl[@"post"];
    if (![cmtTexts isKindOfClass:[NSArray class]]) cmtTexts = @[];
    if (![repTexts isKindOfClass:[NSArray class]]) repTexts = @[];
    if (![postTexts isKindOfClass:[NSArray class]]) postTexts = @[];

    NSMutableArray *queue = [NSMutableArray array];

    NSInteger want = nCmt;
    for (NSString *i in feedIds) {
        if (want <= 0) break;
        if ([doneFeed containsObject:i]) continue;
        [queue addObject:@{ @"kind" : @"comment", @"id" : i }];
        want--;
    }

    want = nRep;
    NSMutableArray *shuffledRep = [NSMutableArray arrayWithArray:repIds];
    for (NSInteger k = (NSInteger)shuffledRep.count - 1; k > 0; k--) {
        NSInteger j = arc4random_uniform((uint32_t)(k + 1));
        [shuffledRep exchangeObjectAtIndex:k withObjectAtIndex:j];
    }
    for (NSString *i in shuffledRep) {
        if (want <= 0) break;
        if ([doneRep containsObject:i]) continue;
        NSString *t = repTexts.count ? repTexts[arc4random_uniform((uint32_t)repTexts.count)] : @"转发支持";
        [queue addObject:@{ @"kind" : @"repost", @"id" : i, @"text" : t }];
        want--;
    }

    for (NSInteger i = 0; i < nPost; i++) {
        if (postTexts.count == 0) break;
        NSString *t = postTexts[arc4random_uniform((uint32_t)postTexts.count)];
        [queue addObject:@{ @"kind" : @"post", @"text" : t }];
    }

    if (queue.count == 0) {
        NSString *msg = nil;
        if (nCmt > 0 && feedIds.count == 0 && feedErr) msg = feedErr;
        else if (nRep > 0 && repIds.count == 0 && repErr) msg = repErr;
        else if (nPost > 0 && postTexts.count == 0) msg = @"文案库还没拉到发帖文案";
        else if (nRep > 0 && repIds.count > 0) msg = @"这个号今天的精华帖已经转发过了";
        else if (nCmt > 0 && feedIds.count > 0) msg = @"这个号今天的帖子已经评论过了";
        if (msg == nil) msg = @"今天能做的都做完了，明天再来";
        finish(0, 0, 0, msg, NO);
        return;
    }

    [self superLikeLog:@"info" text:[NSString stringWithFormat:@"▶ %@ · 本轮 %ld 项",
        (accountName ?: @"账号"), (long)queue.count]];
    [self toast:[NSString stringWithFormat:@"开始执行 %ld 项", (long)queue.count]];

    __block NSInteger idx = 0;
    __block NSInteger cmtN = 0;
    __block NSInteger repN = 0;
    __block NSInteger postN = 0;
    __block NSString *failMsg = nil;
    __block NSInteger failStreak = 0;
    __block NSMutableSet *newFeed = [NSMutableSet set];
    __block NSMutableSet *newRep = [NSMutableSet set];
    __weak typeof(self) ws = self;
    void (^step)(void) = nil;

    step = ^{
        typeof(self) sf = ws;
        if (!sf) return;
        if (sf.slCancelled) return;   // 已手动结束

        if (idx >= (NSInteger)queue.count) {
            NSMutableArray *allFeed = [NSMutableArray arrayWithArray:[doneFeed allObjects]];
            [allFeed addObjectsFromArray:[newFeed allObjects]];
            NSMutableArray *allRep = [NSMutableArray arrayWithArray:[doneRep allObjects]];
            [allRep addObjectsFromArray:[newRep allObjects]];
            NSMutableDictionary *byAcc = [NSMutableDictionary dictionary];
            id oldBy = st[@"byAcc"];
            if ([oldBy isKindOfClass:[NSDictionary class]]) [byAcc addEntriesFromDictionary:oldBy];
            byAcc[doneKey] = @{ @"feed" : allFeed, @"repost" : allRep };
            [[NSUserDefaults standardUserDefaults] setObject:@{
                @"date" : today, @"byAcc" : byAcc } forKey:@"left_superlike"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            sf.slStep = nil;

            NSString *fail = nil;
            if ((cmtN + repN + postN) == 0) {
                fail = (failMsg.length > 0) ? failMsg : @"一项都没成功，可能要过会儿再试";
            }
            finish(cmtN, repN, postN, fail, NO);
            return;
        }

        NSDictionary *job = queue[idx];
        NSString *kind = job[@"kind"];

        void (^next)(BOOL blocked, NSString *blockMsg) = ^(BOOL blocked, NSString *blockMsg) {
            typeof(self) s5 = ws;
            if (!s5 || s5.slCancelled) return;
            idx++;
            [s5 superLikeProgress:idx total:queue.count cmts:cmtN reps:repN posts:postN];
            if (blocked) {
                NSMutableArray *allFeed = [NSMutableArray arrayWithArray:[doneFeed allObjects]];
                [allFeed addObjectsFromArray:[newFeed allObjects]];
                NSMutableArray *allRep = [NSMutableArray arrayWithArray:[doneRep allObjects]];
                [allRep addObjectsFromArray:[newRep allObjects]];
                NSMutableDictionary *byAcc2 = [NSMutableDictionary dictionary];
                id oldBy2 = st[@"byAcc"];
                if ([oldBy2 isKindOfClass:[NSDictionary class]]) [byAcc2 addEntriesFromDictionary:oldBy2];
                byAcc2[doneKey] = @{ @"feed" : allFeed, @"repost" : allRep };
                [[NSUserDefaults standardUserDefaults] setObject:@{
                    @"date" : today, @"byAcc" : byAcc2 } forKey:@"left_superlike"];
                [[NSUserDefaults standardUserDefaults] synchronize];
                s5.slStep = nil;
                finish(cmtN, repN, postN, blockMsg, YES);
                return;
            }
            double stepGap = [[[s5 lsTiming] objectForKey:@"stepGap"] doubleValue];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(stepGap * NSEC_PER_SEC)),
                           dispatch_get_main_queue(), ^{
                if (s5.slCancelled) return;
                if (s5.slPaused) {
                    // 暂停中：把这一步先存起来，等用户点继续再执行
                    s5.slPendingStep = s5.slStep;
                } else if (s5.slStep) {
                    s5.slStep();
                }
            });
        };

        if ([kind isEqualToString:@"comment"]) {
            NSString *idstr = job[@"id"];
            NSString *text = cmtTexts.count ? cmtTexts[arc4random_uniform((uint32_t)cmtTexts.count)] : @"支持";
            [sf postComment:cookiesJSON idstr:idstr text:text completion:^(BOOL ok, NSString *msg) {
                if (ok) {
                    cmtN++;
                    failStreak = 0;
                    [newFeed addObject:idstr];
                    [sf superLikeLog:@"ok" text:[NSString stringWithFormat:@"评论 · %@ · %@",
                        idstr, (accountName.length ? accountName : (accUid ?: @"账号"))]];
                    next(NO, nil);
                } else {
                    if (failMsg == nil) failMsg = (msg.length ? msg : @"未知原因");
                    [sf superLikeLog:@"bad" text:[NSString stringWithFormat:@"评论 · %@ · %@",
                        idstr, (msg.length ? msg : @"失败")]];
                    failStreak++;
                    if (failStreak >= 3) {
                        next(YES, [NSString stringWithFormat:@"连续 3 项失败：%@", failMsg]);
                        return;
                    }
                    BOOL blocked = LSIsRateLimited(msg);
                    next(blocked, blocked ? [NSString stringWithFormat:@"被拦了，先停一下：%@", msg] : nil);
                }
            }];
        } else if ([kind isEqualToString:@"repost"]) {
            NSString *idstr = job[@"id"];
            NSString *text = job[@"text"];
            [sf postRepost:cookiesJSON idstr:idstr text:text completion:^(BOOL ok, NSString *msg) {
                if (ok) {
                    repN++;
                    failStreak = 0;
                    [newRep addObject:idstr];
                    [sf superLikeLog:@"ok" text:[NSString stringWithFormat:@"转发 · %@ · %@",
                        idstr, (accountName.length ? accountName : (accUid ?: @"账号"))]];
                    next(NO, nil);
                } else {
                    if (failMsg == nil) failMsg = (msg.length ? msg : @"未知原因");
                    [sf superLikeLog:@"bad" text:[NSString stringWithFormat:@"转发 · %@ · %@",
                        idstr, (msg.length ? msg : @"失败")]];
                    failStreak++;
                    if (failStreak >= 3) {
                        next(YES, [NSString stringWithFormat:@"连续 3 项失败：%@", failMsg]);
                        return;
                    }
                    BOOL blocked = LSIsRateLimited(msg);
                    next(blocked, blocked ? [NSString stringWithFormat:@"被拦了，先停一下：%@", msg] : nil);
                }
            }];
        } else {
            NSString *text = job[@"text"];
            [sf postPublish:cookiesJSON text:text uid:accUid completion:^(BOOL ok, NSString *msg) {
                if (ok) {
                    postN++;
                    failStreak = 0;
                    [sf superLikeLog:@"ok" text:[NSString stringWithFormat:@"发帖 · 成功 · %@",
                        (accountName.length ? accountName : (accUid ?: @"账号"))]];
                } else {
                    if (failMsg == nil) failMsg = (msg.length ? msg : @"未知原因");
                    [sf superLikeLog:@"bad" text:[NSString stringWithFormat:@"发帖 · %@",
                        (msg.length ? msg : @"失败")]];
                    failStreak++;
                    if (failStreak >= 3) {
                        next(YES, [NSString stringWithFormat:@"连续 3 项失败：%@", failMsg]);
                        return;
                    }
                }
                BOOL blocked = (!ok && LSIsRateLimited(msg));
                next(blocked, blocked ? [NSString stringWithFormat:@"被拦了，先停一下：%@", msg] : nil);
            }];
        }
    };

    self.slStep = step;
    step();
}

- (void)postRepost:(NSString *)cookiesJSON idstr:(NSString *)idstr text:(NSString *)text
         completion:(void (^)(BOOL ok, NSString *msg))done {
    [self lsPostRepost:cookiesJSON idstr:idstr text:text deep:0 completion:done];
}

- (void)lsPostRepost:(NSString *)cookiesJSON idstr:(NSString *)idstr text:(NSString *)text
         deep:(NSInteger)deep completion:(void (^)(BOOL ok, NSString *msg))done {
    __block NSString *nid = nil;   // v1.13: 微博回的新微博 id
    NSString *ck = LSHeaderFromCookiesJSON(cookiesJSON, @"weibo.com");
    if (ck.length == 0) { done(NO, @"需重新登录这个账号"); return; }
    NSString *form = [NSString stringWithFormat:
        @"id=%@&comment=%@&pic_id=&is_repost=0&comment_ori=0&is_comment=0&visible=0&share_id=&fp=%@",
        LSURLEncode(idstr), LSURLEncode(text), LSRandomFp()];

    NSMutableURLRequest *r = [NSMutableURLRequest
        requestWithURL:[NSURL URLWithString:@"https://weibo.com/ajax/statuses/normal_repost"]];
    r.HTTPMethod = @"POST";
    [r setValue:kPCUA forHTTPHeaderField:@"User-Agent"];
    [r setValue:@"application/json, text/plain, */*" forHTTPHeaderField:@"Accept"];
    [r setValue:@"zh-CN,zh;q=0.9" forHTTPHeaderField:@"Accept-Language"];
    [r setValue:[NSString stringWithFormat:@"https://weibo.com/p/%@", kSuperId] forHTTPHeaderField:@"Referer"];
    [r setValue:@"XMLHttpRequest" forHTTPHeaderField:@"X-Requested-With"];
    [r setValue:@"https://weibo.com" forHTTPHeaderField:@"Origin"];
    [r setValue:@"same-origin" forHTTPHeaderField:@"Sec-Fetch-Site"];
    [r setValue:@"cors" forHTTPHeaderField:@"Sec-Fetch-Mode"];
    [r setValue:@"empty" forHTTPHeaderField:@"Sec-Fetch-Dest"];
    [r setValue:@"application/x-www-form-urlencoded; charset=UTF-8" forHTTPHeaderField:@"Content-Type"];
    // v1.11: 以刚刷新的全局值为准（cookie 里那份可能是旧的）
    NSString *xsrf = self.slXsrf;
    if (xsrf.length == 0) xsrf = LSCookieValue(cookiesJSON, @"XSRF-TOKEN");
    // v1.11: 一律覆盖成同一个新值，保证 Cookie 与 X-XSRF-TOKEN 咬合
    NSString *ckSend = (xsrf.length > 0) ? LSReplaceCookieValue(ck, @"XSRF-TOKEN", xsrf) : ck;
    [r setValue:ckSend forHTTPHeaderField:@"Cookie"];
    [r setValue:@"1" forHTTPHeaderField:@"MWeibo-Pwa"];
    if (xsrf.length > 0) {
        [r setValue:xsrf forHTTPHeaderField:@"X-XSRF-TOKEN"];
    }
    r.HTTPBody = [form dataUsingEncoding:NSUTF8StringEncoding];
    r.timeoutInterval = 20.0;

    [[[NSURLSession sharedSession] dataTaskWithRequest:r
        completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
            BOOL ok = NO;
            NSString *msg = nil;
            NSString *vurl = nil;
            if (error) {
                msg = @"网络请求失败";
            } else {
                id obj = data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil;
                if ([obj isKindOfClass:[NSDictionary class]]) {
                    NSDictionary *j = (NSDictionary *)obj;
                    vurl = LSVerifyURLFromJSON(j);
                    NSString *code = [j[@"code"] description];
                    NSString *m = j[@"msg"];
                    if (![m isKindOfClass:[NSString class]] || m.length == 0) m = j[@"message"];
                    if (![m isKindOfClass:[NSString class]] || m.length == 0) m = j[@"error"];
                    if (![m isKindOfClass:[NSString class]] || m.length == 0) m = nil;
                    id dataObj = j[@"data"];
                    BOOL hasId = NO;
                    if ([dataObj isKindOfClass:[NSDictionary class]]) {
                        id mid = ((NSDictionary *)dataObj)[@"id"];
                        hasId = LSValidPostId(mid);
                        if (hasId) nid = [mid description];
                    }
                    ok = ([j[@"ok"] integerValue] == 1 || hasId || [code isEqualToString:@"100000"]);
                    if (!ok && m && [m containsString:@"成功"]) ok = YES;
                    if (!ok) {
                        NSString *rs = data.length ? [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] : nil;
                        if (rs.length > 220) rs = [rs substringToIndex:220];
                        if (!m) {
                            NSString *dbg = [NSString stringWithFormat:@"转发被驳回 · 原文：%@", (rs.length ? rs : @"(空)")];
                            dispatch_async(dispatch_get_main_queue(), ^{ [self superLikeLog:@"bad" text:dbg]; });
                        } else if (LSMsgLooksVerify(m)) {
                            // v1.12: 微博只回一句 verify 时，把原文留下来，才能看出有没有藏 verify_url
                            NSString *dbg = [NSString stringWithFormat:@"转发要验证 · 原文：%@", (rs.length ? rs : @"(空)")];
                            dispatch_async(dispatch_get_main_queue(), ^{ [self superLikeLog:@"bad" text:dbg]; });
                        }
                    }
                    msg = m ?: (ok ? nil : @"转发没成功");
                    if (!ok && vurl.length == 0 && LSMsgLooksVerify(m)) {
                        vurl = @"https://security.weibo.com/verify/index";
                    }
                } else {
                    NSHTTPURLResponse *hr = (NSHTTPURLResponse *)response;
                    msg = (hr.statusCode == 418 || hr.statusCode == 403) ? @"被微博拦截了" : @"返回异常";
                }
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                if (!ok && vurl.length > 0 && deep < 2) {
                    __weak typeof(self) ws2 = self;
                    [self lsRunVerify:vurl cookies:cookiesJSON kind:@"repost" completion:^(BOOL vok, NSString *newCk) {
                        typeof(self) sf2 = ws2;
                        if (!sf2) { done(NO, @"需要安全验证，请稍后重试"); return; }
                        if (vok && newCk.length > 0) {
                            // v1.10 身份守卫：验证器跑在共享网页会话里，回来的 SUB 可能不是这个号
                            NSString *subA = LSCookieValue(cookiesJSON, @"SUB");
                            NSString *subB = LSCookieValue(newCk, @"SUB");
                            NSString *useCk = newCk;
                            if (subA.length && subB.length && ![subA isEqualToString:subB]) {
                                [sf2 superLikeLog:@"bad" text:@"⚠️ 验证回来的登录态不是这个号，已改用本号原 cookie 重试"];
                                useCk = cookiesJSON;
                            }
                            [sf2 fetchXsrfForce:useCk completion:^(NSString *tk) {
                                [sf2 lsPostRepost:useCk idstr:idstr text:text deep:deep + 1 completion:done];
                            }];
                        } else {
                            done(NO, @"验证没通过（微博还要求验证，可再点一次「重开验证」）");
                        }
                    }];
                    return;
                }
                if (!ok && LSMsgLooksCsrf(msg) && deep < 2) {
                    [self superLikeLog:@"info" text:@"CSRF 过期了，正在换最新 XSRF-TOKEN 重试"];
                    __weak typeof(self) wsc = self;
                    [self fetchXsrfForce:cookiesJSON completion:^(NSString *tk) {
                        typeof(self) sfc = wsc;
                        if (!sfc) { done(NO, msg); return; }
                        [sfc lsPostRepost:cookiesJSON idstr:idstr text:text deep:deep + 1 completion:done];
                    }];
                    return;
                }
                if (ok && nid.length > 0) {
                    // v1.13: 微博说成功不等于真发出去了，回头查一次这条在不在
                    NSString *showU = [NSString stringWithFormat:@"https://weibo.com/ajax/statuses/show?id=%@", nid];
                    NSMutableURLRequest *sr = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:showU]];
                    [sr setValue:kPCUA forHTTPHeaderField:@"User-Agent"];
                    [sr setValue:ckSend forHTTPHeaderField:@"Cookie"];
                    [sr setValue:@"1" forHTTPHeaderField:@"MWeibo-Pwa"];
                    [sr setValue:@"https://weibo.com/" forHTTPHeaderField:@"Referer"];
                    [sr setValue:@"application/json, text/plain, */*" forHTTPHeaderField:@"Accept"];
                    sr.timeoutInterval = 15.0;
                    __weak typeof(self) wsv = self;
                    [[[NSURLSession sharedSession] dataTaskWithRequest:sr completionHandler:^(NSData *sd, NSURLResponse *srp, NSError *se) {
                        BOOL exist = NO, gone = NO;
                        NSString *link = nil;
                        NSString *why = nil;
                        if (!se && sd.length) {
                            id o = [NSJSONSerialization JSONObjectWithData:sd options:0 error:nil];
                            if ([o isKindOfClass:[NSDictionary class]]) {
                                NSDictionary *d = (NSDictionary *)o;
                                NSString *sid = [d[@"id"] description];
                                if (LSValidPostId(sid)) {
                                    exist = YES;
                                    NSString *mb = [d[@"mblogid"] description];
                                    NSString *uid = nil;
                                    id uo = d[@"user"];
                                    if ([uo isKindOfClass:[NSDictionary class]]) {
                                        uid = [((NSDictionary *)uo)[@"id"] description];
                                    }
                                    if (uid.length && mb.length) {
                                        link = [NSString stringWithFormat:@"https://weibo.com/%@/%@", uid, mb];
                                    }
                                } else {
                                    NSString *mm = [d[@"msg"] description];
                                    if (mm.length) why = mm;
                                    if ([[d[@"code"] description] isEqualToString:@"-100"]) gone = YES;
                                    if (why.length && ([why containsString:@"不存在"] || [why containsString:@"删除"])) gone = YES;
                                }
                            }
                        }
                        dispatch_async(dispatch_get_main_queue(), ^{
                            typeof(self) sv = wsv;
                            if (!sv) { done(ok, msg); return; }
                            if (exist) {
                                [sv superLikeLog:@"ok" text:[NSString stringWithFormat:@"✓ 已查证这条发出去了%@", (link.length ? [NSString stringWithFormat:@" · %@", link] : @"")]];
                                done(YES, nil);
                            } else if (gone) {
                                [sv superLikeLog:@"bad" text:[NSString stringWithFormat:@"⚠️ 微博回了成功，但这条查不到（%@）—— 被审核/限转了，按失败算", (why.length ? why : @"不存在")]];
                                done(NO, @"微博说成功但这条查不到，可能被审核或限转");
                            } else {
                                [sv superLikeLog:@"info" text:@"⚠️ 微博说成功，但这次没能二次确认"];
                                done(YES, nil);
                            }
                        });
                    }] resume];
                    return;
                }
                done(ok, msg);
            });
        }] resume];
}

- (void)postComment:(NSString *)cookiesJSON idstr:(NSString *)idstr text:(NSString *)text
          completion:(void (^)(BOOL ok, NSString *msg))done {
    [self lsPostComment:cookiesJSON idstr:idstr text:text deep:0 completion:done];
}

- (void)lsPostComment:(NSString *)cookiesJSON idstr:(NSString *)idstr text:(NSString *)text
          deep:(NSInteger)deep completion:(void (^)(BOOL ok, NSString *msg))done {
    NSString *ck = LSHeaderFromCookiesJSON(cookiesJSON, @"weibo.com");
    if (ck.length == 0) { done(NO, @"需重新登录这个账号"); return; }
    NSString *form = [NSString stringWithFormat:
        @"id=%@&comment=%@&pic_id=&is_repost=0&comment_ori=0&is_comment=0&mark=followtopweibo&fp=%@",
        LSURLEncode(idstr), LSURLEncode(text), LSRandomFp()];

    NSMutableURLRequest *r = [NSMutableURLRequest
        requestWithURL:[NSURL URLWithString:@"https://weibo.com/ajax/comments/create"]];
    r.HTTPMethod = @"POST";
    [r setValue:kPCUA forHTTPHeaderField:@"User-Agent"];
    [r setValue:@"application/json, text/plain, */*" forHTTPHeaderField:@"Accept"];
    [r setValue:@"zh-CN,zh;q=0.9" forHTTPHeaderField:@"Accept-Language"];
    [r setValue:@"https://weibo.com/" forHTTPHeaderField:@"Referer"];
    [r setValue:@"XMLHttpRequest" forHTTPHeaderField:@"X-Requested-With"];
    [r setValue:@"https://weibo.com" forHTTPHeaderField:@"Origin"];
    [r setValue:@"same-origin" forHTTPHeaderField:@"Sec-Fetch-Site"];
    [r setValue:@"cors" forHTTPHeaderField:@"Sec-Fetch-Mode"];
    [r setValue:@"empty" forHTTPHeaderField:@"Sec-Fetch-Dest"];
    [r setValue:@"application/x-www-form-urlencoded; charset=UTF-8" forHTTPHeaderField:@"Content-Type"];
    // v1.11: 以刚刷新的全局值为准（cookie 里那份可能是旧的）
    NSString *xsrf = self.slXsrf;
    if (xsrf.length == 0) xsrf = LSCookieValue(cookiesJSON, @"XSRF-TOKEN");
    // v1.11: 一律覆盖成同一个新值，保证 Cookie 与 X-XSRF-TOKEN 咬合
    NSString *ckSend = (xsrf.length > 0) ? LSReplaceCookieValue(ck, @"XSRF-TOKEN", xsrf) : ck;
    [r setValue:ckSend forHTTPHeaderField:@"Cookie"];
    [r setValue:@"1" forHTTPHeaderField:@"MWeibo-Pwa"];
    if (xsrf.length > 0) {
        [r setValue:xsrf forHTTPHeaderField:@"X-XSRF-TOKEN"];
    }
    r.HTTPBody = [form dataUsingEncoding:NSUTF8StringEncoding];
    r.timeoutInterval = 20.0;

    [[[NSURLSession sharedSession] dataTaskWithRequest:r
        completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
            BOOL ok = NO;
            NSString *msg = nil;
            NSString *vurl = nil;
            if (error) {
                msg = @"网络请求失败";
            } else {
                id obj = data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil;
                if ([obj isKindOfClass:[NSDictionary class]]) {
                    NSDictionary *j = (NSDictionary *)obj;
                    vurl = LSVerifyURLFromJSON(j);
                    NSString *code = [j[@"code"] description];
                    NSString *m = j[@"msg"];
                    if (![m isKindOfClass:[NSString class]] || m.length == 0) m = j[@"message"];
                    if (![m isKindOfClass:[NSString class]] || m.length == 0) m = j[@"error"];
                    if (![m isKindOfClass:[NSString class]] || m.length == 0) m = nil;
                    id dataObj = j[@"data"];
                    BOOL hasId = NO;
                    if ([dataObj isKindOfClass:[NSDictionary class]]) {
                        id mid = ((NSDictionary *)dataObj)[@"id"];
                        hasId = (mid != nil && [mid description].length > 0);
                    }
                    ok = ([j[@"ok"] integerValue] == 1 || hasId || [code isEqualToString:@"100000"]);
                    if (!ok && m && [m containsString:@"成功"]) ok = YES;
                    msg = m ?: (ok ? nil : @"评论没发出去");
                    if (!ok && vurl.length == 0 && LSMsgLooksVerify(m)) {
                        vurl = @"https://security.weibo.com/verify/index";
                    }
                } else {
                    NSHTTPURLResponse *hr = (NSHTTPURLResponse *)response;
                    msg = (hr.statusCode == 418 || hr.statusCode == 403) ? @"被微博拦截了" : @"返回异常";
                }
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                if (!ok && vurl.length > 0 && deep < 2) {
                    __weak typeof(self) ws2 = self;
                    [self lsRunVerify:vurl cookies:cookiesJSON kind:@"comment" completion:^(BOOL vok, NSString *newCk) {
                        typeof(self) sf2 = ws2;
                        if (!sf2) { done(NO, @"需要安全验证，请稍后重试"); return; }
                        if (vok && newCk.length > 0) {
                            // v1.10 身份守卫：验证器跑在共享网页会话里，回来的 SUB 可能不是这个号
                            NSString *subA = LSCookieValue(cookiesJSON, @"SUB");
                            NSString *subB = LSCookieValue(newCk, @"SUB");
                            NSString *useCk = newCk;
                            if (subA.length && subB.length && ![subA isEqualToString:subB]) {
                                [sf2 superLikeLog:@"bad" text:@"⚠️ 验证回来的登录态不是这个号，已改用本号原 cookie 重试"];
                                useCk = cookiesJSON;
                            }
                            [sf2 fetchXsrfForce:useCk completion:^(NSString *tk) {
                                [sf2 lsPostComment:useCk idstr:idstr text:text deep:deep + 1 completion:done];
                            }];
                        } else {
                            done(NO, @"验证没通过（微博还要求验证，可再点一次「重开验证」）");
                        }
                    }];
                    return;
                }
                if (!ok && LSMsgLooksCsrf(msg) && deep < 2) {
                    [self superLikeLog:@"info" text:@"CSRF 过期了，正在换最新 XSRF-TOKEN 重试"];
                    __weak typeof(self) wsc = self;
                    [self fetchXsrfForce:cookiesJSON completion:^(NSString *tk) {
                        typeof(self) sfc = wsc;
                        if (!sfc) { done(NO, msg); return; }
                        [sfc lsPostComment:cookiesJSON idstr:idstr text:text deep:deep + 1 completion:done];
                    }];
                    return;
                }
                done(ok, msg);
            });
        }] resume];
}

- (void)superLikeLog:(NSString *)kind text:(NSString *)text {
    NSDictionary *d = @{ @"kind" : (kind ?: @"info"), @"text" : (text ?: @"") };
    NSData *jd = [NSJSONSerialization dataWithJSONObject:d options:0 error:nil];
    NSString *mj = jd ? [[NSString alloc] initWithData:jd encoding:NSUTF8StringEncoding] : @"{}";
    NSString *js = [NSString stringWithFormat:
        @"if(window.lsSuperLikeLog) window.lsSuperLikeLog(%@);", mj];
    [self.web evaluateJavaScript:js completionHandler:nil];
}

- (void)superLikeProgress:(NSInteger)doneCount total:(NSInteger)total
                    cmts:(NSInteger)cmts reps:(NSInteger)reps posts:(NSInteger)posts {
    NSString *js = [NSString stringWithFormat:
        @"if(window.lsSuperLikeProgress) window.lsSuperLikeProgress(%ld,%ld,%ld,%ld,%ld);",
        (long)doneCount, (long)total, (long)cmts, (long)reps, (long)posts];
    [self.web evaluateJavaScript:js completionHandler:nil];
}

- (void)superLikeDone:(BOOL)ok msg:(NSString *)msg
                  cmts:(NSInteger)cmts reps:(NSInteger)reps posts:(NSInteger)posts {
    NSDictionary *d = @{ @"ok" : @(ok), @"msg" : (msg ?: @"") };
    NSData *jd = [NSJSONSerialization dataWithJSONObject:d options:0 error:nil];
    NSString *mj = jd ? [[NSString alloc] initWithData:jd encoding:NSUTF8StringEncoding] : @"{}";
    NSString *js = [NSString stringWithFormat:
        @"if(window.lsSuperLikeDone) window.lsSuperLikeDone(%ld,%ld,%ld,%@);",
        (long)cmts, (long)reps, (long)posts, mj];
    [self.web evaluateJavaScript:js completionHandler:nil];
}

#pragma mark - 首页统计与公告

- (NSMutableDictionary *)lsStatsStore {
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    id d = [ud objectForKey:@"left_stats"];
    NSMutableDictionary *m = [d isKindOfClass:[NSDictionary class]]
        ? [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)d]
        : [NSMutableDictionary dictionary];
    NSString *today = [self lsTodayCN] ?: @"";
    NSDictionary *zero = @{ @"checkin" : @0, @"comment" : @0, @"repost" : @0, @"post" : @0 };
    id tot = m[@"total"];
    if (![tot isKindOfClass:[NSDictionary class]]) tot = zero;
    id td = m[@"today"];
    id d0 = m[@"date"];
    BOOL sameDay = ([d0 isKindOfClass:[NSString class]] && [(NSString *)d0 isEqualToString:today]);
    if (!sameDay || ![td isKindOfClass:[NSDictionary class]]) m[@"today"] = zero;
    m[@"date"] = today;
    m[@"total"] = tot;
    return m;
}

- (void)lsStatsAdd:(NSString *)k n:(NSInteger)n {
    if (![k isKindOfClass:[NSString class]] || n <= 0) return;
    NSMutableDictionary *m = [self lsStatsStore];
    NSMutableDictionary *td = [NSMutableDictionary dictionaryWithDictionary:m[@"today"]];
    NSMutableDictionary *tt = [NSMutableDictionary dictionaryWithDictionary:m[@"total"]];
    td[k] = @([td[k] integerValue] + n);
    tt[k] = @([tt[k] integerValue] + n);
    m[@"today"] = td;
    m[@"total"] = tt;
    [[NSUserDefaults standardUserDefaults] setObject:m forKey:@"left_stats"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)pushStats {
    NSMutableDictionary *m = [self lsStatsStore];
    NSString *today = [self lsTodayCN] ?: @"";
    NSInteger okN = 0;
    id ci = [[NSUserDefaults standardUserDefaults] objectForKey:@"left_checkin"];
    if ([ci isKindOfClass:[NSDictionary class]]) {
        id d = ((NSDictionary *)ci)[@"date"];
        id items = ((NSDictionary *)ci)[@"items"];
        if ([d isKindOfClass:[NSString class]] && [(NSString *)d isEqualToString:today] &&
            [items isKindOfClass:[NSArray class]]) {
            for (id it in (NSArray *)items) {
                if ([it isKindOfClass:[NSDictionary class]] && [((NSDictionary *)it)[@"ok"] boolValue]) okN++;
            }
        }
    }
    NSArray *accs = [LSStore accounts];
    NSDictionary *out = @{
        @"accounts" : @(accs.count),
        @"checkinOk" : @(okN),
        @"today" : (m[@"today"] ?: @{}),
        @"total" : (m[@"total"] ?: @{})
    };
    NSData *jd = [NSJSONSerialization dataWithJSONObject:out options:0 error:nil];
    NSString *json = jd ? [[NSString alloc] initWithData:jd encoding:NSUTF8StringEncoding] : @"{}";
    NSString *js = [NSString stringWithFormat:@"if(window.lsStats) window.lsStats(%@);", json];
    [self.web evaluateJavaScript:js completionHandler:nil];
}

- (void)pushLogs {
    NSString *json = [[NSUserDefaults standardUserDefaults] objectForKey:@"left_logs"];
    if (![json isKindOfClass:[NSString class]]) json = @"[]";
    NSString *js = [NSString stringWithFormat:@"if(window.lsLogsReady) window.lsLogsReady(%@);", json];
    [self.web evaluateJavaScript:js completionHandler:nil];
}

- (void)pushFlower {
    NSString *json = [[NSUserDefaults standardUserDefaults] objectForKey:@"left_flower"];
    if (![json isKindOfClass:[NSString class]]) json = @"null";
    NSString *js = [NSString stringWithFormat:@"if(window.lsFlowerReady) window.lsFlowerReady(%@);", json];
    [self.web evaluateJavaScript:js completionHandler:nil];
}

- (void)pushAnnouncements {
    NSString *url = @"https://raw.giteeusercontent.com/liyn19/left-superlike1/raw/master/announcements.json";
    NSMutableURLRequest *r = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    r.timeoutInterval = 12.0;
    [r setValue:@"no-cache" forHTTPHeaderField:@"Cache-Control"];
    [r setValue:kPCUA forHTTPHeaderField:@"User-Agent"];
    __weak typeof(self) ws = self;
    [[[NSURLSession sharedSession] dataTaskWithRequest:r
        completionHandler:^(NSData *data, NSURLResponse *resp, NSError *err) {
            id cfg = nil;
            if (data.length > 0) {
                id j = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                if ([j isKindOfClass:[NSDictionary class]]) cfg = j;
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                typeof(self) sf = ws;
                if (!sf) return;
                NSData *jd = cfg ? [NSJSONSerialization dataWithJSONObject:cfg options:0 error:nil] : nil;
                NSString *json = jd ? [[NSString alloc] initWithData:jd encoding:NSUTF8StringEncoding] : @"null";
                NSString *js = [NSString stringWithFormat:
                    @"if(window.lsAnnounce) window.lsAnnounce(%@);", json];
                [sf.web evaluateJavaScript:js completionHandler:nil];
            });
        }] resume];
}

- (void)refreshHome {
    [self pushAccounts:[LSStore accounts]];
    [self pushStats];
    [self pushAnnouncements];
}

- (void)lsRunVerify:(NSString *)url cookies:(NSString *)ck kind:(NSString *)kind
            completion:(void (^)(BOOL ok, NSString *newCk))done {
    __block BOOL firedV = NO;
    void (^cbV)(BOOL, NSString *) = ^(BOOL vok, NSString *nck) {
        if (firedV) return;
        firedV = YES;
        if (done) done(vok, nck);
    };
    if (url.length == 0) { cbV(NO, nil); return; }
    if (self.verifying) { cbV(NO, nil); return; }
    self.verifying = YES;
    // 兜底：验证器若因任何原因没回调，601 秒后强制复位，避免后续所有转发都被卡死
    // 601 > runner 自己的 600 秒面板超时，保证先由 runner 收尾、把面板撤掉
    __weak typeof(self) wv = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(601.0 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        typeof(self) sv = wv;
        if (!sv) return;
        if (sv.verifying) {
            sv.verifying = NO;
            sv.verifier = nil;
            [sv superLikeLog:@"bad" text:@"⏱ 验证超时，这个号跳过"];
            cbV(NO, nil);
        }
    });
    [self superLikeLog:@"info" text:@"⏳ 检测到安全验证，正在自动过滑块…"];
    LSVerifyRunner *r = [[LSVerifyRunner alloc] init];
    r.verifyURL = url;
    r.cookiesJSON = ck ?: @"[]";
    r.accountName = self.curAccName;
    r.probeKind = kind ?: @"checkin";
    __weak typeof(self) ws = self;
    r.onNeedLogin = ^{
        typeof(self) sf = ws;
        if (sf) [sf openLogin];
    };
    r.log = ^(NSString *kind, NSString *text) {
        typeof(self) sf = ws;
        if (sf) [sf superLikeLog:kind text:text];
    };
    r.onEnd = ^{
        typeof(self) sf = ws;
        if (sf) {
            sf.verifying = NO;
        }
    };
    r.completion = ^(BOOL ok, NSString *json) {
        typeof(self) sf = ws;
        if (sf) {
            sf.verifying = NO;
            sf.verifier = nil;
        }
        cbV(ok, json);
    };
    self.verifier = r;
    [r start];
}

#pragma mark - 设置

- (NSDictionary *)lsTiming {
    double a = 2.0, b = 4.5;
    NSInteger syncHome = 0;
    id d = [[NSUserDefaults standardUserDefaults] objectForKey:@"left_timing"];
    if ([d isKindOfClass:[NSDictionary class]]) {
        id x = ((NSDictionary *)d)[@"accGap"];
        id y = ((NSDictionary *)d)[@"stepGap"];
        id z = ((NSDictionary *)d)[@"sync"];
        if ([x respondsToSelector:@selector(doubleValue)]) a = [x doubleValue];
        if ([y respondsToSelector:@selector(doubleValue)]) b = [y doubleValue];
        if ([z respondsToSelector:@selector(integerValue)]) syncHome = [z integerValue];
    }
    if (a < 0.5) a = 0.5;
    if (a > 30.0) a = 30.0;
    if (b < 0.5) b = 0.5;
    if (b > 60.0) b = 60.0;
    return @{ @"accGap" : @(a), @"stepGap" : @(b), @"sync" : @(syncHome) };
}

- (NSDictionary *)lsTplCustom {
    NSString *json = [[NSUserDefaults standardUserDefaults] objectForKey:@"left_tpl_custom"];
    if (![json isKindOfClass:[NSString class]] || ((NSString *)json).length == 0) return @{};
    id o = [NSJSONSerialization JSONObjectWithData:[(NSString *)json dataUsingEncoding:NSUTF8StringEncoding]
                                           options:0 error:nil];
    return [o isKindOfClass:[NSDictionary class]] ? (NSDictionary *)o : @{};
}

#pragma mark - 捞帖（按关键词捞帖子 → 批量评论）

- (void)pickPush:(NSDictionary *)payload {
    NSData *jd = [NSJSONSerialization dataWithJSONObject:payload options:0 error:nil];
    NSString *json = jd ? [[NSString alloc] initWithData:jd encoding:NSUTF8StringEncoding] : @"{}";
    __weak typeof(self) ws = self;
    dispatch_async(dispatch_get_main_queue(), ^{
        LSViewController *sf = ws;
        if (!sf) return;
        NSString *js = [NSString stringWithFormat:@"if(window.lsPick) window.lsPick(%@);", json];
        [sf.web evaluateJavaScript:js completionHandler:nil];
    });
}

- (void)pickFetch:(NSString *)raw kw:(NSString *)kw max:(NSInteger)maxC page:(NSInteger)page {
    NSString *pid = LSPickPageID(raw);
    if (pid.length > 0) {
        [self pickFetchSuper:pid kw:kw max:maxC page:page];
        return;
    }
    NSString *uid = LSPickUID(raw);
    if (uid.length == 0) {
        [self pickPush:@{ @"ok" : @0, @"err" : @"没认出 UID，贴 https://weibo.com/u/数字 或纯数字" }];
        return;
    }
    NSArray *accs = [LSStore accounts];
    if (accs.count == 0) {
        [self pickPush:@{ @"ok" : @0, @"err" : @"先在账号页登录一个号" }];
        return;
    }
    NSDictionary *acc = accs.firstObject;
    NSString *cj = [acc[@"cookies"] isKindOfClass:[NSString class]] ? acc[@"cookies"] : @"";
    NSString *ck = LSHeaderFromCookiesJSON(cj, @"weibo.com");
    if (ck.length == 0) {
        [self pickPush:@{ @"ok" : @0, @"err" : @"这个号的 Cookie 不完整，去账号页重新登录" }];
        return;
    }
    if (page < 1) page = 1;
    NSString *u = [NSString stringWithFormat:
        @"https://weibo.com/ajax/statuses/mymblog?uid=%@&page=%ld&feature=0", uid, (long)page];
    NSMutableURLRequest *r = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:u]];
    r.HTTPMethod = @"GET";
    [r setValue:kPCUA forHTTPHeaderField:@"User-Agent"];
    [r setValue:@"application/json, text/plain, */*" forHTTPHeaderField:@"Accept"];
    [r setValue:@"zh-CN,zh;q=0.9" forHTTPHeaderField:@"Accept-Language"];
    [r setValue:[NSString stringWithFormat:@"https://weibo.com/u/%@", uid] forHTTPHeaderField:@"Referer"];
    [r setValue:@"XMLHttpRequest" forHTTPHeaderField:@"X-Requested-With"];
    [r setValue:@"1" forHTTPHeaderField:@"MWeibo-Pwa"];
    [r setValue:ck forHTTPHeaderField:@"Cookie"];
    NSString *xsrf = LSCookieValue(cj, @"XSRF-TOKEN");
    if (xsrf.length > 0) [r setValue:xsrf forHTTPHeaderField:@"X-XSRF-TOKEN"];
    r.timeoutInterval = 20.0;

    __weak typeof(self) ws = self;
    [[[NSURLSession sharedSession] dataTaskWithRequest:r
        completionHandler:^(NSData *data, NSURLResponse *resp, NSError *e) {
            LSViewController *sf = ws;
            if (!sf) return;
            if (e) {
                [sf pickPush:@{ @"ok" : @0, @"err" : @"网络失败，检查网络再试" }];
                return;
            }
            NSHTTPURLResponse *hr = (NSHTTPURLResponse *)resp;
            id obj = data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil;
            if (![obj isKindOfClass:[NSDictionary class]]) {
                NSString *peek = data ? [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] : @"";
                if (!peek) peek = @"";
                if (peek.length > 60) peek = [peek substringToIndex:60];
                [sf pickPush:@{ @"ok" : @0,
                                @"err" : [NSString stringWithFormat:@"HTTP %ld 返回不是 JSON：%@",
                                          (long)hr.statusCode, peek] }];
                return;
            }
            NSDictionary *j = (NSDictionary *)obj;
            id dataObj = j[@"data"];
            NSArray *list = nil;
            if ([dataObj isKindOfClass:[NSDictionary class]]) list = ((NSDictionary *)dataObj)[@"list"];
            if (![list isKindOfClass:[NSArray class]]) {
                NSString *m = [j[@"msg"] description];
                if (m.length == 0) m = [NSString stringWithFormat:@"HTTP %ld 没拿到列表", (long)hr.statusCode];
                [sf pickPush:@{ @"ok" : @0, @"err" : m }];
                return;
            }
            NSInteger ready = 0;
            NSInteger scanned = 0;
            NSMutableArray *items = [NSMutableArray array];
            NSMutableArray *kws = [NSMutableArray array];
            for (NSString *part in [kw componentsSeparatedByString:@","]) {
                NSString *t = [part stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                if (t.length > 0) [kws addObject:t];
            }
            for (id raw in list) {
                if (![raw isKindOfClass:[NSDictionary class]]) continue;
                NSDictionary *it = (NSDictionary *)raw;
                scanned += 1;
                NSInteger cc = [it[@"comments_count"] integerValue];
                if (maxC > 0 && cc >= maxC) continue;
                NSString *txt = [it[@"text_raw"] isKindOfClass:[NSString class]] ? it[@"text_raw"] : LSPickPlain(it[@"text"]);
                if (kws.count > 0) {
                    BOOL hit = NO;
                    for (NSString *k in kws) {
                        if ([txt rangeOfString:k].location != NSNotFound) { hit = YES; break; }
                    }
                    if (!hit) continue;
                }
                NSString *mid = [it[@"id"] description];
                NSString *mb = [it[@"mblogid"] description];
                if (mid.length == 0) continue;
                if (txt.length > 80) txt = [[txt substringToIndex:80] stringByAppendingString:@"…"];
                ready += 1;
                [items addObject:@{ @"id" : mid,
                                    @"mblogid" : (mb.length ? mb : @""),
                                    @"text" : (txt.length ? txt : @"（无正文，可能是图片或转发）"),
                                    @"comments" : @(cc),
                                    @"url" : [NSString stringWithFormat:@"https://weibo.com/%@/%@",
                                              uid, (mb.length ? mb : mid)] }];
            }
            [sf pickPush:@{ @"ok" : @1,
                            @"items" : items,
                            @"total" : @(scanned),
                            @"ready" : @(ready),
                            @"uid" : uid,
                            @"page" : @(page),
                            @"err" : @"" }];
        }] resume];
}

#pragma mark 超话帖子流

- (void)pickFetchSuper:(NSString *)pid kw:(NSString *)kw max:(NSInteger)maxC page:(NSInteger)page {
    NSArray *accs = [LSStore accounts];
    if (accs.count == 0) {
        [self pickPush:@{ @"ok" : @0, @"err" : @"先在账号页登录一个号" }];
        return;
    }
    NSDictionary *acc = accs.firstObject;
    NSString *cj = [acc[@"cookies"] isKindOfClass:[NSString class]] ? acc[@"cookies"] : @"";
    NSString *ck = LSHeaderFromCookiesJSON(cj, @"weibo.cn");
    if (ck.length == 0) ck = LSHeaderFromCookiesJSON(cj, @"weibo.com");
    if (ck.length == 0) {
        [self pickPush:@{ @"ok" : @0, @"err" : @"这个号的 Cookie 不完整，去账号页重新登录" }];
        return;
    }
    if (page < 1) page = 1;
    NSString *u = [NSString stringWithFormat:
        @"https://m.weibo.cn/api/container/getIndex?containerid=%@_-_feed&page=%ld", pid, (long)page];
    NSMutableURLRequest *r = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:u]];
    r.HTTPMethod = @"GET";
    [r setValue:kUA forHTTPHeaderField:@"User-Agent"];
    [r setValue:@"application/json, text/plain, */*" forHTTPHeaderField:@"Accept"];
    [r setValue:@"https://m.weibo.cn/" forHTTPHeaderField:@"Referer"];
    [r setValue:@"XMLHttpRequest" forHTTPHeaderField:@"X-Requested-With"];
    [r setValue:@"1" forHTTPHeaderField:@"MWeibo-Pwa"];
    [r setValue:ck forHTTPHeaderField:@"Cookie"];
    r.timeoutInterval = 20.0;

    __weak typeof(self) ws = self;
    [[[NSURLSession sharedSession] dataTaskWithRequest:r
        completionHandler:^(NSData *data, NSURLResponse *resp, NSError *e) {
            LSViewController *sf = ws;
            if (!sf) return;
            if (e) {
                [sf pickPush:@{ @"ok" : @0, @"err" : @"网络失败，检查网络再试" }];
                return;
            }
            NSHTTPURLResponse *hr = (NSHTTPURLResponse *)resp;
            id obj = data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil;
            if (![obj isKindOfClass:[NSDictionary class]]) {
                NSString *peek = data ? [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] : @"";
                if (!peek) peek = @"";
                if (peek.length > 60) peek = [peek substringToIndex:60];
                [sf pickPush:@{ @"ok" : @0,
                                @"err" : [NSString stringWithFormat:@"HTTP %ld 返回不是 JSON：%@",
                                          (long)hr.statusCode, peek] }];
                return;
            }
            NSDictionary *j = (NSDictionary *)obj;
            NSDictionary *dataD = [j[@"data"] isKindOfClass:[NSDictionary class]] ? j[@"data"] : nil;
            NSArray *cards = [dataD[@"cards"] isKindOfClass:[NSArray class]] ? dataD[@"cards"] : nil;
            if (![cards isKindOfClass:[NSArray class]]) {
                NSString *m = [j[@"msg"] description];
                if (m.length == 0) m = [NSString stringWithFormat:@"HTTP %ld 没拿到帖子列表", (long)hr.statusCode];
                [sf pickPush:@{ @"ok" : @0, @"err" : m }];
                return;
            }
            NSMutableArray *kws = [NSMutableArray array];
            for (NSString *part in [kw componentsSeparatedByString:@","]) {
                NSString *t = [part stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                if (t.length > 0) [kws addObject:t];
            }
            NSMutableArray *items = [NSMutableArray array];
            NSInteger scanned = 0;
            // 超话 feed 的帖子可能直接挂在 card 上，也可能在 card_group 里
            NSMutableArray *blogs = [NSMutableArray array];
            for (id c in cards) {
                if (![c isKindOfClass:[NSDictionary class]]) continue;
                NSDictionary *card = (NSDictionary *)c;
                if ([card[@"mblog"] isKindOfClass:[NSDictionary class]]) [blogs addObject:card[@"mblog"]];
                if ([card[@"card_group"] isKindOfClass:[NSArray class]]) {
                    for (id g in (NSArray *)card[@"card_group"]) {
                        if ([g isKindOfClass:[NSDictionary class]] &&
                            [((NSDictionary *)g)[@"mblog"] isKindOfClass:[NSDictionary class]]) {
                            [blogs addObject:((NSDictionary *)g)[@"mblog"]];
                        }
                    }
                }
            }
            for (id b in blogs) {
                NSDictionary *mb = (NSDictionary *)b;
                scanned += 1;
                NSInteger cc = [mb[@"comments_count"] integerValue];
                if (maxC > 0 && cc >= maxC) continue;
                NSString *txt = LSPickPlain(mb[@"text"]);
                if (kws.count > 0) {
                    BOOL hit = NO;
                    for (NSString *k in kws) {
                        if ([txt rangeOfString:k].location != NSNotFound) { hit = YES; break; }
                    }
                    if (!hit) continue;
                }
                NSString *mid = [mb[@"id"] description];
                if (mid.length == 0) continue;
                NSString *mbid = [mb[@"mblogid"] description];
                NSString *author = @"";
                if ([mb[@"user"] isKindOfClass:[NSDictionary class]]) {
                    author = [((NSDictionary *)mb[@"user"])[@"id"] description];
                }
                if (txt.length > 80) txt = [[txt substringToIndex:80] stringByAppendingString:@"…"];
                NSString *url = mbid.length ? [NSString stringWithFormat:@"https://weibo.com/%@/%@",
                                               (author.length ? author : @"u"), mbid]
                                            : [NSString stringWithFormat:@"https://m.weibo.cn/detail/%@", mid];
                [items addObject:@{ @"id" : mid,
                                    @"mblogid" : (mbid.length ? mbid : @"超话帖"),
                                    @"text" : (txt.length ? txt : @"（无正文，可能是图片或转发）"),
                                    @"comments" : @(cc),
                                    @"url" : url }];
            }
            [sf pickPush:@{ @"ok" : @1,
                            @"items" : items,
                            @"total" : @(scanned),
                            @"ready" : @(items.count),
                            @"uid" : pid,
                            @"page" : @(page),
                            @"err" : @"" }];
        }] resume];
}


// 解析一条微博 JSON → item
static NSDictionary *LSPostItemFromBlog(NSDictionary *mb, NSString *fallbackKey) {
    if (![mb isKindOfClass:[NSDictionary class]]) return nil;
    NSString *mid = [mb[@"id"] description];
    if (mid.length == 0) mid = [mb[@"idstr"] description];
    if (mid.length == 0) mid = fallbackKey;
    NSString *txt = mb[@"text"];
    if (![txt isKindOfClass:[NSString class]] || txt.length == 0) txt = mb[@"text_raw"];
    if (![txt isKindOfClass:[NSString class]]) txt = @"";
    txt = LSPickPlain(txt);
    if (txt.length > 80) txt = [[txt substringToIndex:80] stringByAppendingString:@"…"];
    if (txt.length == 0) txt = @"（这条帖子没有正文，可能是图片或转发）";
    NSInteger cc = [mb[@"comments_count"] integerValue];
    NSString *mbid = [mb[@"mblogid"] description];
    if (mbid.length == 0) mbid = [mb[@"bid"] description];
    NSString *author = @"";
    if ([mb[@"user"] isKindOfClass:[NSDictionary class]]) {
        author = [((NSDictionary *)mb[@"user"])[@"id"] description];
    }
    if (author.length == 0) author = [mb[@"user_id"] description];
    NSString *url = mbid.length ? [NSString stringWithFormat:@"https://weibo.com/%@/%@",
                                   (author.length ? author : @"u"), mbid]
                                : [NSString stringWithFormat:@"https://m.weibo.cn/detail/%@", mid];
    return @{ @"id" : (mid.length ? mid : @"0"),
              @"mblogid" : (mbid.length ? mbid : @"单帖"),
              @"text" : txt,
              @"comments" : @(cc),
              @"url" : url };
}

// 单条帖子：先走 PC 接口（登录态），不行再走 m 站
- (void)pickPostOne:(NSString *)key cookieJSON:(NSString *)cj
          completion:(void (^)(NSDictionary *item, NSString *err))done {
    NSString *ckPC = LSHeaderFromCookiesJSON(cj, @"weibo.com");
    NSString *ckM  = LSHeaderFromCookiesJSON(cj, @"weibo.cn");
    if (ckM.length == 0) ckM = ckPC;

    void (^tryM)(void) = ^{
        NSString *u = [NSString stringWithFormat:@"https://m.weibo.cn/api/statuses/show?id=%@", key];
        NSMutableURLRequest *r = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:u]];
        r.HTTPMethod = @"GET";
        [r setValue:kUA forHTTPHeaderField:@"User-Agent"];
        [r setValue:@"https://m.weibo.cn/" forHTTPHeaderField:@"Referer"];
        [r setValue:@"application/json, text/plain, */*" forHTTPHeaderField:@"Accept"];
        [r setValue:@"XMLHttpRequest" forHTTPHeaderField:@"X-Requested-With"];
        [r setValue:@"1" forHTTPHeaderField:@"MWeibo-Pwa"];
        if (ckM.length) [r setValue:ckM forHTTPHeaderField:@"Cookie"];
        r.timeoutInterval = 18.0;
        [[[NSURLSession sharedSession] dataTaskWithRequest:r
            completionHandler:^(NSData *data, NSURLResponse *resp, NSError *e) {
                NSHTTPURLResponse *hr = (NSHTTPURLResponse *)resp;
                if (e) { done(nil, @"网络失败"); return; }
                id obj = data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil;
                NSDictionary *mb = nil;
                if ([obj isKindOfClass:[NSDictionary class]]) {
                    NSDictionary *j = (NSDictionary *)obj;
                    if ([j[@"data"] isKindOfClass:[NSDictionary class]]) mb = j[@"data"];
                    else if (j[@"id"] != nil) mb = j;
                }
                NSDictionary *item = mb ? LSPostItemFromBlog(mb, key) : nil;
                if (item) { done(item, nil); return; }
                NSString *peek = data ? [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] : @"";
                if (peek.length > 40) peek = [peek substringToIndex:40];
                done(nil, [NSString stringWithFormat:@"m站 HTTP %ld %@", (long)hr.statusCode,
                           (peek.length ? peek : @"空返回")]);
            }] resume];
    };

    NSString *up = [NSString stringWithFormat:
        @"https://weibo.com/ajax/statuses/show?id=%@&isGetLongText=true", key];
    NSMutableURLRequest *rp = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:up]];
    rp.HTTPMethod = @"GET";
    [rp setValue:kPCUA forHTTPHeaderField:@"User-Agent"];
    [rp setValue:@"https://weibo.com/" forHTTPHeaderField:@"Referer"];
    [rp setValue:@"application/json, text/plain, */*" forHTTPHeaderField:@"Accept"];
    [rp setValue:@"1" forHTTPHeaderField:@"MWeibo-Pwa"];
    if (ckPC.length) [rp setValue:ckPC forHTTPHeaderField:@"Cookie"];
    rp.timeoutInterval = 18.0;
    [[[NSURLSession sharedSession] dataTaskWithRequest:rp
        completionHandler:^(NSData *data, NSURLResponse *resp, NSError *e) {
            id obj = data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil;
            NSDictionary *mb = [obj isKindOfClass:[NSDictionary class]] ? (NSDictionary *)obj : nil;
            // 有些返回会包一层 data
            if (mb && [mb[@"data"] isKindOfClass:[NSDictionary class]]) mb = (NSDictionary *)mb[@"data"];
            NSDictionary *item = mb ? LSPostItemFromBlog(mb, key) : nil;
            if (item) { done(item, nil); return; }
            tryM();
        }] resume];
}

// 批量：一条条串行取
- (void)pickPostsStep:(NSArray *)urls idx:(NSInteger)i items:(NSMutableArray *)items
                    bad:(NSMutableArray *)bad cj:(NSString *)cj {
    if (i >= (NSInteger)urls.count) {
        NSString *msg = [NSString stringWithFormat:@"锁定 %ld 条帖子", (long)items.count];
        if (bad.count) {
            msg = [msg stringByAppendingFormat:@"，%ld 条没认出来或取不到", (long)bad.count];
        }
        [self pickPush:@{ @"ok" : @((items.count > 0) ? 1 : 0),
                          @"items" : items,
                          @"total" : @(urls.count),
                          @"ready" : @(items.count),
                          @"msg" : msg,
                          @"bad" : bad,
                          @"err" : (items.count ? @"" : @"这些链接都没取到，看看是不是删了或设了权限") }];
        return;
    }
    NSString *raw = [urls[i] description];
    NSString *key = LSPickPostKey(raw);
    if (key.length == 0) {
        [bad addObject:raw];
        [self pickPostsStep:urls idx:i + 1 items:items bad:bad cj:cj];
        return;
    }
    __weak typeof(self) ws = self;
    [self pickPostOne:key cookieJSON:cj completion:^(NSDictionary *item, NSString *err) {
        LSViewController *sf = ws;
        if (!sf) return;
        if (item) [items addObject:item];
        else [bad addObject:[NSString stringWithFormat:@"%@（%@）", raw, err ?: @"取不到"]];
        [sf pickPostsStep:urls idx:i + 1 items:items bad:bad cj:cj];
    }];
}

- (void)pickFetchPosts:(NSArray *)urls {
    NSArray *accs = [LSStore accounts];
    if (accs.count == 0) {
        [self pickPush:@{ @"ok" : @0, @"err" : @"先在账号页登录一个号" }];
        return;
    }
    NSDictionary *acc = accs.firstObject;
    NSString *cj = [acc[@"cookies"] isKindOfClass:[NSString class]] ? acc[@"cookies"] : @"";
    [self pickPostsStep:urls idx:0 items:[NSMutableArray array] bad:[NSMutableArray array] cj:cj];
}

- (void)pickFetchPost:(NSString *)raw {
    if (raw.length == 0) {
        [self pickPush:@{ @"ok" : @0, @"err" : @"先贴帖子链接" }];
        return;
    }
    [self pickFetchPosts:@[ raw ]];
}

- (void)pickTextPool:(void (^)(NSArray *texts))done {
    NSMutableArray *out = [NSMutableArray array];
    NSDictionary *cu = [self lsTplCustom];
    NSArray *mineGroups = [cu[@"comment"] isKindOfClass:[NSArray class]] ? cu[@"comment"] : @[];
    for (id g in mineGroups) {
        if (![g isKindOfClass:[NSDictionary class]]) continue;
        id its = ((NSDictionary *)g)[@"items"];
        if (![its isKindOfClass:[NSArray class]]) continue;
        for (id t in (NSArray *)its) {
            if ([t isKindOfClass:[NSString class]] && [(NSString *)t length] >= 2) [out addObject:t];
        }
    }
    [self fetchTemplates:^(NSDictionary *tpl) {
        NSMutableArray *all = [NSMutableArray arrayWithArray:out];
        NSDictionary *groups = [tpl[@"groups"] isKindOfClass:[NSDictionary class]] ? tpl[@"groups"] : nil;
        NSArray *cg = [groups[@"comment"] isKindOfClass:[NSArray class]] ? groups[@"comment"] : @[];
        for (id g in cg) {
            if (![g isKindOfClass:[NSDictionary class]]) continue;
            id its = ((NSDictionary *)g)[@"items"];
            if (![its isKindOfClass:[NSArray class]]) continue;
            for (id t in (NSArray *)its) {
                if ([t isKindOfClass:[NSString class]] && [(NSString *)t length] >= 2 &&
                    ![all containsObject:t]) {
                    [all addObject:t];
                }
            }
        }
        if (all.count == 0) {
            [all addObjectsFromArray:@[ @"来了来了，好帅！", @"这套图我存了", @"航航今天状态真好" ]];
        }
        // 洗一遍，避免每次都从同一条开始
        for (NSInteger i = (NSInteger)all.count - 1; i > 0; i--) {
            NSInteger j = (NSInteger)arc4random_uniform((uint32_t)(i + 1));
            [all exchangeObjectAtIndex:(NSUInteger)i withObjectAtIndex:(NSUInteger)j];
        }
        done(all);
    }];
}

- (void)pickCommentStep:(NSArray *)items accs:(NSArray *)accs texts:(NSArray *)texts gap:(double)gap
                     idx:(NSInteger)i okN:(NSInteger)okN failN:(NSInteger)failN {
    NSInteger per = (NSInteger)items.count;
    if (per <= 0 || accs.count == 0) {
        [self pickPush:@{ @"ok" : @0, @"err" : @"没有可评论的帖子或账号" }];
        return;
    }
    NSInteger ai = i / per;
    NSInteger pi = i % per;
    if (ai >= (NSInteger)accs.count) {
        [self pickPush:@{ @"ok" : @1, @"done" : @1,
                          @"okN" : @(okN), @"failN" : @(failN),
                          @"msg" : [NSString stringWithFormat:@"全部跑完：成功 %ld，失败 %ld（%ld 个账号 × %ld 条）",
                                    (long)okN, (long)failN, (long)accs.count, (long)per] }];
        return;
    }
    NSDictionary *acc = accs[(NSUInteger)ai];
    NSDictionary *it = items[(NSUInteger)pi];
    NSString *name = acc[@"remark"] ?: (acc[@"name"] ?: @"账号");
    NSString *text = texts.count ? texts[(NSUInteger)(arc4random_uniform((uint32_t)texts.count))] : @"来了来了";
    NSString *mid = [it[@"id"] description];
    __weak typeof(self) ws = self;
    [self ensureCookies:acc completion:^(NSString *json) {
        LSViewController *sf = ws;
        if (!sf) return;
        [sf superLikeLog:@"info" text:[NSString stringWithFormat:@"[%@] 第 %ld/%ld 条（原评论 %@）：%@",
                                      name, (long)(pi + 1), (long)per, it[@"comments"] ?: @0, text]];
        [sf lsPostComment:json idstr:mid text:text deep:0 completion:^(BOOL aok, NSString *msg) {
            LSViewController *sf2 = ws;
            if (!sf2) return;
            NSInteger ok2 = okN + (aok ? 1 : 0);
            NSInteger fail2 = failN + (aok ? 0 : 1);
            [sf2 superLikeLog:(aok ? @"ok" : @"bad")
                          text:[NSString stringWithFormat:@"%@ [%@] %@",
                                (aok ? @"✓ 成功" : @"✗ 失败"), name, (msg.length ? msg : @"")]];
            NSInteger idx2 = i + 1;
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(gap * NSEC_PER_SEC)),
                           dispatch_get_main_queue(), ^{
                LSViewController *sf3 = ws;
                if (sf3) [sf3 pickCommentStep:items accs:accs texts:texts gap:gap idx:idx2 okN:ok2 failN:fail2];
            });
        }];
    }];
}

#pragma mark - 锁定帖子转发

- (void)startLockRepost:(NSArray *)urls uids:(NSArray *)uids gap:(double)gap {
    NSMutableArray *ids = [NSMutableArray array];
    NSMutableArray *bad = [NSMutableArray array];
    for (id u in urls) {
        if (![u isKindOfClass:[NSString class]]) continue;
        NSString *raw = [(NSString *)u stringByTrimmingCharactersInSet:
            [NSCharacterSet whitespaceAndNewlineCharacterSet]];
        if (raw.length == 0) continue;
        NSString *key = LSPickPostKey(raw);
        if (key.length == 0) {
            // 也可能人家直接贴了 mid
            if (raw.length >= 6 && raw.length <= 20 &&
                [raw rangeOfCharacterFromSet:[NSCharacterSet letterCharacterSet]].location != NSNotFound &&
                [raw rangeOfCharacterFromSet:[NSCharacterSet whitespaceCharacterSet]].location == NSNotFound) {
                [ids addObject:raw];
            } else {
                [bad addObject:raw];
            }
        } else {
            [ids addObject:key];
        }
    }
    if (ids.count == 0) {
        [self toast:@"这些链接都没认出来"];
        return;
    }

    NSArray *all = [LSStore accounts];
    NSMutableArray *accs = [NSMutableArray array];
    for (id a in all) {
        if (![a isKindOfClass:[NSDictionary class]]) continue;
        if (uids) {
            NSString *u = [((NSDictionary *)a)[@"uid"] description];
            BOOL hit = NO;
            for (id uu in uids) {
                if ([u isEqualToString:[uu description]]) { hit = YES; break; }
            }
            if (!hit) continue;
        }
        [accs addObject:a];
    }
    if (accs.count == 0) { [self toast:@"先勾选参与账号"]; return; }

    NSMutableArray *uniq = [NSMutableArray array];
    for (NSString *i in ids) {
        if (![uniq containsObject:i]) [uniq addObject:i];
    }

    __weak typeof(self) ws = self;
    [self fetchTemplates:^(NSDictionary *tpl) {
        LSViewController *sf = ws;
        if (!sf) return;
        NSArray *rt = tpl[@"repost"];
        if (![rt isKindOfClass:[NSArray class]] || rt.count == 0) rt = @[ @"转发支持" ];
        dispatch_async(dispatch_get_main_queue(), ^{
            [sf superLikeLog:@"info" text:[NSString stringWithFormat:
                @"锁定转发：%ld 个账号 × %ld 条帖子%@", (long)accs.count, (long)uniq.count,
                (bad.count ? [NSString stringWithFormat:@"（%ld 条链接没认出来）", (long)bad.count] : @"")]];
            [sf lockRepostStep:uniq accs:accs texts:rt gap:gap idx:0 okN:0 failN:0];
        });
    }];
}

- (void)lockRepostStep:(NSArray *)ids accs:(NSArray *)accs texts:(NSArray *)texts gap:(double)gap
                    idx:(NSInteger)i okN:(NSInteger)okN failN:(NSInteger)failN {
    NSInteger per = (NSInteger)ids.count;
    if (per <= 0 || accs.count == 0) {
        [self pickPush:@{ @"ok" : @0, @"err" : @"没有可转发的帖子或账号" }];
        return;
    }
    NSInteger ai = i / per;
    NSInteger pi = i % per;
    if (ai >= (NSInteger)accs.count) {
        if (okN > 0) {
            [self lsStatsAdd:@"repost" n:okN];
            [self pushStats];
        }
        [self pickPush:@{ @"ok" : @1, @"done" : @1,
                          @"okN" : @(okN), @"failN" : @(failN),
                          @"msg" : [NSString stringWithFormat:@"锁定转发跑完：成功 %ld，失败 %ld（%ld 个账号 × %ld 条）",
                                    (long)okN, (long)failN, (long)accs.count, (long)per] }];
        return;
    }
    NSDictionary *acc = accs[(NSUInteger)ai];
    NSString *idstr = [ids[(NSUInteger)pi] description];
    NSString *name = acc[@"remark"] ?: (acc[@"name"] ?: @"账号");
    NSString *text = texts.count ? texts[(NSUInteger)(arc4random_uniform((uint32_t)texts.count))] : @"转发支持";
    __weak typeof(self) ws = self;
    [self ensureCookies:acc completion:^(NSString *json) {
        LSViewController *sf = ws;
        if (!sf) return;
        [sf superLikeLog:@"info" text:[NSString stringWithFormat:@"[%@] 第 %ld/%ld 条 · %@",
                                      name, (long)(pi + 1), (long)per, idstr]];
        [sf postRepost:json idstr:idstr text:text completion:^(BOOL aok, NSString *msg) {
            LSViewController *sf2 = ws;
            if (!sf2) return;
            NSInteger ok2 = okN + (aok ? 1 : 0);
            NSInteger fail2 = failN + (aok ? 0 : 1);
            [sf2 superLikeLog:(aok ? @"ok" : @"bad")
                          text:[NSString stringWithFormat:@"%@ [%@] %@",
                                (aok ? @"✓ 成功" : @"✗ 失败"), name, (msg.length ? msg : @"")]];
            NSInteger idx2 = i + 1;
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(gap * NSEC_PER_SEC)),
                           dispatch_get_main_queue(), ^{
                LSViewController *sf3 = ws;
                if (sf3) [sf3 lockRepostStep:ids accs:accs texts:texts gap:gap idx:idx2 okN:ok2 failN:fail2];
            });
        }];
    }];
}

- (void)pushTemplates {
    __weak typeof(self) ws = self;
    [self fetchTemplates:^(NSDictionary *tpl) {
        LSViewController *sf = ws;
        if (!sf) return;
        NSDictionary *cloud = tpl[@"groups"] ?: @{};
        NSDictionary *custom = [sf lsTplCustom];
        NSMutableDictionary *merged = [NSMutableDictionary dictionary];
        for (NSString *cat in @[ @"comment", @"repost", @"post" ]) {
            NSArray *cg = [cloud[cat] isKindOfClass:[NSArray class]] ? cloud[cat] : @[];
            NSArray *mg = [custom[cat] isKindOfClass:[NSArray class]] ? custom[cat] : @[];
            merged[cat] = @{ @"cloud" : cg, @"mine" : mg };
        }
        NSData *jd = [NSJSONSerialization dataWithJSONObject:merged options:0 error:nil];
        NSString *json = jd ? [[NSString alloc] initWithData:jd encoding:NSUTF8StringEncoding] : @"{}";
        dispatch_async(dispatch_get_main_queue(), ^{
            NSString *js = [NSString stringWithFormat:@"if(window.lsTplData) window.lsTplData(%@);", json];
            [sf.web evaluateJavaScript:js completionHandler:nil];
        });
    }];
}

- (void)pushSettings {
    NSDictionary *t = [self lsTiming];
    NSData *jd = [NSJSONSerialization dataWithJSONObject:t options:0 error:nil];
    NSString *json = jd ? [[NSString alloc] initWithData:jd encoding:NSUTF8StringEncoding] : @"{}";
    NSString *js = [NSString stringWithFormat:@"if(window.lsSettings) window.lsSettings(%@);", json];
    [self.web evaluateJavaScript:js completionHandler:nil];
}

#pragma mark - 本地数据

- (void)clearLocalData {
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    NSArray *keys = @[ @"left_accounts", @"left_streak", @"left_checkin", @"left_repost",
                       @"left_superlike", @"left_stats", @"left_logs", @"left_flower" ];
    for (NSString *k in keys) [ud removeObjectForKey:k];
    [ud synchronize];

    __weak typeof(self) ws = self;
    NSSet *types = [NSSet setWithObject:WKWebsiteDataTypeCookies];
    [[WKWebsiteDataStore defaultDataStore] removeDataOfTypes:types
        modifiedSince:[NSDate dateWithTimeIntervalSince1970:0]
        completionHandler:^{
            dispatch_async(dispatch_get_main_queue(), ^{
                typeof(self) sf = ws;
                if (!sf) return;
                NSString *js = @"try{localStorage.clear()}catch(e){};"
                                "window.__LS_INIT__ = {days:0,last:''};"
                                "window.__LS_ACCOUNTS__ = [];"
                                "window.__LS_CHECKIN__ = {};"
                                "if(window.lsCleared) window.lsCleared();";
                [sf.web evaluateJavaScript:js completionHandler:nil];
                [sf toast:@"已清除本地数据"];
            });
        }];
}

#pragma mark - 超话发帖

- (void)startPublish:(NSString *)text {
    NSString *body = [text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (body.length == 0) {
        [self publishCallback:NO msg:@"正文不能为空"];
        return;
    }
    NSArray *accs = [LSStore accounts];
    if (accs.count == 0) {
        [self publishCallback:NO msg:@"先在账号页登录一个微博账号"];
        return;
    }
    NSDictionary *acc = accs.firstObject;
    NSString *uid = [acc[@"uid"] description];
    if (![uid isKindOfClass:[NSString class]] || uid.length == 0) uid = @"";
    [self toast:[NSString stringWithFormat:@"正在用 %@ 发到左航超话…", (acc[@"name"] ?: @"账号")]];
    __weak typeof(self) ws = self;
    [self ensureCookies:acc completion:^(NSString *json) {
        typeof(self) sf = ws;
        if (!sf) return;
        [sf postPublish:json text:body uid:uid completion:^(BOOL ok, NSString *msg) {
            typeof(self) sf2 = ws;
            if (!sf2) return;
            [sf2 publishCallback:ok msg:msg];
        }];
    }];
}

- (void)postPublish:(NSString *)cookiesJSON text:(NSString *)text uid:(NSString *)uid completion:(void (^)(BOOL ok, NSString *msg))done {
    [self lsPostPublish:cookiesJSON text:text uid:uid deep:0 completion:done];
}

- (void)lsPostPublish:(NSString *)cookiesJSON text:(NSString *)text uid:(NSString *)uid deep:(NSInteger)deep completion:(void (^)(BOOL ok, NSString *msg))done {
    NSString *ck = LSHeaderFromCookiesJSON(cookiesJSON, @"weibo.com");
    if (ck.length == 0) {
        done(NO, @"需重新登录这个账号");
        return;
    }
    NSString *topic = [@"1022:" stringByAppendingString:kSuperId];
    // sync_mblog=1 会把帖子同步到个人主页，用户可以在设置里关掉
    NSInteger syncHome = 0;
    id tm = [[NSUserDefaults standardUserDefaults] objectForKey:@"left_timing"];
    if ([tm isKindOfClass:[NSDictionary class]]) {
        id z = ((NSDictionary *)tm)[@"sync"];
        if ([z respondsToSelector:@selector(integerValue)]) syncHome = [z integerValue];
    }
    NSString *form = [NSString stringWithFormat:
        @"content=%@&topic_id=%@&visible=0&sync_mblog=%ld",
        LSURLEncode(text), LSURLEncode(topic), (long)syncHome];

    NSMutableURLRequest *r = [NSMutableURLRequest
        requestWithURL:[NSURL URLWithString:@"https://weibo.com/ajax/statuses/update"]];
    r.HTTPMethod = @"POST";
    [r setValue:kPCUA forHTTPHeaderField:@"User-Agent"];
    [r setValue:@"application/json, text/plain, */*" forHTTPHeaderField:@"Accept"];
    [r setValue:@"zh-CN,zh;q=0.9" forHTTPHeaderField:@"Accept-Language"];
    [r setValue:[NSString stringWithFormat:@"https://weibo.com/p/%@", kSuperId]
         forHTTPHeaderField:@"Referer"];
    [r setValue:@"XMLHttpRequest" forHTTPHeaderField:@"X-Requested-With"];
    [r setValue:@"application/x-www-form-urlencoded; charset=UTF-8" forHTTPHeaderField:@"Content-Type"];
    [r setValue:@"https://weibo.com" forHTTPHeaderField:@"Origin"];
    [r setValue:@"same-origin" forHTTPHeaderField:@"Sec-Fetch-Site"];
    [r setValue:@"cors" forHTTPHeaderField:@"Sec-Fetch-Mode"];
    [r setValue:@"empty" forHTTPHeaderField:@"Sec-Fetch-Dest"];
    // v1.11: 以刚刷新的全局值为准（cookie 里那份可能是旧的）
    NSString *xsrf = self.slXsrf;
    if (xsrf.length == 0) xsrf = LSCookieValue(cookiesJSON, @"XSRF-TOKEN");
    // v1.11: 一律覆盖成同一个新值，保证 Cookie 与 X-XSRF-TOKEN 咬合
    NSString *ckSend = (xsrf.length > 0) ? LSReplaceCookieValue(ck, @"XSRF-TOKEN", xsrf) : ck;
    [r setValue:ckSend forHTTPHeaderField:@"Cookie"];
    [r setValue:@"1" forHTTPHeaderField:@"MWeibo-Pwa"];
    if (xsrf.length > 0) {
        [r setValue:xsrf forHTTPHeaderField:@"X-XSRF-TOKEN"];
    }
    r.HTTPBody = [form dataUsingEncoding:NSUTF8StringEncoding];
    r.timeoutInterval = 25.0;

    [[[NSURLSession sharedSession] dataTaskWithRequest:r
        completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
            BOOL ok = NO;
            NSString *msg = nil;
            NSString *vurl = nil;
            if (error) {
                msg = @"网络请求失败，检查网络后重试";
            } else {
                id obj = data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil;
                if ([obj isKindOfClass:[NSDictionary class]]) {
                    NSDictionary *j = (NSDictionary *)obj;
                    vurl = LSVerifyURLFromJSON(j);
                    NSString *code = [j[@"code"] description];
                    NSString *m = j[@"msg"];
                    if (![m isKindOfClass:[NSString class]] || m.length == 0) m = j[@"message"];
                    if (![m isKindOfClass:[NSString class]] || m.length == 0) m = j[@"error"];
                    if (![m isKindOfClass:[NSString class]] || m.length == 0) m = nil;
                    id dataObj = j[@"data"];
                    BOOL hasId = NO;
                    if ([dataObj isKindOfClass:[NSDictionary class]]) {
                        id mid = ((NSDictionary *)dataObj)[@"id"];
                        hasId = (mid != nil && [mid description].length > 0);
                    }
                    ok = ([j[@"ok"] integerValue] == 1 || [code isEqualToString:@"100000"] || hasId);
                    msg = m;
                    if (!ok && msg && [msg containsString:@"成功"]) ok = YES;
                    // v1.07：微博要求验证时，用本号走验证后重试；
                    // 不再借用整机共享的网页会话发帖（那会把活记到别的号名下）。
                    if (!ok && msg && deep < 1
                        && ([msg containsString:@"safety"] || [msg containsString:@"verify"]
                            || [msg containsString:@"Verify"])) {
                        if (vurl.length > 0) {
                            __weak typeof(self) wsv = self;
                            dispatch_async(dispatch_get_main_queue(), ^{
                                typeof(self) sv = wsv;
                                if (!sv) return;
                                [sv superLikeLog:@"info" text:@"微博要求验证，用本号过验证后重发"];
                                [sv lsRunVerify:vurl cookies:cookiesJSON kind:@"publish"
                                       completion:^(BOOL vok, NSString *newCk) {
                                    if (vok && newCk.length > 0) {
                                        [sv superLikeLog:@"info" text:@"验证过了，重新发帖"];
                                        [sv lsPostPublish:newCk text:text uid:uid
                                                      deep:deep + 1 completion:done];
                                    } else {
                                        dispatch_async(dispatch_get_main_queue(), ^{
                                            [sv superLikeLog:@"bad" text:@"需要安全验证，自动过滑块没成功"];
                                            done(NO, @"需要安全验证，自动过滑块没成功");
                                        });
                                    }
                                }];
                            });
                        } else {
                            dispatch_async(dispatch_get_main_queue(), ^{
                                [self superLikeLog:@"bad" text:@"这个号被微博拦了：去手机微博手动发一条，再回来跑就行"];
                                [self toast:@"去手机微博手动发一条，再回来跑就行"];
                                done(NO, @"这个号被微博拦了：去手机微博手动发一条，再回来跑就行");
                            });
                        }
                        return;
                    }
                    if (!ok && !msg) {
                        // 微博回了内容但字段对不上，把原文截几行下来，方便定位到底卡在哪
                        NSString *rs = data.length ? [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] : nil;
                        if (rs.length > 160) rs = [rs substringToIndex:160];
                        NSHTTPURLResponse *hr = (NSHTTPURLResponse *)response;
                        NSString *dbg = [NSString stringWithFormat:@"发帖被驳回 · HTTP %ld · 原文：%@",
                                         (long)hr.statusCode, (rs.length ? rs : @"(空)")];
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [self superLikeLog:@"bad" text:dbg];
                        });
                        if (hr.statusCode == 401 || hr.statusCode == 403) msg = @"Cookie 已失效，请重新登录";
                        else msg = [NSString stringWithFormat:@"发帖失败（%@）", code.length ? code : @"无返回"];
                        // v1.07：这个号的登录态在 weibo.com 上不被认，直接如实报错，
                        // 不再借共享网页会话代发（会串号，且日志会误报成功）。
                        if (deep < 1 && rs.length > 0
                            && ([rs containsString:@"newlogin"] || [rs containsString:@"-100"])) {
                            msg = @"这个号的登录态在 weibo.com 上不被认，去账号页重新登录一次";
                        }
                    }
                } else {
                    NSHTTPURLResponse *hr = (NSHTTPURLResponse *)response;
                    msg = (hr.statusCode == 418 || hr.statusCode == 403) ? @"被微博拦截了，换个网络再试" : @"微博返回了看不懂的内容，稍后再试";
                }
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                if (!ok && vurl.length > 0 && deep < 2) {
                    __weak typeof(self) ws2 = self;
                    [self lsRunVerify:vurl cookies:cookiesJSON kind:@"publish" completion:^(BOOL vok, NSString *newCk) {
                        typeof(self) sf2 = ws2;
                        if (!sf2) { done(NO, @"需要安全验证，请稍后重试"); return; }
                        if (vok && newCk.length > 0) {
                            // v1.10 身份守卫：验证器跑在共享网页会话里，回来的 SUB 可能不是这个号
                            NSString *subA = LSCookieValue(cookiesJSON, @"SUB");
                            NSString *subB = LSCookieValue(newCk, @"SUB");
                            NSString *useCk = newCk;
                            if (subA.length && subB.length && ![subA isEqualToString:subB]) {
                                [sf2 superLikeLog:@"bad" text:@"⚠️ 验证回来的登录态不是这个号，已改用本号原 cookie 重试"];
                                useCk = cookiesJSON;
                            }
                            [sf2 fetchXsrfForce:useCk completion:^(NSString *tk) {
                                [sf2 lsPostPublish:useCk text:text uid:uid deep:deep + 1 completion:done];
                            }];
                        } else {
                            done(NO, @"验证没通过（微博还要求验证，可再点一次「重开验证」）");
                        }
                    }];
                    return;
                }
                // 微博偶发「获取数据失败（ApiError）」但帖子其实已落库：
                // 等几秒回查这个账号的最新微博，能对上就改判成功
                BOOL maybePosted = (!ok && vurl.length == 0 && msg.length > 0 &&
                    ([msg containsString:@"获取数据失败"] || [msg containsString:@"ApiError"]
                     || [msg containsString:@"系统繁忙"] || [msg containsString:@"稍后重试"]));
                // v1.07：判定成功也回查一次个人主页。接口说成功了但主页查不到，
                // 就在日志里点明，不再让「成功」两个字盖住可能的假发。
                if (ok && uid.length > 0) {
                    __weak typeof(self) wv2 = self;
                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(6.0 * NSEC_PER_SEC)),
                        dispatch_get_main_queue(), ^{
                        typeof(self) sv2 = wv2;
                        if (!sv2) return;
                        [sv2 lsConfirmPost:cookiesJSON uid:uid text:text completion:^(BOOL hit) {
                            if (hit) return;
                            dispatch_async(dispatch_get_main_queue(), ^{
                                [sv2 superLikeLog:@"info" text:@"发帖成功，但个人主页暂时查不到这条（可能是延迟，也可能是没真发出去，稍后核对）"];
                            });
                        }];
                    });
                }
                if (maybePosted) {
                    __weak typeof(self) wq = self;
                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5.0 * NSEC_PER_SEC)),
                        dispatch_get_main_queue(), ^{
                        typeof(self) sq = wq;
                        if (!sq) { done(NO, msg); return; }
                        [sq lsConfirmPost:cookiesJSON uid:uid text:text completion:^(BOOL hit) {
                            if (hit) {
                                NSLog(@"[LS] 发帖回查命中，判定为已发出");
                                done(YES, nil);
                            } else {
                                done(NO, msg);
                            }
                        }];
                    });
                    return;
                }
                if (!ok && LSMsgLooksCsrf(msg) && deep < 2) {
                    [self superLikeLog:@"info" text:@"CSRF 过期了，正在换最新 XSRF-TOKEN 重试"];
                    __weak typeof(self) wsc = self;
                    [self fetchXsrfForce:cookiesJSON completion:^(NSString *tk) {
                        typeof(self) sfc = wsc;
                        if (!sfc) { done(NO, msg); return; }
                        [sfc lsPostPublish:cookiesJSON text:text uid:uid deep:deep + 1 completion:done];
                    }];
                    return;
                }
                done(ok, msg);
            });
        }] resume];
}

// 去掉 HTML 标签和 # 号、空白，用于文案比对
- (NSString *)lsPlainPostText:(NSString *)s {
    if (![s isKindOfClass:[NSString class]] || s.length == 0) return @"";
    NSRegularExpression *re = [NSRegularExpression regularExpressionWithPattern:@"<[^>]+>"
        options:0 error:nil];
    NSString *t = [re stringByReplacingMatchesInString:s options:0
        range:NSMakeRange(0, s.length) withTemplate:@""];
    NSMutableString *o = [NSMutableString string];
    NSCharacterSet *skip = [NSCharacterSet characterSetWithCharactersInString:@" \t\r\n#"];
    for (NSUInteger i = 0; i < t.length; i++) {
        unichar c = [t characterAtIndex:i];
        if (![skip characterIsMember:c]) [o appendFormat:@"%C", c];
    }
    return o;
}

// 回查个人主页最新一条，确认这次发帖到底有没有真的发出去
- (void)lsConfirmPost:(NSString *)cookiesJSON uid:(NSString *)uid text:(NSString *)text
           completion:(void (^)(BOOL hit))done {
    if (uid.length == 0) { done(NO); return; }
    NSString *ck = LSHeaderFromCookiesJSON(cookiesJSON, @"weibo.com");
    if (ck.length == 0) { done(NO); return; }
    NSString *url = [NSString stringWithFormat:
        @"https://weibo.com/ajax/statuses/mymblog?uid=%@&feature=0&page=1", uid];
    NSMutableURLRequest *r = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    r.HTTPMethod = @"GET";
    [r setValue:kPCUA forHTTPHeaderField:@"User-Agent"];
    [r setValue:@"https://weibo.com/" forHTTPHeaderField:@"Referer"];
    [r setValue:@"application/json, text/plain, */*" forHTTPHeaderField:@"Accept"];
    [r setValue:ck forHTTPHeaderField:@"Cookie"];
    r.timeoutInterval = 15.0;
    [[[NSURLSession sharedSession] dataTaskWithRequest:r
        completionHandler:^(NSData *data, NSURLResponse *resp, NSError *error) {
            BOOL hit = NO;
            if (!error && data) {
                id j = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                if ([j isKindOfClass:[NSDictionary class]]) {
                    id d = ((NSDictionary *)j)[@"data"];
                    if ([d isKindOfClass:[NSDictionary class]]) {
                        id lst = ((NSDictionary *)d)[@"list"];
                        if ([lst isKindOfClass:[NSArray class]] && [lst count] > 0) {
                            id first = [lst objectAtIndex:0];
                            if ([first isKindOfClass:[NSDictionary class]]) {
                                NSString *pub = [self lsPlainPostText:((NSDictionary *)first)[@"text"]];
                                NSString *mine = [self lsPlainPostText:text];
                                if (pub.length > 0 && mine.length > 0) {
                                    NSUInteger probe = MIN((NSUInteger)16, mine.length);
                                    NSString *head = [mine substringToIndex:probe];
                                    if ([pub containsString:head]) hit = YES;
                                }
                            }
                        }
                    }
                }
            }
            dispatch_async(dispatch_get_main_queue(), ^{ done(hit); });
        }] resume];
}

- (void)publishCallback:(BOOL)ok msg:(NSString *)msg {
    NSString *m = msg ?: @"";
    NSData *d = [NSJSONSerialization dataWithJSONObject:@[ @(ok), m ] options:0 error:nil];
    NSString *json = d ? [[NSString alloc] initWithData:d encoding:NSUTF8StringEncoding] : @"[false,\"\"]";
    NSString *js = [NSString stringWithFormat:
        @"if(window.lsPublishDone) window.lsPublishDone(%@[0], %@[1]);", json, json];
    [self.web evaluateJavaScript:js completionHandler:nil];
    if (ok) [self toast:@"已发送到左航超话"];
}

#pragma mark - 登录

- (void)openLogin {
    // 登录前把 WebView 里残留的微博登录态清掉。
    // 否则新号扫码成功后，旧号的 cookie 还在，登录检测会把新号识别成上一个账号，
    // upsert 按 uid 去重就会「加进来还是原来那个」，账号数永远卡在原地。
    __weak typeof(self) ws = self;
    __block BOOL fired = NO;
    void (^go)(void) = ^{
        if (fired) return;
        fired = YES;
        dispatch_async(dispatch_get_main_queue(), ^{
            typeof(self) sf = ws;
            if (sf) [sf showLoginPage];
        });
    };
    // 清理本身也可能不回调，3 秒后直接开登录页，不让用户干等
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{ go(); });

    WKHTTPCookieStore *cs = [WKWebsiteDataStore defaultDataStore].httpCookieStore;
    [cs getAllCookies:^(NSArray<NSHTTPCookie *> *cookies) {
        NSMutableArray *victims = [NSMutableArray array];
        for (NSHTTPCookie *c in cookies) {
            NSString *dom = [c.domain lowercaseString];
            if ([dom containsString:@"weibo"] || [dom containsString:@"sina"]) [victims addObject:c];
        }
        if (victims.count == 0) { go(); return; }
        __block NSInteger left = (NSInteger)victims.count;
        for (NSHTTPCookie *c in victims) {
            [cs deleteCookie:c completionHandler:^{
                dispatch_async(dispatch_get_main_queue(), ^{
                    left -= 1;
                    if (left <= 0) go();
                });
            }];
        }
    }];
}

- (void)showLoginPage {
    LSLoginViewController *vc = [[LSLoginViewController alloc] init];
    vc.modalPresentationStyle = UIModalPresentationFullScreen;
    __weak typeof(self) weakSelf = self;
    vc.onDone = ^(NSDictionary *acc) {
        typeof(self) sf = weakSelf;
        if (!sf) return;
        NSString *nu = [acc[@"uid"] description];
        BOOL dup = NO;
        NSString *oldName = nil;
        for (NSDictionary *d in [LSStore accounts]) {
            if ([[d[@"uid"] description] isEqualToString:nu]) {
                dup = YES;
                oldName = d[@"name"];
                break;
            }
        }
        [sf pushAccounts:[LSStore upsert:acc]];
        if (dup) {
            [sf toast:[NSString stringWithFormat:@"还是上一次的号（%@），登录态没切换成功，退出去重试一次", oldName ?: @"同名账号"]];
        } else {
            [sf toast:[NSString stringWithFormat:@"已添加 %@", acc[@"name"] ?: @"账号"]];
        }
    };
    vc.onFail = ^(NSString *msg) {
        typeof(self) sf = weakSelf;
        if (sf) [sf toast:msg];
    };
    [self presentViewController:vc animated:YES completion:nil];
}

- (void)pushNick {
    NSString *n = [[NSUserDefaults standardUserDefaults] stringForKey:@"left_nick"];
    if (n.length == 0) n = @"航航丝";
    NSData *d = [NSJSONSerialization dataWithJSONObject:@[ n ] options:0 error:nil];
    NSString *js = d ? [[NSString alloc] initWithData:d encoding:NSUTF8StringEncoding] : @"[\"航航丝\"]";
    NSString *code = [NSString stringWithFormat:
        @"if (window.lsNick) window.lsNick(%@[0]);", js];
    [self.web evaluateJavaScript:code completionHandler:nil];
}

- (void)pushAccounts:(NSArray *)accounts {
    NSData *d = [NSJSONSerialization dataWithJSONObject:(accounts ?: @[]) options:0 error:nil];
    NSString *json = d ? [[NSString alloc] initWithData:d encoding:NSUTF8StringEncoding] : @"[]";
    NSString *js = [NSString stringWithFormat:
        @"window.__LS_ACCOUNTS__ = %@; if (window.renderAccounts) window.renderAccounts();", json];
    [self.web evaluateJavaScript:js completionHandler:nil];
}

- (void)toast:(NSString *)msg {
    if (!msg) return;
    NSData *d = [NSJSONSerialization dataWithJSONObject:@[ msg ] options:0 error:nil];
    NSString *json = d ? [[NSString alloc] initWithData:d encoding:NSUTF8StringEncoding] : @"[]";
    NSString *js = [NSString stringWithFormat:
        @"if (window.toast) window.toast(%@[0]);", json];
    [self.web evaluateJavaScript:js completionHandler:nil];
}

#pragma mark - 导航失败

- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(WKNavigation *)navigation withError:(NSError *)error {
    NSString *html = [NSString stringWithFormat:
        @"<html><body style='font-family:-apple-system;padding:24px;background:#f1f5fb'>"
        @"<h3 style='color:#e8557f'>页面加载失败</h3>"
        @"<p style='font-size:13px;color:#6b7c93'>%@</p></body></html>", error.localizedDescription];
    [webView loadHTMLString:html baseURL:nil];
}

@end

#pragma mark - AppDelegate

@interface LSAppDelegate : UIResponder <UIApplicationDelegate>
@property (nonatomic, strong) UIWindow *window;
@end

@implementation LSAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.window.backgroundColor = [UIColor colorWithRed:0.945 green:0.961 blue:0.984 alpha:1.0];
    LSViewController *vc = [[LSViewController alloc] init];
    self.window.rootViewController = vc;
    [self.window makeKeyAndVisible];
    return YES;
}

@end

int main(int argc, char *argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, @"LSAppDelegate");
    }
}
